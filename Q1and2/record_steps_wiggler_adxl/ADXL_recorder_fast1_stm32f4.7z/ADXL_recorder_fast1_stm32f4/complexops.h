/* 
 *  complexops.h
 *   Complex math definitions for code sharing between 
 *   the DSP System Toolbox and the Communications System Toolbox.
 *
 *  Copyright 1996-2016 The MathWorks, Inc.
 */

#ifndef __COMPLEXOPS_H__
#define __COMPLEXOPS_H__

#ifdef MATLAB_MEX_FILE
#include "tmwtypes.h"
#else
#include "rtwtypes.h"
#endif

#ifdef USE_MXARRAY_COMPLEXOPS

    #include "comm_mx_util.h"

    #ifdef MX_INTERLEAVED_COMPLEX
        #define cArray mxComplexDouble *
        #define Re(x, n) (x[n].real)
        #define Im(x, n) (x[n].imag)
        #define cArray32 mxComplexSingle *
    #else
        #define cArray struct complexnumber
        #define Re(x, n) (x.re[n])
        #define Im(x, n) (x.im[n])
        #define cArray32 struct complexnumber32
    #endif
#else

    /* Simulink complex arrays, creal_T (interleaved real/imag parts) */
    #define cArray creal_T *
    #define Re(x, n) (x[n].re)
    #define Im(x, n) (x[n].im)

    /* Simulink complex arrays, creal32_T (interleaved real/imag parts) */
    #define cArray32 creal32_T *
    
#endif

#define cmult_Re(x, nx, y, ny) ( Re(x, nx)*Re(y, ny) - Im(x, nx)*Im(y, ny) )
#define cmult_Im(x, nx, y, ny) ( Re(x, nx)*Im(y, ny) + Im(x, nx)*Re(y, ny) )

#endif

/* [EOF] */
