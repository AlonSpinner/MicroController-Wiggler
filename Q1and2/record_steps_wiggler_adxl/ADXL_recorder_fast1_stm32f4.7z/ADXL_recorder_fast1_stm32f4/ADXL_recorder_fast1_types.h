/*
 * File: ADXL_recorder_fast1_types.h
 *
 * Created with Waijung Blockset
 *
 * Real-Time Workshop code generated for Simulink model ADXL_recorder_fast1.
 *
 * Model version                        : 1.124
 * Real-Time Workshop file version      : 8.14 (R2018a) 06-Feb-2018
 * Real-Time Workshop file generated on : Sun Jul 21 13:42:21 2019
 * TLC version                          : 8.14 (Feb 22 2018)
 * C/C++ source code generated on       : Sun Jul 21 13:42:30 2019
 *
 * Target selection: stm32f4.tlc
 * Embedded hardware selection: ARM Compatible->Cortex - M4
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_ADXL_recorder_fast1_types_h_
#define RTW_HEADER_ADXL_recorder_fast1_types_h_
#include "rtwtypes.h"
#ifndef typedef_dsp_private_MedianFilterCG_ADXL
#define typedef_dsp_private_MedianFilterCG_ADXL

typedef struct {
  int32_T isInitialized;
  boolean_T isSetupComplete;
  real32_T pWinLen;
  real32_T pBuf[5];
  real32_T pHeap[5];
  real32_T pMidHeap;
  real32_T pIdx;
  real32_T pPos[5];
  real32_T pMinHeapLength;
  real32_T pMaxHeapLength;
} dsp_private_MedianFilterCG_ADXL;

#endif                                 /*typedef_dsp_private_MedianFilterCG_ADXL*/

#ifndef typedef_cell_wrap_ADXL_recorder_fast1
#define typedef_cell_wrap_ADXL_recorder_fast1

typedef struct {
  uint32_T f1[8];
} cell_wrap_ADXL_recorder_fast1;

#endif                                 /*typedef_cell_wrap_ADXL_recorder_fast1*/

#ifndef typedef_dsp_MedianFilter_ADXL_recorder_
#define typedef_dsp_MedianFilter_ADXL_recorder_

typedef struct {
  boolean_T matlabCodegenIsDeleted;
  int32_T isInitialized;
  boolean_T isSetupComplete;
  cell_wrap_ADXL_recorder_fast1 inputVarSize;
  int32_T NumChannels;
  dsp_private_MedianFilterCG_ADXL pMID;
} dsp_MedianFilter_ADXL_recorder_;

#endif                                 /*typedef_dsp_MedianFilter_ADXL_recorder_*/

/* Parameters (default storage) */
typedef struct Parameters_ADXL_recorder_fast1_ Parameters_ADXL_recorder_fast1;

/* Forward declaration for rtModel */
typedef struct tag_RTM_ADXL_recorder_fast1 RT_MODEL_ADXL_recorder_fast1;

#endif                                 /* RTW_HEADER_ADXL_recorder_fast1_types_h_ */

/* [EOF] */
