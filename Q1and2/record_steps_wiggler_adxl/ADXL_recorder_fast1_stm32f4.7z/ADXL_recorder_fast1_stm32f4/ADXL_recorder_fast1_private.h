/*
 * File: ADXL_recorder_fast1_private.h
 *
 * Created with Waijung Blockset
 *
 * Real-Time Workshop code generated for Simulink model ADXL_recorder_fast1.
 *
 * Model version                        : 1.124
 * Real-Time Workshop file version      : 8.14 (R2018a) 06-Feb-2018
 * Real-Time Workshop file generated on : Sun Jul 21 13:42:21 2019
 * TLC version                          : 8.14 (Feb 22 2018)
 * C/C++ source code generated on       : Sun Jul 21 13:42:30 2019
 *
 * Target selection: stm32f4.tlc
 * Embedded hardware selection: ARM Compatible->Cortex - M4
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_ADXL_recorder_fast1_private_h_
#define RTW_HEADER_ADXL_recorder_fast1_private_h_
#include "rtwtypes.h"
#include "ADXL_recorder_fast1.h"
#include "dsp_rt.h"                    /* DSP System Toolbox general run time support functions */
#include "dspeph_rt.h"                 /* DSP System Toolbox run time support library */

extern real_T rt_modd_snf(real_T u0, real_T u1);
extern void ADXL_recorde_MedianFilter1_Init(rtDW_MedianFilter1_ADXL_recorde
  *localDW);
extern void ADXL_record_MedianFilter1_Start(rtDW_MedianFilter1_ADXL_recorde
  *localDW);
extern void ADXL_recorder_fas_MedianFilter1(real32_T rtu_0,
  rtB_MedianFilter1_ADXL_recorder *localB, rtDW_MedianFilter1_ADXL_recorde
  *localDW);
extern void ADXL_recorde_MedianFilter1_Term(rtDW_MedianFilter1_ADXL_recorde
  *localDW);

#endif                                 /* RTW_HEADER_ADXL_recorder_fast1_private_h_ */

/* [EOF] */
