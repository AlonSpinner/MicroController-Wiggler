/*
 * File: ADXL_recorder_fast1.c
 *
 * Created with Waijung Blockset
 *
 * Real-Time Workshop code generated for Simulink model ADXL_recorder_fast1.
 *
 * Model version                        : 1.124
 * Real-Time Workshop file version      : 8.14 (R2018a) 06-Feb-2018
 * Real-Time Workshop file generated on : Sun Jul 21 13:42:21 2019
 * TLC version                          : 8.14 (Feb 22 2018)
 * C/C++ source code generated on       : Sun Jul 21 13:42:30 2019
 *
 * Target selection: stm32f4.tlc
 * Embedded hardware selection: ARM Compatible->Cortex - M4
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "ADXL_recorder_fast1.h"
#include "ADXL_recorder_fast1_private.h"

/* Block signals (default storage) */
BlockIO_ADXL_recorder_fast1 ADXL_recorder_fast1_B;

/* Block states (default storage) */
D_Work_ADXL_recorder_fast1 ADXL_recorder_fast1_DWork;

/* Real-time model */
RT_MODEL_ADXL_recorder_fast1 ADXL_recorder_fast1_M_;
RT_MODEL_ADXL_recorder_fast1 *const ADXL_recorder_fast1_M =
  &ADXL_recorder_fast1_M_;

/* Forward declaration for local functions */
static void ADXL_r_MedianFilterCG_resetImpl(dsp_private_MedianFilterCG_ADXL *obj);
static void A_MedianFilterCG_trickleDownMax(dsp_private_MedianFilterCG_ADXL *obj,
  real32_T i);
static void A_MedianFilterCG_trickleDownMin(dsp_private_MedianFilterCG_ADXL *obj,
  real32_T i);
static void SystemProp_matlabCodegenSetAnyP(dsp_MedianFilter_ADXL_recorder_ *obj,
  boolean_T value);
static void ADXL_recorde_SystemCore_release(dsp_MedianFilter_ADXL_recorder_ *obj);
static void ADXL_recorder_SystemCore_delete(dsp_MedianFilter_ADXL_recorder_ *obj);
static void matlabCodegenHandle_matlabCodeg(dsp_MedianFilter_ADXL_recorder_ *obj);
static void rate_scheduler(void);

/*
 *   This function updates active task flag for each subrate.
 * The function is called at model base rate, hence the
 * generated code self-manages all its subrates.
 */
static void rate_scheduler(void)
{
  /* Compute which subrates run during the next base time step.  Subrates
   * are an integer multiple of the base rate counter.  Therefore, the subtask
   * counter is reset when it reaches its limit (zero means run).
   */
  (ADXL_recorder_fast1_M->Timing.TaskCounters.TID[1])++;
  if ((ADXL_recorder_fast1_M->Timing.TaskCounters.TID[1]) > 9) {/* Sample time: [0.01s, 0.0s] */
    ADXL_recorder_fast1_M->Timing.TaskCounters.TID[1] = 0;
  }

  (ADXL_recorder_fast1_M->Timing.TaskCounters.TID[2])++;
  if ((ADXL_recorder_fast1_M->Timing.TaskCounters.TID[2]) > 99) {/* Sample time: [0.1s, 0.0s] */
    ADXL_recorder_fast1_M->Timing.TaskCounters.TID[2] = 0;
  }
}

static void ADXL_r_MedianFilterCG_resetImpl(dsp_private_MedianFilterCG_ADXL *obj)
{
  real32_T cnt1;
  real32_T cnt2;
  int32_T i;
  for (i = 0; i < 5; i++) {
    obj->pBuf[i] = 0.0F;
    obj->pPos[i] = 0.0F;
    obj->pHeap[i] = 0.0F;
  }

  obj->pWinLen = 5.0F;
  obj->pIdx = obj->pWinLen;
  obj->pMidHeap = (real32_T)ceil((obj->pWinLen + 1.0F) / 2.0F);
  cnt1 = (obj->pWinLen - 1.0F) / 2.0F;
  if (cnt1 < 0.0F) {
    obj->pMinHeapLength = (real32_T)ceil(cnt1);
  } else {
    obj->pMinHeapLength = (real32_T)floor(cnt1);
  }

  cnt1 = obj->pWinLen / 2.0F;
  if (cnt1 < 0.0F) {
    obj->pMaxHeapLength = (real32_T)ceil(cnt1);
  } else {
    obj->pMaxHeapLength = (real32_T)floor(cnt1);
  }

  cnt1 = 1.0F;
  cnt2 = obj->pWinLen;
  for (i = 0; i < 5; i++) {
    if ((int32_T)(real32_T)fmod(5.0F + -(real32_T)i, 2.0) == 0) {
      obj->pPos[(5 - i) - 1] = cnt1;
      cnt1++;
    } else {
      obj->pPos[(5 - i) - 1] = cnt2;
      cnt2--;
    }

    obj->pHeap[(int32_T)obj->pPos[(5 - i) - 1] - 1] = 5.0F + -(real32_T)i;
  }
}

static void A_MedianFilterCG_trickleDownMax(dsp_private_MedianFilterCG_ADXL *obj,
  real32_T i)
{
  real32_T temp;
  real32_T u;
  real32_T ind2;
  int32_T temp_tmp;
  boolean_T exitg1;
  exitg1 = false;
  while ((!exitg1) && (i >= -obj->pMaxHeapLength)) {
    if ((i < -1.0F) && (i > -obj->pMaxHeapLength) && (obj->pBuf[(int32_T)
         obj->pHeap[(int32_T)(i + obj->pMidHeap) - 1] - 1] < obj->pBuf[(int32_T)
         obj->pHeap[(int32_T)((i - 1.0F) + obj->pMidHeap) - 1] - 1])) {
      i--;
    }

    u = i / 2.0F;
    if (u < 0.0F) {
      u = (real32_T)ceil(u);
    } else {
      u = (real32_T)floor(u);
    }

    ind2 = i + obj->pMidHeap;
    if (!(obj->pBuf[(int32_T)obj->pHeap[(int32_T)(u + obj->pMidHeap) - 1] - 1] <
          obj->pBuf[(int32_T)obj->pHeap[(int32_T)ind2 - 1] - 1])) {
      exitg1 = true;
    } else {
      u = i / 2.0F;
      if (u < 0.0F) {
        u = (real32_T)ceil(u);
      } else {
        u = (real32_T)floor(u);
      }

      u += obj->pMidHeap;
      temp_tmp = (int32_T)u - 1;
      temp = obj->pHeap[temp_tmp];
      obj->pHeap[temp_tmp] = obj->pHeap[(int32_T)ind2 - 1];
      obj->pHeap[(int32_T)ind2 - 1] = temp;
      obj->pPos[(int32_T)obj->pHeap[(int32_T)u - 1] - 1] = u;
      obj->pPos[(int32_T)obj->pHeap[(int32_T)ind2 - 1] - 1] = ind2;
      i *= 2.0F;
    }
  }
}

static void A_MedianFilterCG_trickleDownMin(dsp_private_MedianFilterCG_ADXL *obj,
  real32_T i)
{
  real32_T temp;
  real32_T u;
  real32_T ind1;
  int32_T tmp;
  boolean_T exitg1;
  exitg1 = false;
  while ((!exitg1) && (i <= obj->pMinHeapLength)) {
    if ((i > 1.0F) && (i < obj->pMinHeapLength) && (obj->pBuf[(int32_T)
         obj->pHeap[(int32_T)((i + 1.0F) + obj->pMidHeap) - 1] - 1] < obj->pBuf
         [(int32_T)obj->pHeap[(int32_T)(i + obj->pMidHeap) - 1] - 1])) {
      i++;
    }

    u = i / 2.0F;
    if (u < 0.0F) {
      u = (real32_T)ceil(u);
    } else {
      u = (real32_T)floor(u);
    }

    ind1 = i + obj->pMidHeap;
    if (!(obj->pBuf[(int32_T)obj->pHeap[(int32_T)ind1 - 1] - 1] < obj->pBuf
          [(int32_T)obj->pHeap[(int32_T)(u + obj->pMidHeap) - 1] - 1])) {
      exitg1 = true;
    } else {
      u = i / 2.0F;
      if (u < 0.0F) {
        u = (real32_T)ceil(u);
      } else {
        u = (real32_T)floor(u);
      }

      u += obj->pMidHeap;
      temp = obj->pHeap[(int32_T)ind1 - 1];
      tmp = (int32_T)u - 1;
      obj->pHeap[(int32_T)ind1 - 1] = obj->pHeap[tmp];
      obj->pHeap[tmp] = temp;
      obj->pPos[(int32_T)obj->pHeap[(int32_T)ind1 - 1] - 1] = ind1;
      obj->pPos[(int32_T)obj->pHeap[(int32_T)u - 1] - 1] = u;
      i *= 2.0F;
    }
  }
}

static void SystemProp_matlabCodegenSetAnyP(dsp_MedianFilter_ADXL_recorder_ *obj,
  boolean_T value)
{
  obj->matlabCodegenIsDeleted = value;
}

static void ADXL_recorde_SystemCore_release(dsp_MedianFilter_ADXL_recorder_ *obj)
{
  if ((obj->isInitialized == 1) && obj->isSetupComplete) {
    obj->NumChannels = -1;
    if (obj->pMID.isInitialized == 1) {
      obj->pMID.isInitialized = 2;
    }
  }
}

static void ADXL_recorder_SystemCore_delete(dsp_MedianFilter_ADXL_recorder_ *obj)
{
  ADXL_recorde_SystemCore_release(obj);
}

static void matlabCodegenHandle_matlabCodeg(dsp_MedianFilter_ADXL_recorder_ *obj)
{
  if (!obj->matlabCodegenIsDeleted) {
    SystemProp_matlabCodegenSetAnyP(obj, true);
    ADXL_recorder_SystemCore_delete(obj);
  }
}

/*
 * System initialize for atomic system:
 *    synthesized block
 *    synthesized block
 */
void ADXL_recorde_MedianFilter1_Init(rtDW_MedianFilter1_ADXL_recorde *localDW)
{
  /* InitializeConditions for MATLABSystem: '<Root>/Median Filter1' */
  if (localDW->obj.pMID.isInitialized == 1) {
    ADXL_r_MedianFilterCG_resetImpl(&localDW->obj.pMID);
  }

  /* End of InitializeConditions for MATLABSystem: '<Root>/Median Filter1' */
}

/*
 * Start for atomic system:
 *    synthesized block
 *    synthesized block
 */
void ADXL_record_MedianFilter1_Start(rtDW_MedianFilter1_ADXL_recorde *localDW)
{
  dsp_MedianFilter_ADXL_recorder_ *obj;

  /* Start for MATLABSystem: '<Root>/Median Filter1' */
  localDW->obj.matlabCodegenIsDeleted = true;
  localDW->obj.isInitialized = 0;
  localDW->obj.NumChannels = -1;
  localDW->obj.matlabCodegenIsDeleted = false;
  localDW->objisempty = true;
  obj = &localDW->obj;
  localDW->obj.isSetupComplete = false;
  localDW->obj.isInitialized = 1;
  localDW->obj.NumChannels = 1;
  obj->pMID.isInitialized = 0;
  localDW->obj.isSetupComplete = true;
}

/*
 * Output and update for atomic system:
 *    synthesized block
 *    synthesized block
 */
void ADXL_recorder_fas_MedianFilter1(real32_T rtu_0,
  rtB_MedianFilter1_ADXL_recorder *localB, rtDW_MedianFilter1_ADXL_recorde
  *localDW)
{
  dsp_MedianFilter_ADXL_recorder_ *obj;
  dsp_private_MedianFilterCG_ADXL *obj_0;
  real32_T vprev;
  real32_T p;
  boolean_T flag;
  real32_T temp;
  int32_T vprev_tmp;
  real32_T flag_tmp;
  real32_T tmp;
  boolean_T exitg1;

  /* MATLABSystem: '<Root>/Median Filter1' */
  obj = &localDW->obj;
  obj_0 = &localDW->obj.pMID;
  if (obj->pMID.isInitialized != 1) {
    obj->pMID.isSetupComplete = false;
    obj->pMID.isInitialized = 1;
    obj->pMID.isSetupComplete = true;
    ADXL_r_MedianFilterCG_resetImpl(&obj->pMID);
  }

  vprev_tmp = (int32_T)obj->pMID.pIdx - 1;
  vprev = obj->pMID.pBuf[vprev_tmp];
  vprev_tmp = (int32_T)obj->pMID.pIdx - 1;
  obj->pMID.pBuf[vprev_tmp] = rtu_0;
  vprev_tmp = (int32_T)obj->pMID.pIdx - 1;
  p = obj->pMID.pPos[vprev_tmp];
  obj->pMID.pIdx++;
  if (obj->pMID.pWinLen + 1.0F == obj->pMID.pIdx) {
    obj->pMID.pIdx = 1.0F;
  }

  if (p > obj->pMID.pMidHeap) {
    if (vprev < rtu_0) {
      vprev = p - obj->pMID.pMidHeap;
      A_MedianFilterCG_trickleDownMin(&obj->pMID, vprev * 2.0F);
    } else {
      vprev = p - obj->pMID.pMidHeap;
      exitg1 = false;
      while ((!exitg1) && (vprev > 0.0F)) {
        flag_tmp = vprev + obj_0->pMidHeap;
        p = (real32_T)floor(vprev / 2.0F);
        temp = p + obj_0->pMidHeap;
        flag = (obj_0->pBuf[(int32_T)obj_0->pHeap[(int32_T)flag_tmp - 1] - 1] <
                obj_0->pBuf[(int32_T)obj_0->pHeap[(int32_T)temp - 1] - 1]);
        if (!flag) {
          exitg1 = true;
        } else {
          tmp = vprev + obj_0->pMidHeap;
          flag_tmp = (real32_T)floor(vprev / 2.0F) + obj_0->pMidHeap;
          temp = obj_0->pHeap[(int32_T)tmp - 1];
          obj_0->pHeap[(int32_T)tmp - 1] = obj_0->pHeap[(int32_T)flag_tmp - 1];
          obj_0->pHeap[(int32_T)flag_tmp - 1] = temp;
          obj_0->pPos[(int32_T)obj_0->pHeap[(int32_T)tmp - 1] - 1] = tmp;
          obj_0->pPos[(int32_T)obj_0->pHeap[(int32_T)flag_tmp - 1] - 1] =
            flag_tmp;
          vprev = p;
        }
      }

      if (vprev == 0.0F) {
        A_MedianFilterCG_trickleDownMax(&obj->pMID, -1.0F);
      }
    }
  } else if (p < obj->pMID.pMidHeap) {
    if (rtu_0 < vprev) {
      vprev = p - obj->pMID.pMidHeap;
      A_MedianFilterCG_trickleDownMax(&obj->pMID, vprev * 2.0F);
    } else {
      vprev = p - obj->pMID.pMidHeap;
      exitg1 = false;
      while ((!exitg1) && (vprev < 0.0F)) {
        p = vprev / 2.0F;
        if (p < 0.0F) {
          p = (real32_T)ceil(p);
        } else {
          p = -0.0F;
        }

        flag_tmp = vprev + obj_0->pMidHeap;
        flag = (obj_0->pBuf[(int32_T)obj_0->pHeap[(int32_T)(p + obj_0->pMidHeap)
                - 1] - 1] < obj_0->pBuf[(int32_T)obj_0->pHeap[(int32_T)flag_tmp
                - 1] - 1]);
        if (!flag) {
          exitg1 = true;
        } else {
          p = vprev / 2.0F;
          if (p < 0.0F) {
            p = (real32_T)ceil(p);
          } else {
            p = -0.0F;
          }

          p += obj_0->pMidHeap;
          flag_tmp = vprev + obj_0->pMidHeap;
          vprev_tmp = (int32_T)p - 1;
          temp = obj_0->pHeap[vprev_tmp];
          obj_0->pHeap[vprev_tmp] = obj_0->pHeap[(int32_T)flag_tmp - 1];
          obj_0->pHeap[(int32_T)flag_tmp - 1] = temp;
          obj_0->pPos[(int32_T)obj_0->pHeap[(int32_T)p - 1] - 1] = p;
          obj_0->pPos[(int32_T)obj_0->pHeap[(int32_T)flag_tmp - 1] - 1] =
            flag_tmp;
          p = vprev / 2.0F;
          if (p < 0.0F) {
            vprev = (real32_T)ceil(p);
          } else {
            vprev = -0.0F;
          }
        }
      }

      if (vprev == 0.0F) {
        A_MedianFilterCG_trickleDownMin(&obj->pMID, 1.0F);
      }
    }
  } else {
    if (obj->pMID.pMaxHeapLength != 0.0F) {
      A_MedianFilterCG_trickleDownMax(&obj->pMID, -1.0F);
    }

    if (obj->pMID.pMinHeapLength > 0.0F) {
      A_MedianFilterCG_trickleDownMin(&obj->pMID, 1.0F);
    }
  }

  localB->MedianFilter1 = obj->pMID.pBuf[(int32_T)obj->pMID.pHeap[(int32_T)
    obj->pMID.pMidHeap - 1] - 1];

  /* End of MATLABSystem: '<Root>/Median Filter1' */
}

/*
 * Termination for atomic system:
 *    synthesized block
 *    synthesized block
 */
void ADXL_recorde_MedianFilter1_Term(rtDW_MedianFilter1_ADXL_recorde *localDW)
{
  /* Terminate for MATLABSystem: '<Root>/Median Filter1' */
  matlabCodegenHandle_matlabCodeg(&localDW->obj);
}

real_T rt_modd_snf(real_T u0, real_T u1)
{
  real_T y;
  boolean_T yEq;
  real_T q;
  y = u0;
  if (!((!rtIsNaN(u0)) && (!rtIsInf(u0)) && ((!rtIsNaN(u1)) && (!rtIsInf(u1)))))
  {
    if (u1 != 0.0) {
      y = (rtNaN);
    }
  } else if (u0 == 0.0) {
    y = u1 * 0.0;
  } else {
    if (u1 != 0.0) {
      y = fmod(u0, u1);
      yEq = (y == 0.0);
      if ((!yEq) && (u1 > floor(u1))) {
        q = fabs(u0 / u1);
        yEq = (fabs(q - floor(q + 0.5)) <= DBL_EPSILON * q);
      }

      if (yEq) {
        y = u1 * 0.0;
      } else {
        if ((u0 < 0.0) != (u1 < 0.0)) {
          y += u1;
        }
      }
    }
  }

  return y;
}

/* Model step function */
void ADXL_recorder_fast1_step(void)
{
  /* local block i/o variables */
  uint32_T rtb_Queue_o4;
  real32_T rtb_TmpSignalConversionAtQueueI[4];
  boolean_T rtb_LogicalOperator;
  boolean_T rtb_LogicalOperator1;
  boolean_T rtb_Queue_o2;
  boolean_T rtb_Queue_o3;
  real32_T rtb_Switch2_h;
  real32_T rtb_Switch2_p;
  int32_T denIdx;
  int32_T j;
  real32_T rtb_Sum1_m;
  real_T rtb_DiscreteFilter1;
  real_T rtb_Sum1;
  real_T Switch;
  real_T Switch1;

  /* S-Function (waijung_vdata_read): '<Root>/flag_for_recorder_uart' */

  /* flag_for_recorder_uart */
  ADXL_recorder_fast1_B.flag_for_recorder_uart = (uint8_t)
    VolatileDataStorage3_flag;

  /* RelationalOperator: '<S23>/Compare' incorporates:
   *  Constant: '<S23>/Constant'
   */
  ADXL_recorder_fast1_B.Compare = (ADXL_recorder_fast1_B.flag_for_recorder_uart ==
    ADXL_recorder_fast1_P.CompareToConstant1_const_c);

  /* RelationalOperator: '<S24>/Compare' incorporates:
   *  Constant: '<S24>/Constant'
   */
  ADXL_recorder_fast1_B.Compare_i =
    (ADXL_recorder_fast1_B.flag_for_recorder_uart ==
     ADXL_recorder_fast1_P.CompareToConstant5_const);

  /* RelationalOperator: '<S25>/Compare' incorporates:
   *  Constant: '<S25>/Constant'
   */
  ADXL_recorder_fast1_B.Compare_d =
    (ADXL_recorder_fast1_B.flag_for_recorder_uart ==
     ADXL_recorder_fast1_P.CompareToConstant6_const);

  /* S-Function (stm32f4_digital_output): '<S7>/DC_enable' */

  /* record_and_send_via_UARTDC_enable */
  {
    *record_and_send_via_UARTDC_enable_B0 = ADXL_recorder_fast1_B.Compare;
    *record_and_send_via_UARTDC_enable_B7 = ADXL_recorder_fast1_B.Compare_i;
    *record_and_send_via_UARTDC_enable_B14 = ADXL_recorder_fast1_B.Compare_d;
  }

  if (ADXL_recorder_fast1_M->Timing.TaskCounters.TID[1] == 0) {
    /* S-Function (stm32f4_pwm_capture): '<Root>/PWM chX' */

    /* PWMchX: '<Root>/PWM chX' */
    PWMchX_GetCaptured( &ADXL_recorder_fast1_B.PWMchX_o2,
                       &ADXL_recorder_fast1_B.PWMchX_o3,
                       &ADXL_recorder_fast1_B.PWMchX_o4,
                       &ADXL_recorder_fast1_B.PWMchX_o1);

    /* Sum: '<Root>/Sum' incorporates:
     *  Constant: '<Root>/Constant'
     */
    rtb_Sum1_m = ADXL_recorder_fast1_B.PWMchX_o3 -
      ADXL_recorder_fast1_P.Constant_Value;

    /* Switch: '<S5>/Switch2' incorporates:
     *  Constant: '<S19>/Constant'
     *  Constant: '<S20>/Constant'
     *  Delay: '<S5>/Delay2'
     *  Logic: '<S5>/Logical Operator4'
     *  RelationalOperator: '<S19>/Compare'
     *  RelationalOperator: '<S20>/Compare'
     */
    if ((rtb_Sum1_m < ADXL_recorder_fast1_P.CompareToConstant8_const) &&
        (rtb_Sum1_m > ADXL_recorder_fast1_P.CompareToConstant10_const)) {
      rtb_Switch2_h = rtb_Sum1_m;
    } else {
      rtb_Switch2_h = ADXL_recorder_fast1_DWork.Delay2_DSTATE;
    }

    /* End of Switch: '<S5>/Switch2' */
    ADXL_recorder_fas_MedianFilter1(rtb_Switch2_h,
      &ADXL_recorder_fast1_B.MedianFilter,
      &ADXL_recorder_fast1_DWork.MedianFilter);

    /* MultiPortSwitch: '<Root>/Index Vector' */
    ADXL_recorder_fast1_B.IndexVector =
      ADXL_recorder_fast1_B.MedianFilter.MedianFilter1;

    /* S-Function (stm32f4_pwm_capture): '<Root>/PWM chY' */

    /* PWMchY: '<Root>/PWM chY' */
    PWMchY_GetCaptured( &ADXL_recorder_fast1_B.PWMchY_o2,
                       &ADXL_recorder_fast1_B.PWMchY_o3,
                       &ADXL_recorder_fast1_B.PWMchY_o4,
                       &ADXL_recorder_fast1_B.PWMchY_o1);

    /* Sum: '<Root>/Sum1' incorporates:
     *  Constant: '<Root>/Constant1'
     */
    rtb_Sum1_m = ADXL_recorder_fast1_B.PWMchY_o3 -
      ADXL_recorder_fast1_P.Constant1_Value;

    /* Switch: '<S6>/Switch2' incorporates:
     *  Constant: '<S21>/Constant'
     *  Constant: '<S22>/Constant'
     *  Delay: '<S6>/Delay2'
     *  Logic: '<S6>/Logical Operator4'
     *  RelationalOperator: '<S21>/Compare'
     *  RelationalOperator: '<S22>/Compare'
     */
    if ((rtb_Sum1_m < ADXL_recorder_fast1_P.CompareToConstant8_const_l) &&
        (rtb_Sum1_m > ADXL_recorder_fast1_P.CompareToConstant10_const_o)) {
      rtb_Switch2_p = rtb_Sum1_m;
    } else {
      rtb_Switch2_p = ADXL_recorder_fast1_DWork.Delay2_DSTATE_c;
    }

    /* End of Switch: '<S6>/Switch2' */

    /* MATLABSystem: '<Root>/Median Filter1' */
    ADXL_recorder_fas_MedianFilter1(rtb_Switch2_p,
      &ADXL_recorder_fast1_B.MedianFilter1,
      &ADXL_recorder_fast1_DWork.MedianFilter1);

    /* MultiPortSwitch: '<Root>/Index Vector1' */
    ADXL_recorder_fast1_B.IndexVector1 =
      ADXL_recorder_fast1_B.MedianFilter1.MedianFilter1;
  }

  /* DiscreteFilter: '<Root>/Discrete Filter1' */
  rtb_DiscreteFilter1 = 0.0;
  denIdx = 1;
  for (j = 0; j < 500; j++) {
    rtb_DiscreteFilter1 += ADXL_recorder_fast1_P.DiscreteFilter1_NumCoef[denIdx]
      * ADXL_recorder_fast1_DWork.DiscreteFilter1_states[j];
    denIdx++;
  }

  /* End of DiscreteFilter: '<Root>/Discrete Filter1' */

  /* DiscreteFilter: '<Root>/Discrete Filter3' */
  rtb_Sum1 = 0.0;
  denIdx = 1;
  for (j = 0; j < 500; j++) {
    rtb_Sum1 += ADXL_recorder_fast1_P.DiscreteFilter3_NumCoef[denIdx] *
      ADXL_recorder_fast1_DWork.DiscreteFilter3_states[j];
    denIdx++;
  }

  ADXL_recorder_fast1_B.DiscreteFilter3 = rtb_Sum1;

  /* End of DiscreteFilter: '<Root>/Discrete Filter3' */

  /* SignalConversion: '<S7>/TmpSignal ConversionAtQueueInport1' incorporates:
   *  DataTypeConversion: '<Root>/Data Type Conversion'
   *  DataTypeConversion: '<Root>/Data Type Conversion1'
   */
  rtb_TmpSignalConversionAtQueueI[0] = ADXL_recorder_fast1_B.IndexVector;
  rtb_TmpSignalConversionAtQueueI[1] = ADXL_recorder_fast1_B.IndexVector1;
  rtb_TmpSignalConversionAtQueueI[2] = (real32_T)rtb_DiscreteFilter1;
  rtb_TmpSignalConversionAtQueueI[3] = (real32_T)
    ADXL_recorder_fast1_B.DiscreteFilter3;

  /* DiscretePulseGenerator: '<Root>/recording_clock' */
  rtb_Sum1 = (ADXL_recorder_fast1_DWork.clockTickCounter <
              ADXL_recorder_fast1_P.recording_clock_Duty) &&
    (ADXL_recorder_fast1_DWork.clockTickCounter >= 0) ?
    ADXL_recorder_fast1_P.recording_clock_Amp : 0.0;
  if (ADXL_recorder_fast1_DWork.clockTickCounter >=
      ADXL_recorder_fast1_P.recording_clock_Period - 1.0) {
    ADXL_recorder_fast1_DWork.clockTickCounter = 0;
  } else {
    ADXL_recorder_fast1_DWork.clockTickCounter++;
  }

  /* End of DiscretePulseGenerator: '<Root>/recording_clock' */

  /* Logic: '<S7>/Logical Operator' */
  rtb_LogicalOperator = (ADXL_recorder_fast1_B.Compare && (rtb_Sum1 != 0.0));

  /* DiscretePulseGenerator: '<Root>/send_2_uart_clock' */
  rtb_Sum1 = (ADXL_recorder_fast1_DWork.clockTickCounter_b <
              ADXL_recorder_fast1_P.send_2_uart_clock_Duty) &&
    (ADXL_recorder_fast1_DWork.clockTickCounter_b >= 0) ?
    ADXL_recorder_fast1_P.send_2_uart_clock_Amp : 0.0;
  if (ADXL_recorder_fast1_DWork.clockTickCounter_b >=
      ADXL_recorder_fast1_P.send_2_uart_clock_Period - 1.0) {
    ADXL_recorder_fast1_DWork.clockTickCounter_b = 0;
  } else {
    ADXL_recorder_fast1_DWork.clockTickCounter_b++;
  }

  /* End of DiscretePulseGenerator: '<Root>/send_2_uart_clock' */

  /* Logic: '<S7>/Logical Operator1' */
  rtb_LogicalOperator1 = (ADXL_recorder_fast1_B.Compare_i && (rtb_Sum1 != 0.0));

  /* S-Function (sdspstacknqueue): '<S7>/Queue' */
  /* DSP System Toolbox Queue (sdspstacknqueue) - '<S7>/Queue' */
  {
    if (MWDSP_EPHZCFcn(EVENT_PORT_MODE_EITHER,
                       (EventPortSigState *)
                       &ADXL_recorder_fast1_DWork.Queue_EPH2PrevState,
                       EventPortSigStateFcn_B(ADXL_recorder_fast1_B.Compare_d)
                       ) != EVENT_PORT_EVENT_NONE)/* CLEAR */
    {
      ADXL_recorder_fast1_DWork.Queue_QueueFrontIdx =
        ADXL_recorder_fast1_DWork.Queue_QueueBackIdx =
        ADXL_recorder_fast1_DWork.Queue_NumElements = 0;
      memset(&ADXL_recorder_fast1_B.Queue_o1[0], 0, sizeof(real32_T)*4);/* Set output values to zero */
    }

    if (MWDSP_EPHZCFcn(EVENT_PORT_MODE_EITHER,
                       (EventPortSigState *)
                       &ADXL_recorder_fast1_DWork.Queue_EPH0PrevState,
                       EventPortSigStateFcn_B(rtb_LogicalOperator)
                       ) != EVENT_PORT_EVENT_NONE)/* PUSH */
    {
      if (ADXL_recorder_fast1_DWork.Queue_NumElements != 6000) {
        {
          const size_t numbytes = sizeof(real32_T)*4;
          memcpy(&ADXL_recorder_fast1_DWork.Queue_BufferPtr[0]+
                 (ADXL_recorder_fast1_DWork.Queue_QueueBackIdx % 6000)*4,
                 &rtb_TmpSignalConversionAtQueueI[0], numbytes);
          ADXL_recorder_fast1_DWork.Queue_QueueBackIdx++;
          ADXL_recorder_fast1_DWork.Queue_NumElements++;
        }
      }
    }

    if (MWDSP_EPHZCFcn(EVENT_PORT_MODE_EITHER,
                       (EventPortSigState *)
                       &ADXL_recorder_fast1_DWork.Queue_EPH1PrevState,
                       EventPortSigStateFcn_B(rtb_LogicalOperator1)
                       ) != EVENT_PORT_EVENT_NONE)/* POP */
    {
      {
        const size_t numbytes = sizeof(real32_T)*4;
        if (ADXL_recorder_fast1_DWork.Queue_NumElements) {
          memcpy(&ADXL_recorder_fast1_B.Queue_o1[0],
                 &ADXL_recorder_fast1_DWork.Queue_BufferPtr[0]+
                 ADXL_recorder_fast1_DWork.Queue_QueueFrontIdx*4, numbytes);
          ADXL_recorder_fast1_DWork.Queue_NumElements --;
          if ((ADXL_recorder_fast1_DWork.Queue_QueueFrontIdx + 1) == 6000) {
            ADXL_recorder_fast1_DWork.Queue_QueueFrontIdx = 0;
            ADXL_recorder_fast1_DWork.Queue_QueueBackIdx %= 6000;
          } else
            ADXL_recorder_fast1_DWork.Queue_QueueFrontIdx ++;
        }
      }
    }

    rtb_Queue_o2 = (boolean_T) (ADXL_recorder_fast1_DWork.Queue_NumElements == 0);
    rtb_Queue_o3 = (boolean_T) (ADXL_recorder_fast1_DWork.Queue_NumElements ==
      6000);
    rtb_Queue_o4 = (uint32_T) ADXL_recorder_fast1_DWork.Queue_NumElements;
  }

  /* Outputs for Enabled SubSystem: '<S7>/Subsystem3' incorporates:
   *  EnablePort: '<S27>/Enable'
   */
  /* Logic: '<S7>/Logical Operator5' incorporates:
   *  Constant: '<S26>/Constant'
   *  Logic: '<S7>/Logical Operator4'
   *  RelationalOperator: '<S26>/Compare'
   */
  if ((!rtb_Queue_o2) && (ADXL_recorder_fast1_B.flag_for_recorder_uart ==
                          ADXL_recorder_fast1_P.CompareToConstant7_const)) {
    if (!ADXL_recorder_fast1_DWork.Subsystem3_MODE) {
      /* Enable for S-Function (stm32f4_usart): '<S27>/UART Tx3' */
      /* Level2 S-Function Block: '<S27>/UART Tx3' (stm32f4_usart) */
      enable_record_and_send_via_UARTSubsystem3UARTTx3();
      ADXL_recorder_fast1_DWork.Subsystem3_MODE = true;
    }

    /* S-Function (stm32f4_usart): '<S27>/UART Tx3' */

    /* record_and_send_via_UARTSubsystem3UARTTx3: '<S27>/UART Tx3' */
    {
      /* Flush tx, so we can put data directly to DMA buffer */
      UART3_FlushTxBuffer();

      /* Put data into buffer */
      UART3_Tx_Buffer[0] = 126;        /* Header 0 */
      UART3_Tx_Buffer[1] = 126;        /* Header 1 */
      memcpy(&UART3_Tx_Buffer[2], &ADXL_recorder_fast1_B.Queue_o1[0], sizeof
             (real32_T));              /* Data 0 */
      memcpy(&UART3_Tx_Buffer[6], &ADXL_recorder_fast1_B.Queue_o1[1], sizeof
             (real32_T));              /* Data 1 */
      memcpy(&UART3_Tx_Buffer[10], &ADXL_recorder_fast1_B.Queue_o1[2], sizeof
             (real32_T));              /* Data 2 */
      memcpy(&UART3_Tx_Buffer[14], &ADXL_recorder_fast1_B.Queue_o1[3], sizeof
             (real32_T));              /* Data 3 */
      UART3_Tx_Buffer[18] = 3;         /* Terminator 0 */
      UART3_Tx_Buffer[19] = 3;         /* Terminator 1 */

      /* Write to DMA, 20 bytes */
      UART3_TxUpdate(20);              /* Only update since data is ready on Tx buffer */
    }
  } else {
    if (ADXL_recorder_fast1_DWork.Subsystem3_MODE) {
      ADXL_recorder_fast1_DWork.Subsystem3_MODE = false;
    }
  }

  /* End of Logic: '<S7>/Logical Operator5' */
  /* End of Outputs for SubSystem: '<S7>/Subsystem3' */

  /* Outputs for Enabled SubSystem: '<S7>/set flag=0' incorporates:
   *  EnablePort: '<S28>/Enable'
   */
  /* Logic: '<S7>/Logical Operator6' incorporates:
   *  Logic: '<S7>/Logical Operator2'
   *  Logic: '<S7>/Logical Operator3'
   */
  if ((ADXL_recorder_fast1_B.Compare_i && rtb_Queue_o2) ||
      (ADXL_recorder_fast1_B.Compare && rtb_Queue_o3)) {
    if (!ADXL_recorder_fast1_DWork.setflag0_MODE) {
      ADXL_recorder_fast1_DWork.setflag0_MODE = true;
    }

    if (ADXL_recorder_fast1_M->Timing.TaskCounters.TID[2] == 0) {
      /* S-Function (waijung_vdata_write): '<S28>/Volatile Data Storage Write' incorporates:
       *  Constant: '<S28>/Constant'
       */

      /* record_and_send_via_UARTsetflag0VolatileDataStorageWrite */
      VolatileDataStorage3_flag = (uint8_t)
        ADXL_recorder_fast1_P.Constant_Value_e;
    }
  } else {
    if (ADXL_recorder_fast1_DWork.setflag0_MODE) {
      ADXL_recorder_fast1_DWork.setflag0_MODE = false;
    }
  }

  /* End of Logic: '<S7>/Logical Operator6' */
  /* End of Outputs for SubSystem: '<S7>/set flag=0' */

  /* Gain: '<S9>/Gain' incorporates:
   *  Abs: '<S9>/Abs'
   */
  ADXL_recorder_fast1_B.PWM_VC2 = ADXL_recorder_fast1_P.Gain_Gain * fabs
    (rtb_DiscreteFilter1);

  /* Gain: '<S9>/Gain1' incorporates:
   *  Abs: '<S9>/Abs1'
   */
  ADXL_recorder_fast1_B.PWM_VC1 = ADXL_recorder_fast1_P.Gain1_Gain * fabs
    (ADXL_recorder_fast1_B.DiscreteFilter3);

  /* S-Function (waijung_vdata_read): '<S9>/Volatile Data Storage Read3' */

  /* wigglerVolatileDataStorageRead3 */
  ADXL_recorder_fast1_B.Laser = (float)VolatileDataStorage1_Laser;

  /* DataTypeConversion: '<S9>/Data Type Conversion' */
  ADXL_recorder_fast1_B.DataTypeConversion = ADXL_recorder_fast1_B.Laser;

  /* S-Function (stm32f4_basicpwm): '<S9>/Basic PWM' */

  /* S-Function Block: <S9>/Basic PWM (stm32f4_basicpwm) */
  TIM3->CCR2 = (uint32_t) (ADXL_recorder_fast1_B.PWM_VC2 * wigglerBasicPWM_SF);
  TIM3->CCR3 = (uint32_t) (ADXL_recorder_fast1_B.PWM_VC1 * wigglerBasicPWM_SF);
  TIM3->CCR4 = (uint32_t) (ADXL_recorder_fast1_B.DataTypeConversion *
    wigglerBasicPWM_SF);

  /* RelationalOperator: '<S38>/Compare' incorporates:
   *  Constant: '<S38>/Constant'
   */
  ADXL_recorder_fast1_B.Compare_i4 = (rtb_DiscreteFilter1 <
    ADXL_recorder_fast1_P.CompareToConstant2_const);

  /* RelationalOperator: '<S37>/Compare' incorporates:
   *  Constant: '<S37>/Constant'
   */
  ADXL_recorder_fast1_B.Compare_a = (ADXL_recorder_fast1_B.DiscreteFilter3 >
    ADXL_recorder_fast1_P.CompareToConstant1_const);

  /* S-Function (stm32f4_digital_output): '<S9>/Digital Output1' */

  /* wigglerDigitalOutput1 */
  {
    *wigglerDigitalOutput1_F13 = ADXL_recorder_fast1_B.Compare_i4;
    *wigglerDigitalOutput1_F14 = ADXL_recorder_fast1_B.Compare_a;
  }

  /* S-Function (stm32f4_digital_output): '<S9>/Digital Output2' */

  /* wigglerDigitalOutput2 */
  {
    *wigglerDigitalOutput2_D0 = (boolean_T)
      ADXL_recorder_fast1_B.DiscreteFilter3;
    *wigglerDigitalOutput2_D7 = ADXL_recorder_fast1_B.Compare_a;
  }

  /* S-Function (waijung_vdata_read): '<Root>/Volatile Data Storage Read5' */

  /* VolatileDataStorageRead5 */
  ADXL_recorder_fast1_B.VolatileDataStorageRead5 = (double)
    VolatileDataStorage7_vcyPWMamp;

  /* S-Function (waijung_vdata_read): '<Root>/Volatile Data Storage Read6' */

  /* VolatileDataStorageRead6 */
  ADXL_recorder_fast1_B.VolatileDataStorageRead6 = (double)
    VolatileDataStorage2_vcxPWMamp;

  /* S-Function (waijung_vdata_read): '<Root>/Volatile Data Storage Read4' */

  /* VolatileDataStorageRead4 */
  ADXL_recorder_fast1_B.VolatileDataStorageRead4 = (double)
    VolatileDataStorage8_vcyPWMfreq;

  /* Math: '<S11>/Math Function' incorporates:
   *  Constant: '<S11>/Modulo 2*pi'
   *  Gain: '<S11>/Center Frequency'
   *  Gain: '<S14>/Gain'
   *  Product: '<S14>/Product'
   *  SampleTimeMath: '<S11>/Weighted Sample Time'
   *  Sum: '<S11>/Sum1'
   *  UnitDelay: '<S11>/Unit Delay'
   *
   * About '<S11>/Weighted Sample Time':
   *  y = K where K = ( w * Ts )
   */
  rtb_DiscreteFilter1 = rt_modd_snf((ADXL_recorder_fast1_P.Gain_Gain_h *
    ADXL_recorder_fast1_B.VolatileDataStorageRead4 *
    ADXL_recorder_fast1_P.WeightedSampleTime_WtEt +
    ADXL_recorder_fast1_P.CenterFrequency_Gain *
    ADXL_recorder_fast1_P.WeightedSampleTime_WtEt) +
    ADXL_recorder_fast1_DWork.UnitDelay_DSTATE,
    ADXL_recorder_fast1_P.Modulo2pi_Value);

  /* S-Function (waijung_vdata_read): '<Root>/Volatile Data Storage Read2' */

  /* VolatileDataStorageRead2 */
  ADXL_recorder_fast1_B.VolatileDataStorageRead2 = (double)
    VolatileDataStorage6_vcxPWMfreq;

  /* Math: '<S15>/Math Function' incorporates:
   *  Constant: '<S15>/Modulo 2*pi'
   *  Gain: '<S15>/Center Frequency'
   *  Gain: '<S18>/Gain'
   *  Product: '<S18>/Product'
   *  SampleTimeMath: '<S15>/Weighted Sample Time'
   *  Sum: '<S15>/Sum1'
   *  UnitDelay: '<S15>/Unit Delay'
   *
   * About '<S15>/Weighted Sample Time':
   *  y = K where K = ( w * Ts )
   */
  rtb_Sum1 = rt_modd_snf((ADXL_recorder_fast1_P.Gain_Gain_o *
    ADXL_recorder_fast1_B.VolatileDataStorageRead2 *
    ADXL_recorder_fast1_P.WeightedSampleTime_WtEt_b +
    ADXL_recorder_fast1_P.CenterFrequency_Gain_d *
    ADXL_recorder_fast1_P.WeightedSampleTime_WtEt_b) +
    ADXL_recorder_fast1_DWork.UnitDelay_DSTATE_e,
    ADXL_recorder_fast1_P.Modulo2pi_Value_h);

  /* S-Function (waijung_vdata_read): '<Root>/Volatile Data Storage Read1' */

  /* VolatileDataStorageRead1 */
  ADXL_recorder_fast1_B.VolatileDataStorageRead1 = (uint8_t)
    VolatileDataStorage4_VCflag;

  /* Switch: '<Root>/Switch' incorporates:
   *  Constant: '<Root>/Constant2'
   *  Gain: '<S15>/Sensitivity3'
   *  Product: '<Root>/Product1'
   *  Switch: '<S4>/Switch2'
   *  Trigonometry: '<S15>/Trigonometric Function'
   *  UnitDelay: '<S15>/Unit Delay'
   */
  if (ADXL_recorder_fast1_B.VolatileDataStorageRead1 >
      ADXL_recorder_fast1_P.Switch_Threshold) {
    Switch = ADXL_recorder_fast1_P.Constant2_Value_i;
  } else {
    if (ADXL_recorder_fast1_P.DiscreteTimeVCO_Ac * cos
        (ADXL_recorder_fast1_DWork.UnitDelay_DSTATE_e) >
        ADXL_recorder_fast1_P.Switch2_Threshold) {
      /* Switch: '<S4>/Switch2' incorporates:
       *  Constant: '<S4>/Constant5'
       */
      Switch1 = ADXL_recorder_fast1_P.Constant5_Value;
    } else {
      /* Switch: '<S4>/Switch2' incorporates:
       *  Constant: '<S4>/Constant6'
       */
      Switch1 = ADXL_recorder_fast1_P.Constant6_Value;
    }

    Switch = Switch1 * ADXL_recorder_fast1_B.VolatileDataStorageRead6;
  }

  /* End of Switch: '<Root>/Switch' */

  /* S-Function (waijung_vdata_read): '<Root>/Volatile Data Storage Read3' */

  /* VolatileDataStorageRead3 */
  ADXL_recorder_fast1_B.VolatileDataStorageRead3 = (uint8_t)
    VolatileDataStorage5_vcflag2;

  /* Switch: '<Root>/Switch1' incorporates:
   *  Constant: '<Root>/Constant4'
   *  Gain: '<S11>/Sensitivity3'
   *  Product: '<Root>/Product'
   *  Switch: '<S3>/Switch1'
   *  Trigonometry: '<S11>/Trigonometric Function'
   *  UnitDelay: '<S11>/Unit Delay'
   */
  if (ADXL_recorder_fast1_B.VolatileDataStorageRead3 >
      ADXL_recorder_fast1_P.Switch1_Threshold_g) {
    Switch1 = ADXL_recorder_fast1_P.Constant4_Value;
  } else {
    if (ADXL_recorder_fast1_P.DiscreteTimeVCO1_Ac * cos
        (ADXL_recorder_fast1_DWork.UnitDelay_DSTATE) >
        ADXL_recorder_fast1_P.Switch1_Threshold) {
      /* Switch: '<S3>/Switch1' incorporates:
       *  Constant: '<S3>/Constant2'
       */
      Switch1 = ADXL_recorder_fast1_P.Constant2_Value;
    } else {
      /* Switch: '<S3>/Switch1' incorporates:
       *  Constant: '<S3>/Constant3'
       */
      Switch1 = ADXL_recorder_fast1_P.Constant3_Value;
    }

    Switch1 *= ADXL_recorder_fast1_B.VolatileDataStorageRead5;
  }

  /* End of Switch: '<Root>/Switch1' */

  /* DataTypeConversion: '<S8>/Data Type Conversion1' incorporates:
   *  Delay: '<S8>/Wait for Buffer to clear3'
   */
  ADXL_recorder_fast1_B.DataTypeConversion1 =
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear3_DSTATE[0];

  /* Outputs for Enabled SubSystem: '<S8>/Set UART vc Flag=4' incorporates:
   *  EnablePort: '<S32>/Enable'
   */
  /* Delay: '<S8>/Wait for Buffer to clear 3' */
  if (ADXL_recorder_fast1_DWork.WaitforBuffertoclear3_DSTATE_h[0U] > 0) {
    if (!ADXL_recorder_fast1_DWork.SetUARTvcFlag4_MODE) {
      ADXL_recorder_fast1_DWork.SetUARTvcFlag4_MODE = true;
    }

    /* S-Function (waijung_vdata_write): '<S32>/Volatile Data Storage Write' */

    /* set_UART_VCflagSetUARTvcFlag4VolatileDataStorageWrite */
    VolatileDataStorage2_vcxPWMamp = (double)
      ADXL_recorder_fast1_B.DataTypeConversion1;
  } else {
    if (ADXL_recorder_fast1_DWork.SetUARTvcFlag4_MODE) {
      ADXL_recorder_fast1_DWork.SetUARTvcFlag4_MODE = false;
    }
  }

  /* End of Delay: '<S8>/Wait for Buffer to clear 3' */
  /* End of Outputs for SubSystem: '<S8>/Set UART vc Flag=4' */

  /* RateTransition: '<S8>/Rate Transition7' */
  if (ADXL_recorder_fast1_M->Timing.TaskCounters.TID[1] == 0) {
    ADXL_recorder_fast1_B.RateTransition7 =
      ADXL_recorder_fast1_DWork.RateTransition7_Buffer0;

    /* RateTransition: '<S8>/Rate Transition8' */
    ADXL_recorder_fast1_B.RateTransition8 =
      ADXL_recorder_fast1_DWork.RateTransition8_Buffer0;

    /* S-Function (stm32f4_usart): '<S8>/UART Rx4' */

    /* set_UART_VCflagUARTRx4: '<S8>/UART Rx4' */
    if (set_UART_VCflagUARTRx4_Receive(&UART3_Temp_Buffer[0], URX3_BUFFER_SIZE))
    {                                  /* Non-Blocking */
      ADXL_recorder_fast1_B.UARTRx4_o2 = set_UART_VCflagUARTRx4_data0;/* D0 */
      ADXL_recorder_fast1_B.UARTRx4_o1 = 1;/* READY */
    } else {
      ADXL_recorder_fast1_B.UARTRx4_o1 = 0;/* Not READY */
    }
  }

  /* End of RateTransition: '<S8>/Rate Transition7' */

  /* DataTypeConversion: '<S8>/Data Type Conversion2' incorporates:
   *  Delay: '<S8>/Wait for Buffer to clear4'
   */
  ADXL_recorder_fast1_B.DataTypeConversion2 =
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear4_DSTATE[0];

  /* Outputs for Enabled SubSystem: '<S8>/Set UART vc Flag=5' incorporates:
   *  EnablePort: '<S33>/Enable'
   */
  /* Delay: '<S8>/Wait for Buffer to clear 4' */
  if (ADXL_recorder_fast1_DWork.WaitforBuffertoclear4_DSTATE_c[0U] > 0) {
    if (!ADXL_recorder_fast1_DWork.SetUARTvcFlag5_MODE) {
      ADXL_recorder_fast1_DWork.SetUARTvcFlag5_MODE = true;
    }

    /* S-Function (waijung_vdata_write): '<S33>/Volatile Data Storage Write' */

    /* set_UART_VCflagSetUARTvcFlag5VolatileDataStorageWrite */
    VolatileDataStorage6_vcxPWMfreq = (double)
      ADXL_recorder_fast1_B.DataTypeConversion2;
  } else {
    if (ADXL_recorder_fast1_DWork.SetUARTvcFlag5_MODE) {
      ADXL_recorder_fast1_DWork.SetUARTvcFlag5_MODE = false;
    }
  }

  /* End of Delay: '<S8>/Wait for Buffer to clear 4' */
  /* End of Outputs for SubSystem: '<S8>/Set UART vc Flag=5' */

  /* RateTransition: '<S8>/Rate Transition10' */
  if (ADXL_recorder_fast1_M->Timing.TaskCounters.TID[1] == 0) {
    ADXL_recorder_fast1_B.RateTransition10 =
      ADXL_recorder_fast1_DWork.RateTransition10_Buffer0;

    /* RateTransition: '<S8>/Rate Transition9' */
    ADXL_recorder_fast1_B.RateTransition9 =
      ADXL_recorder_fast1_DWork.RateTransition9_Buffer0;

    /* S-Function (stm32f4_usart): '<S8>/UART Rx5' */

    /* set_UART_VCflagUARTRx5: '<S8>/UART Rx5' */
    if (set_UART_VCflagUARTRx5_Receive(&UART3_Temp_Buffer[0], URX3_BUFFER_SIZE))
    {                                  /* Non-Blocking */
      ADXL_recorder_fast1_B.UARTRx5_o2 = set_UART_VCflagUARTRx5_data0;/* D0 */
      ADXL_recorder_fast1_B.UARTRx5_o1 = 1;/* READY */
    } else {
      ADXL_recorder_fast1_B.UARTRx5_o1 = 0;/* Not READY */
    }
  }

  /* End of RateTransition: '<S8>/Rate Transition10' */

  /* DataTypeConversion: '<S8>/Data Type Conversion3' incorporates:
   *  Delay: '<S8>/Wait for Buffer to clear5'
   */
  ADXL_recorder_fast1_B.DataTypeConversion3 =
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear5_DSTATE[0];

  /* Outputs for Enabled SubSystem: '<S8>/Set UART vc Flag=7' incorporates:
   *  EnablePort: '<S35>/Enable'
   */
  /* Delay: '<S8>/Wait for Buffer to clear 6' */
  if (ADXL_recorder_fast1_DWork.WaitforBuffertoclear6_DSTATE_o[0U] > 0) {
    if (!ADXL_recorder_fast1_DWork.SetUARTvcFlag7_MODE) {
      ADXL_recorder_fast1_DWork.SetUARTvcFlag7_MODE = true;
    }

    /* S-Function (waijung_vdata_write): '<S35>/Volatile Data Storage Write' */

    /* set_UART_VCflagSetUARTvcFlag7VolatileDataStorageWrite */
    VolatileDataStorage8_vcyPWMfreq = (double)
      ADXL_recorder_fast1_B.DataTypeConversion3;
  } else {
    if (ADXL_recorder_fast1_DWork.SetUARTvcFlag7_MODE) {
      ADXL_recorder_fast1_DWork.SetUARTvcFlag7_MODE = false;
    }
  }

  /* End of Delay: '<S8>/Wait for Buffer to clear 6' */
  /* End of Outputs for SubSystem: '<S8>/Set UART vc Flag=7' */

  /* RateTransition: '<S8>/Rate Transition13' */
  if (ADXL_recorder_fast1_M->Timing.TaskCounters.TID[1] == 0) {
    ADXL_recorder_fast1_B.RateTransition13 =
      ADXL_recorder_fast1_DWork.RateTransition13_Buffer0;

    /* RateTransition: '<S8>/Rate Transition14' */
    ADXL_recorder_fast1_B.RateTransition14 =
      ADXL_recorder_fast1_DWork.RateTransition14_Buffer0;

    /* S-Function (stm32f4_usart): '<S8>/UART Rx7' */

    /* set_UART_VCflagUARTRx7: '<S8>/UART Rx7' */
    if (set_UART_VCflagUARTRx7_Receive(&UART3_Temp_Buffer[0], URX3_BUFFER_SIZE))
    {                                  /* Non-Blocking */
      ADXL_recorder_fast1_B.UARTRx7_o2 = set_UART_VCflagUARTRx7_data0;/* D0 */
      ADXL_recorder_fast1_B.UARTRx7_o1 = 1;/* READY */
    } else {
      ADXL_recorder_fast1_B.UARTRx7_o1 = 0;/* Not READY */
    }
  }

  /* End of RateTransition: '<S8>/Rate Transition13' */

  /* DataTypeConversion: '<S8>/Data Type Conversion5' incorporates:
   *  Delay: '<S8>/Wait for Buffer to clear6'
   */
  ADXL_recorder_fast1_B.DataTypeConversion5 =
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear6_DSTATE[0];

  /* Outputs for Enabled SubSystem: '<S8>/Set UART vc Flag=6' incorporates:
   *  EnablePort: '<S34>/Enable'
   */
  /* Delay: '<S8>/Wait for Buffer to clear 5' */
  if (ADXL_recorder_fast1_DWork.WaitforBuffertoclear5_DSTATE_b[0U] > 0) {
    if (!ADXL_recorder_fast1_DWork.SetUARTvcFlag6_MODE) {
      ADXL_recorder_fast1_DWork.SetUARTvcFlag6_MODE = true;
    }

    /* S-Function (waijung_vdata_write): '<S34>/Volatile Data Storage Write' */

    /* set_UART_VCflagSetUARTvcFlag6VolatileDataStorageWrite */
    VolatileDataStorage7_vcyPWMamp = (double)
      ADXL_recorder_fast1_B.DataTypeConversion5;
  } else {
    if (ADXL_recorder_fast1_DWork.SetUARTvcFlag6_MODE) {
      ADXL_recorder_fast1_DWork.SetUARTvcFlag6_MODE = false;
    }
  }

  /* End of Delay: '<S8>/Wait for Buffer to clear 5' */
  /* End of Outputs for SubSystem: '<S8>/Set UART vc Flag=6' */

  /* RateTransition: '<S8>/Rate Transition11' */
  if (ADXL_recorder_fast1_M->Timing.TaskCounters.TID[1] == 0) {
    ADXL_recorder_fast1_B.RateTransition11 =
      ADXL_recorder_fast1_DWork.RateTransition11_Buffer0;

    /* RateTransition: '<S8>/Rate Transition12' */
    ADXL_recorder_fast1_B.RateTransition12 =
      ADXL_recorder_fast1_DWork.RateTransition12_Buffer0;

    /* S-Function (stm32f4_usart): '<S8>/UART Rx6' */

    /* set_UART_VCflagUARTRx6: '<S8>/UART Rx6' */
    if (set_UART_VCflagUARTRx6_Receive(&UART3_Temp_Buffer[0], URX3_BUFFER_SIZE))
    {                                  /* Non-Blocking */
      ADXL_recorder_fast1_B.UARTRx6_o2 = set_UART_VCflagUARTRx6_data0;/* D0 */
      ADXL_recorder_fast1_B.UARTRx6_o1 = 1;/* READY */
    } else {
      ADXL_recorder_fast1_B.UARTRx6_o1 = 0;/* Not READY */
    }
  }

  /* End of RateTransition: '<S8>/Rate Transition11' */

  /* Outputs for Enabled SubSystem: '<S8>/Set UART vc Flag=2' incorporates:
   *  EnablePort: '<S30>/Enable'
   */
  /* Delay: '<S8>/Wait for Buffer to clear 1' */
  if (ADXL_recorder_fast1_DWork.WaitforBuffertoclear1_DSTATE_p[0U] > 0) {
    if (!ADXL_recorder_fast1_DWork.SetUARTvcFlag2_MODE) {
      ADXL_recorder_fast1_DWork.SetUARTvcFlag2_MODE = true;
    }

    /* DataTypeConversion: '<S30>/Data Type Conversion' incorporates:
     *  Delay: '<S8>/Wait for Buffer to clear1'
     */
    ADXL_recorder_fast1_B.DataTypeConversion_m = (uint8_T)
      ADXL_recorder_fast1_DWork.WaitforBuffertoclear1_DSTATE[0];
    if (ADXL_recorder_fast1_M->Timing.TaskCounters.TID[1] == 0) {
      /* S-Function (waijung_vdata_write): '<S30>/Volatile Data Storage Write' */

      /* set_UART_VCflagSetUARTvcFlag2VolatileDataStorageWrite */
      VolatileDataStorage5_vcflag2 = (uint8_t)
        ADXL_recorder_fast1_B.DataTypeConversion_m;
    }
  } else {
    if (ADXL_recorder_fast1_DWork.SetUARTvcFlag2_MODE) {
      ADXL_recorder_fast1_DWork.SetUARTvcFlag2_MODE = false;
    }
  }

  /* End of Delay: '<S8>/Wait for Buffer to clear 1' */
  /* End of Outputs for SubSystem: '<S8>/Set UART vc Flag=2' */

  /* RateTransition: '<S8>/Rate Transition1' */
  if (ADXL_recorder_fast1_M->Timing.TaskCounters.TID[1] == 0) {
    ADXL_recorder_fast1_B.RateTransition1 =
      ADXL_recorder_fast1_DWork.RateTransition1_Buffer0;

    /* RateTransition: '<S8>/Rate Transition3' */
    ADXL_recorder_fast1_B.RateTransition3 =
      ADXL_recorder_fast1_DWork.RateTransition3_Buffer0;

    /* S-Function (stm32f4_usart): '<S8>/UART Rx1' */

    /* set_UART_VCflagUARTRx1: '<S8>/UART Rx1' */
    if (set_UART_VCflagUARTRx1_Receive(&UART3_Temp_Buffer[0], URX3_BUFFER_SIZE))
    {                                  /* Non-Blocking */
      ADXL_recorder_fast1_B.UARTRx1_o2 = set_UART_VCflagUARTRx1_data0;/* D0 */
      ADXL_recorder_fast1_B.UARTRx1_o1 = 1;/* READY */
    } else {
      ADXL_recorder_fast1_B.UARTRx1_o1 = 0;/* Not READY */
    }
  }

  /* End of RateTransition: '<S8>/Rate Transition1' */

  /* Outputs for Enabled SubSystem: '<S8>/Set UART vc Flag=1' incorporates:
   *  EnablePort: '<S29>/Enable'
   */
  /* Delay: '<S8>/Wait for Buffer to clear ' */
  if (ADXL_recorder_fast1_DWork.WaitforBuffertoclear_DSTATE_k[0U] > 0) {
    if (!ADXL_recorder_fast1_DWork.SetUARTvcFlag1_MODE) {
      ADXL_recorder_fast1_DWork.SetUARTvcFlag1_MODE = true;
    }

    /* DataTypeConversion: '<S29>/Data Type Conversion' incorporates:
     *  Delay: '<S8>/Wait for Buffer to clear'
     */
    ADXL_recorder_fast1_B.DataTypeConversion_a = (uint8_T)
      ADXL_recorder_fast1_DWork.WaitforBuffertoclear_DSTATE[0];
    if (ADXL_recorder_fast1_M->Timing.TaskCounters.TID[1] == 0) {
      /* S-Function (waijung_vdata_write): '<S29>/Volatile Data Storage Write' */

      /* set_UART_VCflagSetUARTvcFlag1VolatileDataStorageWrite */
      VolatileDataStorage4_VCflag = (uint8_t)
        ADXL_recorder_fast1_B.DataTypeConversion_a;
    }
  } else {
    if (ADXL_recorder_fast1_DWork.SetUARTvcFlag1_MODE) {
      ADXL_recorder_fast1_DWork.SetUARTvcFlag1_MODE = false;
    }
  }

  /* End of Delay: '<S8>/Wait for Buffer to clear ' */
  /* End of Outputs for SubSystem: '<S8>/Set UART vc Flag=1' */

  /* RateTransition: '<S8>/Rate Transition2' */
  if (ADXL_recorder_fast1_M->Timing.TaskCounters.TID[1] == 0) {
    ADXL_recorder_fast1_B.RateTransition2 =
      ADXL_recorder_fast1_DWork.RateTransition2_Buffer0;

    /* RateTransition: '<S8>/Rate Transition4' */
    ADXL_recorder_fast1_B.RateTransition4 =
      ADXL_recorder_fast1_DWork.RateTransition4_Buffer0;

    /* S-Function (stm32f4_usart): '<S8>/UART Rx' */

    /* set_UART_VCflagUARTRx: '<S8>/UART Rx' */
    if (set_UART_VCflagUARTRx_Receive(&UART3_Temp_Buffer[0], URX3_BUFFER_SIZE))
    {                                  /* Non-Blocking */
      ADXL_recorder_fast1_B.UARTRx_o2 = set_UART_VCflagUARTRx_data0;/* D0 */
      ADXL_recorder_fast1_B.UARTRx_o1 = 1;/* READY */
    } else {
      ADXL_recorder_fast1_B.UARTRx_o1 = 0;/* Not READY */
    }
  }

  /* End of RateTransition: '<S8>/Rate Transition2' */

  /* Delay: '<S8>/Wait for Buffer to clear2' */
  ADXL_recorder_fast1_B.WaitforBuffertoclear2 =
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear2_DSTATE[0];

  /* Outputs for Enabled SubSystem: '<S8>/Set UART vc Flag=3' incorporates:
   *  EnablePort: '<S31>/Enable'
   */
  /* Delay: '<S8>/Wait for Buffer to clear 2' */
  if (ADXL_recorder_fast1_DWork.WaitforBuffertoclear2_DSTATE_l[0U] > 0) {
    if (!ADXL_recorder_fast1_DWork.SetUARTvcFlag3_MODE) {
      ADXL_recorder_fast1_DWork.SetUARTvcFlag3_MODE = true;
    }

    /* S-Function (waijung_vdata_write): '<S31>/Volatile Data Storage Write' */

    /* set_UART_VCflagSetUARTvcFlag3VolatileDataStorageWrite */
    VolatileDataStorage1_Laser = (float)
      ADXL_recorder_fast1_B.WaitforBuffertoclear2;
  } else {
    if (ADXL_recorder_fast1_DWork.SetUARTvcFlag3_MODE) {
      ADXL_recorder_fast1_DWork.SetUARTvcFlag3_MODE = false;
    }
  }

  /* End of Delay: '<S8>/Wait for Buffer to clear 2' */
  /* End of Outputs for SubSystem: '<S8>/Set UART vc Flag=3' */

  /* RateTransition: '<S8>/Rate Transition5' */
  if (ADXL_recorder_fast1_M->Timing.TaskCounters.TID[1] == 0) {
    ADXL_recorder_fast1_B.RateTransition5 =
      ADXL_recorder_fast1_DWork.RateTransition5_Buffer0;

    /* RateTransition: '<S8>/Rate Transition6' */
    ADXL_recorder_fast1_B.RateTransition6 =
      ADXL_recorder_fast1_DWork.RateTransition6_Buffer0;

    /* S-Function (stm32f4_usart): '<S8>/UART Rx2' */

    /* set_UART_VCflagUARTRx2: '<S8>/UART Rx2' */
    if (set_UART_VCflagUARTRx2_Receive(&UART3_Temp_Buffer[0], URX3_BUFFER_SIZE))
    {                                  /* Non-Blocking */
      ADXL_recorder_fast1_B.UARTRx2_o2 = set_UART_VCflagUARTRx2_data0;/* D0 */
      ADXL_recorder_fast1_B.UARTRx2_o1 = 1;/* READY */
    } else {
      ADXL_recorder_fast1_B.UARTRx2_o1 = 0;/* Not READY */
    }

    /* S-Function (stm32f4_usart): '<S8>/UART Rx3' */

    /* set_UART_VCflagUARTRx3: '<S8>/UART Rx3' */
    if (set_UART_VCflagUARTRx3_Receive(&UART3_Temp_Buffer[0], URX3_BUFFER_SIZE))
    {                                  /* Non-Blocking */
      ADXL_recorder_fast1_B.UARTRx3_o2 = set_UART_VCflagUARTRx3_data0;/* D0 */
      ADXL_recorder_fast1_B.UARTRx3_o1 = 1;/* READY */
    } else {
      ADXL_recorder_fast1_B.UARTRx3_o1 = 0;/* Not READY */
    }

    /* Outputs for Enabled SubSystem: '<S8>/flag_setting' incorporates:
     *  EnablePort: '<S36>/Enable'
     */
    if (ADXL_recorder_fast1_B.UARTRx3_o1 > 0) {
      if (!ADXL_recorder_fast1_DWork.flag_setting_MODE) {
        ADXL_recorder_fast1_DWork.flag_setting_MODE = true;
      }

      /* DataTypeConversion: '<S36>/Data Type Conversion' */
      ADXL_recorder_fast1_B.DataTypeConversion_j = (uint8_T)
        ADXL_recorder_fast1_B.UARTRx3_o2;

      /* S-Function (waijung_vdata_write): '<S36>/Volatile Data Storage Write' */

      /* set_UART_VCflagflag_settingVolatileDataStorageWrite */
      VolatileDataStorage3_flag = (uint8_t)
        ADXL_recorder_fast1_B.DataTypeConversion_j;
    } else {
      if (ADXL_recorder_fast1_DWork.flag_setting_MODE) {
        ADXL_recorder_fast1_DWork.flag_setting_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S8>/flag_setting' */
  }

  /* End of RateTransition: '<S8>/Rate Transition5' */
  if (ADXL_recorder_fast1_M->Timing.TaskCounters.TID[1] == 0) {
    /* Update for Delay: '<S5>/Delay2' */
    ADXL_recorder_fast1_DWork.Delay2_DSTATE = rtb_Switch2_h;

    /* Update for Delay: '<S6>/Delay2' */
    ADXL_recorder_fast1_DWork.Delay2_DSTATE_c = rtb_Switch2_p;
  }

  for (j = 0; j < 499; j++) {
    /* Update for DiscreteFilter: '<Root>/Discrete Filter1' */
    ADXL_recorder_fast1_DWork.DiscreteFilter1_states[499 - j] =
      ADXL_recorder_fast1_DWork.DiscreteFilter1_states[498 - j];

    /* Update for DiscreteFilter: '<Root>/Discrete Filter3' */
    ADXL_recorder_fast1_DWork.DiscreteFilter3_states[499 - j] =
      ADXL_recorder_fast1_DWork.DiscreteFilter3_states[498 - j];
  }

  /* Update for DiscreteFilter: '<Root>/Discrete Filter1' */
  ADXL_recorder_fast1_DWork.DiscreteFilter1_states[0] = Switch /
    ADXL_recorder_fast1_P.DiscreteFilter1_DenCoef;

  /* Update for DiscreteFilter: '<Root>/Discrete Filter3' */
  ADXL_recorder_fast1_DWork.DiscreteFilter3_states[0] = Switch1 /
    ADXL_recorder_fast1_P.DiscreteFilter3_DenCoef;

  /* Update for UnitDelay: '<S11>/Unit Delay' */
  ADXL_recorder_fast1_DWork.UnitDelay_DSTATE = rtb_DiscreteFilter1;

  /* Update for UnitDelay: '<S15>/Unit Delay' */
  ADXL_recorder_fast1_DWork.UnitDelay_DSTATE_e = rtb_Sum1;

  /* Update for Delay: '<S8>/Wait for Buffer to clear3' */
  ADXL_recorder_fast1_DWork.WaitforBuffertoclear3_DSTATE[0] =
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear3_DSTATE[1];
  ADXL_recorder_fast1_DWork.WaitforBuffertoclear3_DSTATE[1] =
    ADXL_recorder_fast1_B.RateTransition7;

  /* Update for Delay: '<S8>/Wait for Buffer to clear 3' */
  ADXL_recorder_fast1_DWork.WaitforBuffertoclear3_DSTATE_h[0] =
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear3_DSTATE_h[1];
  ADXL_recorder_fast1_DWork.WaitforBuffertoclear3_DSTATE_h[1] =
    ADXL_recorder_fast1_B.RateTransition8;

  /* Update for RateTransition: '<S8>/Rate Transition7' incorporates:
   *  RateTransition: '<S8>/Rate Transition10'
   */
  if (ADXL_recorder_fast1_M->Timing.TaskCounters.TID[1] == 0) {
    ADXL_recorder_fast1_DWork.RateTransition7_Buffer0 =
      ADXL_recorder_fast1_B.UARTRx4_o2;

    /* Update for RateTransition: '<S8>/Rate Transition8' */
    ADXL_recorder_fast1_DWork.RateTransition8_Buffer0 =
      ADXL_recorder_fast1_B.UARTRx4_o1;
    ADXL_recorder_fast1_DWork.RateTransition10_Buffer0 =
      ADXL_recorder_fast1_B.UARTRx5_o1;

    /* Update for RateTransition: '<S8>/Rate Transition9' */
    ADXL_recorder_fast1_DWork.RateTransition9_Buffer0 =
      ADXL_recorder_fast1_B.UARTRx5_o2;
  }

  /* End of Update for RateTransition: '<S8>/Rate Transition7' */

  /* Update for Delay: '<S8>/Wait for Buffer to clear4' */
  ADXL_recorder_fast1_DWork.WaitforBuffertoclear4_DSTATE[0] =
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear4_DSTATE[1];
  ADXL_recorder_fast1_DWork.WaitforBuffertoclear4_DSTATE[1] =
    ADXL_recorder_fast1_B.RateTransition9;

  /* Update for Delay: '<S8>/Wait for Buffer to clear 4' */
  ADXL_recorder_fast1_DWork.WaitforBuffertoclear4_DSTATE_c[0] =
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear4_DSTATE_c[1];
  ADXL_recorder_fast1_DWork.WaitforBuffertoclear4_DSTATE_c[1] =
    ADXL_recorder_fast1_B.RateTransition10;

  /* Update for Delay: '<S8>/Wait for Buffer to clear5' */
  ADXL_recorder_fast1_DWork.WaitforBuffertoclear5_DSTATE[0] =
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear5_DSTATE[1];
  ADXL_recorder_fast1_DWork.WaitforBuffertoclear5_DSTATE[1] =
    ADXL_recorder_fast1_B.RateTransition13;

  /* Update for Delay: '<S8>/Wait for Buffer to clear 6' */
  ADXL_recorder_fast1_DWork.WaitforBuffertoclear6_DSTATE_o[0] =
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear6_DSTATE_o[1];
  ADXL_recorder_fast1_DWork.WaitforBuffertoclear6_DSTATE_o[1] =
    ADXL_recorder_fast1_B.RateTransition14;

  /* Update for RateTransition: '<S8>/Rate Transition13' incorporates:
   *  RateTransition: '<S8>/Rate Transition11'
   */
  if (ADXL_recorder_fast1_M->Timing.TaskCounters.TID[1] == 0) {
    ADXL_recorder_fast1_DWork.RateTransition13_Buffer0 =
      ADXL_recorder_fast1_B.UARTRx7_o2;

    /* Update for RateTransition: '<S8>/Rate Transition14' */
    ADXL_recorder_fast1_DWork.RateTransition14_Buffer0 =
      ADXL_recorder_fast1_B.UARTRx7_o1;
    ADXL_recorder_fast1_DWork.RateTransition11_Buffer0 =
      ADXL_recorder_fast1_B.UARTRx6_o2;

    /* Update for RateTransition: '<S8>/Rate Transition12' */
    ADXL_recorder_fast1_DWork.RateTransition12_Buffer0 =
      ADXL_recorder_fast1_B.UARTRx6_o1;
  }

  /* End of Update for RateTransition: '<S8>/Rate Transition13' */

  /* Update for Delay: '<S8>/Wait for Buffer to clear6' */
  ADXL_recorder_fast1_DWork.WaitforBuffertoclear6_DSTATE[0] =
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear6_DSTATE[1];
  ADXL_recorder_fast1_DWork.WaitforBuffertoclear6_DSTATE[1] =
    ADXL_recorder_fast1_B.RateTransition11;

  /* Update for Delay: '<S8>/Wait for Buffer to clear 5' */
  ADXL_recorder_fast1_DWork.WaitforBuffertoclear5_DSTATE_b[0] =
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear5_DSTATE_b[1];
  ADXL_recorder_fast1_DWork.WaitforBuffertoclear5_DSTATE_b[1] =
    ADXL_recorder_fast1_B.RateTransition12;

  /* Update for Delay: '<S8>/Wait for Buffer to clear1' */
  ADXL_recorder_fast1_DWork.WaitforBuffertoclear1_DSTATE[0] =
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear1_DSTATE[1];
  ADXL_recorder_fast1_DWork.WaitforBuffertoclear1_DSTATE[1] =
    ADXL_recorder_fast1_B.RateTransition3;

  /* Update for Delay: '<S8>/Wait for Buffer to clear 1' */
  ADXL_recorder_fast1_DWork.WaitforBuffertoclear1_DSTATE_p[0] =
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear1_DSTATE_p[1];
  ADXL_recorder_fast1_DWork.WaitforBuffertoclear1_DSTATE_p[1] =
    ADXL_recorder_fast1_B.RateTransition1;

  /* Update for RateTransition: '<S8>/Rate Transition1' incorporates:
   *  RateTransition: '<S8>/Rate Transition2'
   */
  if (ADXL_recorder_fast1_M->Timing.TaskCounters.TID[1] == 0) {
    ADXL_recorder_fast1_DWork.RateTransition1_Buffer0 =
      ADXL_recorder_fast1_B.UARTRx1_o1;

    /* Update for RateTransition: '<S8>/Rate Transition3' */
    ADXL_recorder_fast1_DWork.RateTransition3_Buffer0 =
      ADXL_recorder_fast1_B.UARTRx1_o2;
    ADXL_recorder_fast1_DWork.RateTransition2_Buffer0 =
      ADXL_recorder_fast1_B.UARTRx_o1;

    /* Update for RateTransition: '<S8>/Rate Transition4' */
    ADXL_recorder_fast1_DWork.RateTransition4_Buffer0 =
      ADXL_recorder_fast1_B.UARTRx_o2;
  }

  /* End of Update for RateTransition: '<S8>/Rate Transition1' */

  /* Update for Delay: '<S8>/Wait for Buffer to clear' */
  ADXL_recorder_fast1_DWork.WaitforBuffertoclear_DSTATE[0] =
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear_DSTATE[1];
  ADXL_recorder_fast1_DWork.WaitforBuffertoclear_DSTATE[1] =
    ADXL_recorder_fast1_B.RateTransition4;

  /* Update for Delay: '<S8>/Wait for Buffer to clear ' */
  ADXL_recorder_fast1_DWork.WaitforBuffertoclear_DSTATE_k[0] =
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear_DSTATE_k[1];
  ADXL_recorder_fast1_DWork.WaitforBuffertoclear_DSTATE_k[1] =
    ADXL_recorder_fast1_B.RateTransition2;

  /* Update for Delay: '<S8>/Wait for Buffer to clear2' */
  ADXL_recorder_fast1_DWork.WaitforBuffertoclear2_DSTATE[0] =
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear2_DSTATE[1];
  ADXL_recorder_fast1_DWork.WaitforBuffertoclear2_DSTATE[1] =
    ADXL_recorder_fast1_B.RateTransition6;

  /* Update for Delay: '<S8>/Wait for Buffer to clear 2' */
  ADXL_recorder_fast1_DWork.WaitforBuffertoclear2_DSTATE_l[0] =
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear2_DSTATE_l[1];
  ADXL_recorder_fast1_DWork.WaitforBuffertoclear2_DSTATE_l[1] =
    ADXL_recorder_fast1_B.RateTransition5;

  /* Update for RateTransition: '<S8>/Rate Transition5' */
  if (ADXL_recorder_fast1_M->Timing.TaskCounters.TID[1] == 0) {
    ADXL_recorder_fast1_DWork.RateTransition5_Buffer0 =
      ADXL_recorder_fast1_B.UARTRx2_o1;

    /* Update for RateTransition: '<S8>/Rate Transition6' */
    ADXL_recorder_fast1_DWork.RateTransition6_Buffer0 =
      ADXL_recorder_fast1_B.UARTRx2_o2;
  }

  /* End of Update for RateTransition: '<S8>/Rate Transition5' */
  rate_scheduler();
}

/* Model initialize function */
void ADXL_recorder_fast1_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)ADXL_recorder_fast1_M, 0,
                sizeof(RT_MODEL_ADXL_recorder_fast1));

  /* block I/O */
  (void) memset(((void *) &ADXL_recorder_fast1_B), 0,
                sizeof(BlockIO_ADXL_recorder_fast1));

  /* states (dwork) */
  (void) memset((void *)&ADXL_recorder_fast1_DWork, 0,
                sizeof(D_Work_ADXL_recorder_fast1));

  {
    int32_T i;
    ADXL_record_MedianFilter1_Start(&ADXL_recorder_fast1_DWork.MedianFilter);

    /* Start for MATLABSystem: '<Root>/Median Filter1' */
    ADXL_record_MedianFilter1_Start(&ADXL_recorder_fast1_DWork.MedianFilter1);

    /* Start for RateTransition: '<S8>/Rate Transition7' */
    ADXL_recorder_fast1_B.RateTransition7 =
      ADXL_recorder_fast1_P.RateTransition7_InitialConditio;

    /* Start for RateTransition: '<S8>/Rate Transition8' */
    ADXL_recorder_fast1_B.RateTransition8 =
      ADXL_recorder_fast1_P.RateTransition8_InitialConditio;

    /* Start for RateTransition: '<S8>/Rate Transition10' */
    ADXL_recorder_fast1_B.RateTransition10 =
      ADXL_recorder_fast1_P.RateTransition10_InitialConditi;

    /* Start for RateTransition: '<S8>/Rate Transition9' */
    ADXL_recorder_fast1_B.RateTransition9 =
      ADXL_recorder_fast1_P.RateTransition9_InitialConditio;

    /* Start for RateTransition: '<S8>/Rate Transition13' */
    ADXL_recorder_fast1_B.RateTransition13 =
      ADXL_recorder_fast1_P.RateTransition13_InitialConditi;

    /* Start for RateTransition: '<S8>/Rate Transition14' */
    ADXL_recorder_fast1_B.RateTransition14 =
      ADXL_recorder_fast1_P.RateTransition14_InitialConditi;

    /* Start for RateTransition: '<S8>/Rate Transition11' */
    ADXL_recorder_fast1_B.RateTransition11 =
      ADXL_recorder_fast1_P.RateTransition11_InitialConditi;

    /* Start for RateTransition: '<S8>/Rate Transition12' */
    ADXL_recorder_fast1_B.RateTransition12 =
      ADXL_recorder_fast1_P.RateTransition12_InitialConditi;

    /* Start for RateTransition: '<S8>/Rate Transition1' */
    ADXL_recorder_fast1_B.RateTransition1 =
      ADXL_recorder_fast1_P.RateTransition1_InitialConditio;

    /* Start for RateTransition: '<S8>/Rate Transition3' */
    ADXL_recorder_fast1_B.RateTransition3 =
      ADXL_recorder_fast1_P.RateTransition3_InitialConditio;

    /* Start for RateTransition: '<S8>/Rate Transition2' */
    ADXL_recorder_fast1_B.RateTransition2 =
      ADXL_recorder_fast1_P.RateTransition2_InitialConditio;

    /* Start for RateTransition: '<S8>/Rate Transition4' */
    ADXL_recorder_fast1_B.RateTransition4 =
      ADXL_recorder_fast1_P.RateTransition4_InitialConditio;

    /* Start for RateTransition: '<S8>/Rate Transition5' */
    ADXL_recorder_fast1_B.RateTransition5 =
      ADXL_recorder_fast1_P.RateTransition5_InitialConditio;

    /* Start for RateTransition: '<S8>/Rate Transition6' */
    ADXL_recorder_fast1_B.RateTransition6 =
      ADXL_recorder_fast1_P.RateTransition6_InitialConditio;

    /* Start for S-Function (waijung_vdata_storage): '<Root>/Volatile Data Storage1' */

    /* S-Function Block: <Root>/Volatile Data Storage1 */
    VolatileDataStorage1_Laser = 90.0;

    /* Start for S-Function (waijung_vdata_storage): '<Root>/Volatile Data Storage2' */

    /* S-Function Block: <Root>/Volatile Data Storage2 */
    VolatileDataStorage2_vcxPWMamp = 50.0;

    /* Start for S-Function (waijung_vdata_storage): '<Root>/Volatile Data Storage3' */

    /* S-Function Block: <Root>/Volatile Data Storage3 */
    VolatileDataStorage3_flag = 0.0;

    /* Start for S-Function (waijung_vdata_storage): '<Root>/Volatile Data Storage4' */

    /* S-Function Block: <Root>/Volatile Data Storage4 */
    VolatileDataStorage4_VCflag = 2.0;

    /* Start for S-Function (waijung_vdata_storage): '<Root>/Volatile Data Storage5' */

    /* S-Function Block: <Root>/Volatile Data Storage5 */
    VolatileDataStorage5_vcflag2 = 2.0;

    /* Start for S-Function (waijung_vdata_storage): '<Root>/Volatile Data Storage6' */

    /* S-Function Block: <Root>/Volatile Data Storage6 */
    VolatileDataStorage6_vcxPWMfreq = 0.25;

    /* Start for S-Function (waijung_vdata_storage): '<Root>/Volatile Data Storage7' */

    /* S-Function Block: <Root>/Volatile Data Storage7 */
    VolatileDataStorage7_vcyPWMamp = 45.0;

    /* Start for S-Function (waijung_vdata_storage): '<Root>/Volatile Data Storage8' */

    /* S-Function Block: <Root>/Volatile Data Storage8 */
    VolatileDataStorage8_vcyPWMfreq = 0.25;

    /* InitializeConditions for Delay: '<S5>/Delay2' */
    ADXL_recorder_fast1_DWork.Delay2_DSTATE =
      ADXL_recorder_fast1_P.Delay2_InitialCondition;

    /* InitializeConditions for Delay: '<S6>/Delay2' */
    ADXL_recorder_fast1_DWork.Delay2_DSTATE_c =
      ADXL_recorder_fast1_P.Delay2_InitialCondition_h;
    for (i = 0; i < 500; i++) {
      /* InitializeConditions for DiscreteFilter: '<Root>/Discrete Filter1' */
      ADXL_recorder_fast1_DWork.DiscreteFilter1_states[i] =
        ADXL_recorder_fast1_P.DiscreteFilter1_InitialStates;

      /* InitializeConditions for DiscreteFilter: '<Root>/Discrete Filter3' */
      ADXL_recorder_fast1_DWork.DiscreteFilter3_states[i] =
        ADXL_recorder_fast1_P.DiscreteFilter3_InitialStates;
    }

    /* InitializeConditions for DiscretePulseGenerator: '<Root>/recording_clock' */
    ADXL_recorder_fast1_DWork.clockTickCounter = 0;

    /* InitializeConditions for DiscretePulseGenerator: '<Root>/send_2_uart_clock' */
    ADXL_recorder_fast1_DWork.clockTickCounter_b = 0;

    /* InitializeConditions for S-Function (sdspstacknqueue): '<S7>/Queue' */

    /* DSP System Toolbox Queue (sdspstacknqueue) - '<S7>/Queue' */
    /* Initialize event port handler previous signal state: */
    ADXL_recorder_fast1_DWork.Queue_EPH0PrevState = EVENT_PORT_STATE_UNINIT;

    /* Initialize event port handler previous signal state: */
    ADXL_recorder_fast1_DWork.Queue_EPH1PrevState = EVENT_PORT_STATE_UNINIT;

    /* Initialize event port handler previous signal state: */
    ADXL_recorder_fast1_DWork.Queue_EPH2PrevState = EVENT_PORT_STATE_UNINIT;

    {
      ADXL_recorder_fast1_DWork.Queue_QueueFrontIdx =
        ADXL_recorder_fast1_DWork.Queue_QueueBackIdx =
        ADXL_recorder_fast1_DWork.Queue_NumElements = 0;
      memset(&ADXL_recorder_fast1_B.Queue_o1[0], 0, sizeof(real32_T)*4);/* Set output values to zero */
    }

    /* InitializeConditions for UnitDelay: '<S11>/Unit Delay' */
    ADXL_recorder_fast1_DWork.UnitDelay_DSTATE =
      ADXL_recorder_fast1_P.DiscreteTimeVCO1_Ph;

    /* InitializeConditions for UnitDelay: '<S15>/Unit Delay' */
    ADXL_recorder_fast1_DWork.UnitDelay_DSTATE_e =
      ADXL_recorder_fast1_P.DiscreteTimeVCO_Ph;

    /* InitializeConditions for RateTransition: '<S8>/Rate Transition7' */
    ADXL_recorder_fast1_DWork.RateTransition7_Buffer0 =
      ADXL_recorder_fast1_P.RateTransition7_InitialConditio;

    /* InitializeConditions for RateTransition: '<S8>/Rate Transition8' */
    ADXL_recorder_fast1_DWork.RateTransition8_Buffer0 =
      ADXL_recorder_fast1_P.RateTransition8_InitialConditio;

    /* InitializeConditions for RateTransition: '<S8>/Rate Transition10' */
    ADXL_recorder_fast1_DWork.RateTransition10_Buffer0 =
      ADXL_recorder_fast1_P.RateTransition10_InitialConditi;

    /* InitializeConditions for RateTransition: '<S8>/Rate Transition9' */
    ADXL_recorder_fast1_DWork.RateTransition9_Buffer0 =
      ADXL_recorder_fast1_P.RateTransition9_InitialConditio;

    /* InitializeConditions for RateTransition: '<S8>/Rate Transition13' */
    ADXL_recorder_fast1_DWork.RateTransition13_Buffer0 =
      ADXL_recorder_fast1_P.RateTransition13_InitialConditi;

    /* InitializeConditions for RateTransition: '<S8>/Rate Transition14' */
    ADXL_recorder_fast1_DWork.RateTransition14_Buffer0 =
      ADXL_recorder_fast1_P.RateTransition14_InitialConditi;

    /* InitializeConditions for RateTransition: '<S8>/Rate Transition11' */
    ADXL_recorder_fast1_DWork.RateTransition11_Buffer0 =
      ADXL_recorder_fast1_P.RateTransition11_InitialConditi;

    /* InitializeConditions for RateTransition: '<S8>/Rate Transition12' */
    ADXL_recorder_fast1_DWork.RateTransition12_Buffer0 =
      ADXL_recorder_fast1_P.RateTransition12_InitialConditi;

    /* InitializeConditions for RateTransition: '<S8>/Rate Transition1' */
    ADXL_recorder_fast1_DWork.RateTransition1_Buffer0 =
      ADXL_recorder_fast1_P.RateTransition1_InitialConditio;

    /* InitializeConditions for RateTransition: '<S8>/Rate Transition3' */
    ADXL_recorder_fast1_DWork.RateTransition3_Buffer0 =
      ADXL_recorder_fast1_P.RateTransition3_InitialConditio;

    /* InitializeConditions for RateTransition: '<S8>/Rate Transition2' */
    ADXL_recorder_fast1_DWork.RateTransition2_Buffer0 =
      ADXL_recorder_fast1_P.RateTransition2_InitialConditio;

    /* InitializeConditions for RateTransition: '<S8>/Rate Transition4' */
    ADXL_recorder_fast1_DWork.RateTransition4_Buffer0 =
      ADXL_recorder_fast1_P.RateTransition4_InitialConditio;

    /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear3' */
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear3_DSTATE[0] =
      ADXL_recorder_fast1_P.WaitforBuffertoclear3_InitialCo;

    /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear 3' */
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear3_DSTATE_h[0] =
      ADXL_recorder_fast1_P.WaitforBuffertoclear3_Initial_o;

    /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear4' */
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear4_DSTATE[0] =
      ADXL_recorder_fast1_P.WaitforBuffertoclear4_InitialCo;

    /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear 4' */
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear4_DSTATE_c[0] =
      ADXL_recorder_fast1_P.WaitforBuffertoclear4_Initial_j;

    /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear5' */
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear5_DSTATE[0] =
      ADXL_recorder_fast1_P.WaitforBuffertoclear5_InitialCo;

    /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear 6' */
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear6_DSTATE_o[0] =
      ADXL_recorder_fast1_P.WaitforBuffertoclear6_Initial_m;

    /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear6' */
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear6_DSTATE[0] =
      ADXL_recorder_fast1_P.WaitforBuffertoclear6_InitialCo;

    /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear 5' */
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear5_DSTATE_b[0] =
      ADXL_recorder_fast1_P.WaitforBuffertoclear5_Initial_p;

    /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear1' */
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear1_DSTATE[0] =
      ADXL_recorder_fast1_P.WaitforBuffertoclear1_InitialCo;

    /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear 1' */
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear1_DSTATE_p[0] =
      ADXL_recorder_fast1_P.WaitforBuffertoclear1_Initial_i;

    /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear' */
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear_DSTATE[0] =
      ADXL_recorder_fast1_P.WaitforBuffertoclear_InitialCon;

    /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear ' */
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear_DSTATE_k[0] =
      ADXL_recorder_fast1_P.WaitforBuffertoclear_InitialC_a;

    /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear2' */
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear2_DSTATE[0] =
      ADXL_recorder_fast1_P.WaitforBuffertoclear2_InitialCo;

    /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear 2' */
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear2_DSTATE_l[0] =
      ADXL_recorder_fast1_P.WaitforBuffertoclear2_Initial_l;

    /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear3' */
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear3_DSTATE[1] =
      ADXL_recorder_fast1_P.WaitforBuffertoclear3_InitialCo;

    /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear 3' */
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear3_DSTATE_h[1] =
      ADXL_recorder_fast1_P.WaitforBuffertoclear3_Initial_o;

    /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear4' */
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear4_DSTATE[1] =
      ADXL_recorder_fast1_P.WaitforBuffertoclear4_InitialCo;

    /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear 4' */
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear4_DSTATE_c[1] =
      ADXL_recorder_fast1_P.WaitforBuffertoclear4_Initial_j;

    /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear5' */
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear5_DSTATE[1] =
      ADXL_recorder_fast1_P.WaitforBuffertoclear5_InitialCo;

    /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear 6' */
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear6_DSTATE_o[1] =
      ADXL_recorder_fast1_P.WaitforBuffertoclear6_Initial_m;

    /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear6' */
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear6_DSTATE[1] =
      ADXL_recorder_fast1_P.WaitforBuffertoclear6_InitialCo;

    /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear 5' */
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear5_DSTATE_b[1] =
      ADXL_recorder_fast1_P.WaitforBuffertoclear5_Initial_p;

    /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear1' */
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear1_DSTATE[1] =
      ADXL_recorder_fast1_P.WaitforBuffertoclear1_InitialCo;

    /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear 1' */
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear1_DSTATE_p[1] =
      ADXL_recorder_fast1_P.WaitforBuffertoclear1_Initial_i;

    /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear' */
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear_DSTATE[1] =
      ADXL_recorder_fast1_P.WaitforBuffertoclear_InitialCon;

    /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear ' */
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear_DSTATE_k[1] =
      ADXL_recorder_fast1_P.WaitforBuffertoclear_InitialC_a;

    /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear2' */
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear2_DSTATE[1] =
      ADXL_recorder_fast1_P.WaitforBuffertoclear2_InitialCo;

    /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear 2' */
    ADXL_recorder_fast1_DWork.WaitforBuffertoclear2_DSTATE_l[1] =
      ADXL_recorder_fast1_P.WaitforBuffertoclear2_Initial_l;

    /* InitializeConditions for RateTransition: '<S8>/Rate Transition5' */
    ADXL_recorder_fast1_DWork.RateTransition5_Buffer0 =
      ADXL_recorder_fast1_P.RateTransition5_InitialConditio;

    /* InitializeConditions for RateTransition: '<S8>/Rate Transition6' */
    ADXL_recorder_fast1_DWork.RateTransition6_Buffer0 =
      ADXL_recorder_fast1_P.RateTransition6_InitialConditio;
    ADXL_recorde_MedianFilter1_Init(&ADXL_recorder_fast1_DWork.MedianFilter);
    ADXL_recorde_MedianFilter1_Init(&ADXL_recorder_fast1_DWork.MedianFilter1);

    /* Enable for S-Function (stm32f4_usart): '<Root>/UART Setup' */
    /* Level2 S-Function Block: '<Root>/UART Setup' (stm32f4_usart) */
    enable_UARTSetup();

    /* Enable for S-Function (stm32f4_digital_output): '<S7>/DC_enable' */
    /* Level2 S-Function Block: '<S7>/DC_enable' (stm32f4_digital_output) */
    enable_record_and_send_via_UARTDC_enable();

    /* Enable for S-Function (stm32f4_pwm_capture): '<Root>/PWM chX' */
    /* Level2 S-Function Block: '<Root>/PWM chX' (stm32f4_pwm_capture) */
    enable_PWMchX();

    /* Enable for S-Function (stm32f4_pwm_capture): '<Root>/PWM chY' */
    /* Level2 S-Function Block: '<Root>/PWM chY' (stm32f4_pwm_capture) */
    enable_PWMchY();

    /* Enable for S-Function (stm32f4_basicpwm): '<S9>/Basic PWM' */
    /* Level2 S-Function Block: '<S9>/Basic PWM' (stm32f4_basicpwm) */
    enable_wigglerBasicPWM();

    /* Enable for S-Function (stm32f4_digital_output): '<S9>/Digital Output1' */
    /* Level2 S-Function Block: '<S9>/Digital Output1' (stm32f4_digital_output) */
    enable_wigglerDigitalOutput1();

    /* Enable for S-Function (stm32f4_digital_output): '<S9>/Digital Output2' */
    /* Level2 S-Function Block: '<S9>/Digital Output2' (stm32f4_digital_output) */
    enable_wigglerDigitalOutput2();

    /* Enable for S-Function (stm32f4_usart): '<S8>/UART Rx4' */
    /* Level2 S-Function Block: '<S8>/UART Rx4' (stm32f4_usart) */
    enable_set_UART_VCflagUARTRx4();

    /* Enable for S-Function (stm32f4_usart): '<S8>/UART Rx5' */
    /* Level2 S-Function Block: '<S8>/UART Rx5' (stm32f4_usart) */
    enable_set_UART_VCflagUARTRx5();

    /* Enable for S-Function (stm32f4_usart): '<S8>/UART Rx7' */
    /* Level2 S-Function Block: '<S8>/UART Rx7' (stm32f4_usart) */
    enable_set_UART_VCflagUARTRx7();

    /* Enable for S-Function (stm32f4_usart): '<S8>/UART Rx6' */
    /* Level2 S-Function Block: '<S8>/UART Rx6' (stm32f4_usart) */
    enable_set_UART_VCflagUARTRx6();

    /* Enable for S-Function (stm32f4_usart): '<S8>/UART Rx1' */
    /* Level2 S-Function Block: '<S8>/UART Rx1' (stm32f4_usart) */
    enable_set_UART_VCflagUARTRx1();

    /* Enable for S-Function (stm32f4_usart): '<S8>/UART Rx' */
    /* Level2 S-Function Block: '<S8>/UART Rx' (stm32f4_usart) */
    enable_set_UART_VCflagUARTRx();

    /* Enable for S-Function (stm32f4_usart): '<S8>/UART Rx2' */
    /* Level2 S-Function Block: '<S8>/UART Rx2' (stm32f4_usart) */
    enable_set_UART_VCflagUARTRx2();

    /* Enable for S-Function (stm32f4_usart): '<S8>/UART Rx3' */
    /* Level2 S-Function Block: '<S8>/UART Rx3' (stm32f4_usart) */
    enable_set_UART_VCflagUARTRx3();
  }
}

/* Model terminate function */
void ADXL_recorder_fast1_terminate(void)
{
  /* Terminate for S-Function (stm32f4_digital_output): '<S7>/DC_enable' */

  /* terminate_record_and_send_via_UARTDC_enable(); */
  ADXL_recorde_MedianFilter1_Term(&ADXL_recorder_fast1_DWork.MedianFilter);

  /* Terminate for MATLABSystem: '<Root>/Median Filter1' */
  ADXL_recorde_MedianFilter1_Term(&ADXL_recorder_fast1_DWork.MedianFilter1);

  /* Terminate for S-Function (stm32f4_basicpwm): '<S9>/Basic PWM' */

  /* terminate_wigglerBasicPWM(); */

  /* Terminate for S-Function (stm32f4_digital_output): '<S9>/Digital Output1' */

  /* terminate_wigglerDigitalOutput1(); */

  /* Terminate for S-Function (stm32f4_digital_output): '<S9>/Digital Output2' */

  /* terminate_wigglerDigitalOutput2(); */
}

/* [EOF] */
