/*
 * File: ADXL_recorder_fast1.h
 *
 * Created with Waijung Blockset
 *
 * Real-Time Workshop code generated for Simulink model ADXL_recorder_fast1.
 *
 * Model version                        : 1.124
 * Real-Time Workshop file version      : 8.14 (R2018a) 06-Feb-2018
 * Real-Time Workshop file generated on : Sun Jul 21 13:42:21 2019
 * TLC version                          : 8.14 (Feb 22 2018)
 * C/C++ source code generated on       : Sun Jul 21 13:42:30 2019
 *
 * Target selection: stm32f4.tlc
 * Embedded hardware selection: ARM Compatible->Cortex - M4
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_ADXL_recorder_fast1_h_
#define RTW_HEADER_ADXL_recorder_fast1_h_
#include <float.h>
#include <math.h>
#include <string.h>
#ifndef ADXL_recorder_fast1_COMMON_INCLUDES_
# define ADXL_recorder_fast1_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "waijung_hwdrvlib.h"
#endif                                 /* ADXL_recorder_fast1_COMMON_INCLUDES_ */

#include "ADXL_recorder_fast1_types.h"
#include "rt_nonfinite.h"
#include "rtGetInf.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

/* Block signals for system '<Root>/Median Filter1' */
typedef struct {
  real32_T MedianFilter1;              /* '<Root>/Median Filter1' */
} rtB_MedianFilter1_ADXL_recorder;

/* Block states (default storage) for system '<Root>/Median Filter1' */
typedef struct {
  dsp_MedianFilter_ADXL_recorder_ obj; /* '<Root>/Median Filter1' */
  boolean_T objisempty;                /* '<Root>/Median Filter1' */
} rtDW_MedianFilter1_ADXL_recorde;

/* Block signals (default storage) */
typedef struct {
  real_T DiscreteFilter3;              /* '<Root>/Discrete Filter3' */
  real_T PWM_VC2;                      /* '<S9>/Gain' */
  real_T PWM_VC1;                      /* '<S9>/Gain1' */
  real_T DataTypeConversion;           /* '<S9>/Data Type Conversion' */
  real_T VolatileDataStorageRead5;     /* '<Root>/Volatile Data Storage Read5' */
  real_T VolatileDataStorageRead6;     /* '<Root>/Volatile Data Storage Read6' */
  real_T VolatileDataStorageRead4;     /* '<Root>/Volatile Data Storage Read4' */
  real_T VolatileDataStorageRead2;     /* '<Root>/Volatile Data Storage Read2' */
  real_T DataTypeConversion1;          /* '<S8>/Data Type Conversion1' */
  real_T DataTypeConversion2;          /* '<S8>/Data Type Conversion2' */
  real_T DataTypeConversion3;          /* '<S8>/Data Type Conversion3' */
  real_T DataTypeConversion5;          /* '<S8>/Data Type Conversion5' */
  uint32_T RateTransition3;            /* '<S8>/Rate Transition3' */
  uint32_T UARTRx1_o2;                 /* '<S8>/UART Rx1' */
  uint32_T RateTransition4;            /* '<S8>/Rate Transition4' */
  uint32_T UARTRx_o2;                  /* '<S8>/UART Rx' */
  uint32_T UARTRx3_o2;                 /* '<S8>/UART Rx3' */
  real32_T PWMchX_o2;                  /* '<Root>/PWM chX' */
  real32_T PWMchX_o3;                  /* '<Root>/PWM chX' */
  real32_T PWMchX_o4;                  /* '<Root>/PWM chX' */
  real32_T IndexVector;                /* '<Root>/Index Vector' */
  real32_T PWMchY_o2;                  /* '<Root>/PWM chY' */
  real32_T PWMchY_o3;                  /* '<Root>/PWM chY' */
  real32_T PWMchY_o4;                  /* '<Root>/PWM chY' */
  real32_T IndexVector1;               /* '<Root>/Index Vector1' */
  real32_T Queue_o1[4];                /* '<S7>/Queue' */
  real32_T Laser;                      /* '<S9>/Volatile Data Storage Read3' */
  real32_T RateTransition7;            /* '<S8>/Rate Transition7' */
  real32_T UARTRx4_o2;                 /* '<S8>/UART Rx4' */
  real32_T RateTransition9;            /* '<S8>/Rate Transition9' */
  real32_T UARTRx5_o2;                 /* '<S8>/UART Rx5' */
  real32_T RateTransition13;           /* '<S8>/Rate Transition13' */
  real32_T UARTRx7_o2;                 /* '<S8>/UART Rx7' */
  real32_T RateTransition11;           /* '<S8>/Rate Transition11' */
  real32_T UARTRx6_o2;                 /* '<S8>/UART Rx6' */
  real32_T WaitforBuffertoclear2;      /* '<S8>/Wait for Buffer to clear2' */
  real32_T RateTransition6;            /* '<S8>/Rate Transition6' */
  real32_T UARTRx2_o2;                 /* '<S8>/UART Rx2' */
  uint8_T flag_for_recorder_uart;      /* '<Root>/flag_for_recorder_uart' */
  uint8_T PWMchX_o1;                   /* '<Root>/PWM chX' */
  uint8_T PWMchY_o1;                   /* '<Root>/PWM chY' */
  uint8_T VolatileDataStorageRead1;    /* '<Root>/Volatile Data Storage Read1' */
  uint8_T VolatileDataStorageRead3;    /* '<Root>/Volatile Data Storage Read3' */
  uint8_T RateTransition8;             /* '<S8>/Rate Transition8' */
  uint8_T UARTRx4_o1;                  /* '<S8>/UART Rx4' */
  uint8_T RateTransition10;            /* '<S8>/Rate Transition10' */
  uint8_T UARTRx5_o1;                  /* '<S8>/UART Rx5' */
  uint8_T RateTransition14;            /* '<S8>/Rate Transition14' */
  uint8_T UARTRx7_o1;                  /* '<S8>/UART Rx7' */
  uint8_T RateTransition12;            /* '<S8>/Rate Transition12' */
  uint8_T UARTRx6_o1;                  /* '<S8>/UART Rx6' */
  uint8_T RateTransition1;             /* '<S8>/Rate Transition1' */
  uint8_T UARTRx1_o1;                  /* '<S8>/UART Rx1' */
  uint8_T RateTransition2;             /* '<S8>/Rate Transition2' */
  uint8_T UARTRx_o1;                   /* '<S8>/UART Rx' */
  uint8_T RateTransition5;             /* '<S8>/Rate Transition5' */
  uint8_T UARTRx2_o1;                  /* '<S8>/UART Rx2' */
  uint8_T UARTRx3_o1;                  /* '<S8>/UART Rx3' */
  uint8_T DataTypeConversion_j;        /* '<S36>/Data Type Conversion' */
  uint8_T DataTypeConversion_m;        /* '<S30>/Data Type Conversion' */
  uint8_T DataTypeConversion_a;        /* '<S29>/Data Type Conversion' */
  boolean_T Compare;                   /* '<S23>/Compare' */
  boolean_T Compare_i;                 /* '<S24>/Compare' */
  boolean_T Compare_d;                 /* '<S25>/Compare' */
  boolean_T Compare_i4;                /* '<S38>/Compare' */
  boolean_T Compare_a;                 /* '<S37>/Compare' */
  rtB_MedianFilter1_ADXL_recorder MedianFilter;/* '<Root>/Median Filter1' */
  rtB_MedianFilter1_ADXL_recorder MedianFilter1;/* '<Root>/Median Filter1' */
} BlockIO_ADXL_recorder_fast1;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  real_T DiscreteFilter1_states[500];  /* '<Root>/Discrete Filter1' */
  real_T DiscreteFilter3_states[500];  /* '<Root>/Discrete Filter3' */
  real_T UnitDelay_DSTATE;             /* '<S11>/Unit Delay' */
  real_T UnitDelay_DSTATE_e;           /* '<S15>/Unit Delay' */
  real32_T Delay2_DSTATE;              /* '<S5>/Delay2' */
  real32_T Delay2_DSTATE_c;            /* '<S6>/Delay2' */
  real32_T WaitforBuffertoclear3_DSTATE[2];/* '<S8>/Wait for Buffer to clear3' */
  real32_T WaitforBuffertoclear4_DSTATE[2];/* '<S8>/Wait for Buffer to clear4' */
  real32_T WaitforBuffertoclear5_DSTATE[2];/* '<S8>/Wait for Buffer to clear5' */
  real32_T WaitforBuffertoclear6_DSTATE[2];/* '<S8>/Wait for Buffer to clear6' */
  real32_T WaitforBuffertoclear2_DSTATE[2];/* '<S8>/Wait for Buffer to clear2' */
  uint32_T WaitforBuffertoclear1_DSTATE[2];/* '<S8>/Wait for Buffer to clear1' */
  uint32_T WaitforBuffertoclear_DSTATE[2];/* '<S8>/Wait for Buffer to clear' */
  real32_T Queue_BufferPtr[24000];     /* '<S7>/Queue' */
  real32_T RateTransition7_Buffer0;    /* '<S8>/Rate Transition7' */
  real32_T RateTransition9_Buffer0;    /* '<S8>/Rate Transition9' */
  real32_T RateTransition13_Buffer0;   /* '<S8>/Rate Transition13' */
  real32_T RateTransition11_Buffer0;   /* '<S8>/Rate Transition11' */
  real32_T RateTransition6_Buffer0;    /* '<S8>/Rate Transition6' */
  int32_T clockTickCounter;            /* '<Root>/recording_clock' */
  int32_T clockTickCounter_b;          /* '<Root>/send_2_uart_clock' */
  uint32_T Queue_EPH0PrevState;        /* '<S7>/Queue' */
  uint32_T Queue_EPH1PrevState;        /* '<S7>/Queue' */
  uint32_T Queue_EPH2PrevState;        /* '<S7>/Queue' */
  uint32_T Queue_QueueFrontIdx;        /* '<S7>/Queue' */
  uint32_T Queue_NumElements;          /* '<S7>/Queue' */
  uint32_T Queue_QueueBackIdx;         /* '<S7>/Queue' */
  uint32_T RateTransition3_Buffer0;    /* '<S8>/Rate Transition3' */
  uint32_T RateTransition4_Buffer0;    /* '<S8>/Rate Transition4' */
  uint8_T WaitforBuffertoclear3_DSTATE_h[2];/* '<S8>/Wait for Buffer to clear 3' */
  uint8_T WaitforBuffertoclear4_DSTATE_c[2];/* '<S8>/Wait for Buffer to clear 4' */
  uint8_T WaitforBuffertoclear6_DSTATE_o[2];/* '<S8>/Wait for Buffer to clear 6' */
  uint8_T WaitforBuffertoclear5_DSTATE_b[2];/* '<S8>/Wait for Buffer to clear 5' */
  uint8_T WaitforBuffertoclear1_DSTATE_p[2];/* '<S8>/Wait for Buffer to clear 1' */
  uint8_T WaitforBuffertoclear_DSTATE_k[2];/* '<S8>/Wait for Buffer to clear ' */
  uint8_T WaitforBuffertoclear2_DSTATE_l[2];/* '<S8>/Wait for Buffer to clear 2' */
  uint8_T RateTransition8_Buffer0;     /* '<S8>/Rate Transition8' */
  uint8_T RateTransition10_Buffer0;    /* '<S8>/Rate Transition10' */
  uint8_T RateTransition14_Buffer0;    /* '<S8>/Rate Transition14' */
  uint8_T RateTransition12_Buffer0;    /* '<S8>/Rate Transition12' */
  uint8_T RateTransition1_Buffer0;     /* '<S8>/Rate Transition1' */
  uint8_T RateTransition2_Buffer0;     /* '<S8>/Rate Transition2' */
  uint8_T RateTransition5_Buffer0;     /* '<S8>/Rate Transition5' */
  boolean_T flag_setting_MODE;         /* '<S8>/flag_setting' */
  boolean_T SetUARTvcFlag7_MODE;       /* '<S8>/Set UART vc Flag=7' */
  boolean_T SetUARTvcFlag6_MODE;       /* '<S8>/Set UART vc Flag=6' */
  boolean_T SetUARTvcFlag5_MODE;       /* '<S8>/Set UART vc Flag=5' */
  boolean_T SetUARTvcFlag4_MODE;       /* '<S8>/Set UART vc Flag=4' */
  boolean_T SetUARTvcFlag3_MODE;       /* '<S8>/Set UART vc Flag=3' */
  boolean_T SetUARTvcFlag2_MODE;       /* '<S8>/Set UART vc Flag=2' */
  boolean_T SetUARTvcFlag1_MODE;       /* '<S8>/Set UART vc Flag=1' */
  boolean_T setflag0_MODE;             /* '<S7>/set flag=0' */
  boolean_T Subsystem3_MODE;           /* '<S7>/Subsystem3' */
  rtDW_MedianFilter1_ADXL_recorde MedianFilter;/* '<Root>/Median Filter1' */
  rtDW_MedianFilter1_ADXL_recorde MedianFilter1;/* '<Root>/Median Filter1' */
} D_Work_ADXL_recorder_fast1;

/* Parameters (default storage) */
struct Parameters_ADXL_recorder_fast1_ {
  real_T DiscreteTimeVCO1_Ac;          /* Mask Parameter: DiscreteTimeVCO1_Ac
                                        * Referenced by: '<S11>/Sensitivity3'
                                        */
  real_T DiscreteTimeVCO_Ac;           /* Mask Parameter: DiscreteTimeVCO_Ac
                                        * Referenced by: '<S15>/Sensitivity3'
                                        */
  real_T DiscreteTimeVCO1_Ph;          /* Mask Parameter: DiscreteTimeVCO1_Ph
                                        * Referenced by: '<S11>/Unit Delay'
                                        */
  real_T DiscreteTimeVCO_Ph;           /* Mask Parameter: DiscreteTimeVCO_Ph
                                        * Referenced by: '<S15>/Unit Delay'
                                        */
  real_T CompareToConstant2_const;     /* Mask Parameter: CompareToConstant2_const
                                        * Referenced by: '<S38>/Constant'
                                        */
  real_T CompareToConstant1_const;     /* Mask Parameter: CompareToConstant1_const
                                        * Referenced by: '<S37>/Constant'
                                        */
  real32_T CompareToConstant8_const;   /* Mask Parameter: CompareToConstant8_const
                                        * Referenced by: '<S20>/Constant'
                                        */
  real32_T CompareToConstant10_const;  /* Mask Parameter: CompareToConstant10_const
                                        * Referenced by: '<S19>/Constant'
                                        */
  real32_T CompareToConstant8_const_l; /* Mask Parameter: CompareToConstant8_const_l
                                        * Referenced by: '<S22>/Constant'
                                        */
  real32_T CompareToConstant10_const_o;/* Mask Parameter: CompareToConstant10_const_o
                                        * Referenced by: '<S21>/Constant'
                                        */
  uint8_T CompareToConstant1_const_c;  /* Mask Parameter: CompareToConstant1_const_c
                                        * Referenced by: '<S23>/Constant'
                                        */
  uint8_T CompareToConstant5_const;    /* Mask Parameter: CompareToConstant5_const
                                        * Referenced by: '<S24>/Constant'
                                        */
  uint8_T CompareToConstant6_const;    /* Mask Parameter: CompareToConstant6_const
                                        * Referenced by: '<S25>/Constant'
                                        */
  uint8_T CompareToConstant7_const;    /* Mask Parameter: CompareToConstant7_const
                                        * Referenced by: '<S26>/Constant'
                                        */
  real_T Constant3_Value;              /* Expression: -1
                                        * Referenced by: '<S3>/Constant3'
                                        */
  real_T Constant2_Value;              /* Expression: 1
                                        * Referenced by: '<S3>/Constant2'
                                        */
  real_T Switch1_Threshold;            /* Expression: 0
                                        * Referenced by: '<S3>/Switch1'
                                        */
  real_T Constant4_Value;              /* Expression: 0
                                        * Referenced by: '<Root>/Constant4'
                                        */
  real_T Constant6_Value;              /* Expression: -1
                                        * Referenced by: '<S4>/Constant6'
                                        */
  real_T Constant5_Value;              /* Expression: 1
                                        * Referenced by: '<S4>/Constant5'
                                        */
  real_T Switch2_Threshold;            /* Expression: 0
                                        * Referenced by: '<S4>/Switch2'
                                        */
  real_T Constant2_Value_i;            /* Expression: 0
                                        * Referenced by: '<Root>/Constant2'
                                        */
  real_T DiscreteFilter1_NumCoef[501]; /* Expression: 0.5*sin(pi*[0:500]/500)*(pi/500)
                                        * Referenced by: '<Root>/Discrete Filter1'
                                        */
  real_T DiscreteFilter1_DenCoef;      /* Expression: [1]
                                        * Referenced by: '<Root>/Discrete Filter1'
                                        */
  real_T DiscreteFilter1_InitialStates;/* Expression: 0
                                        * Referenced by: '<Root>/Discrete Filter1'
                                        */
  real_T DiscreteFilter3_NumCoef[501]; /* Expression: 0.5*sin(pi*[0:500]/500)*(pi/500)
                                        * Referenced by: '<Root>/Discrete Filter3'
                                        */
  real_T DiscreteFilter3_DenCoef;      /* Expression: [1]
                                        * Referenced by: '<Root>/Discrete Filter3'
                                        */
  real_T DiscreteFilter3_InitialStates;/* Expression: 0
                                        * Referenced by: '<Root>/Discrete Filter3'
                                        */
  real_T recording_clock_Amp;          /* Expression: 1
                                        * Referenced by: '<Root>/recording_clock'
                                        */
  real_T recording_clock_Period;       /* Expression: 2
                                        * Referenced by: '<Root>/recording_clock'
                                        */
  real_T recording_clock_Duty;         /* Expression: 1
                                        * Referenced by: '<Root>/recording_clock'
                                        */
  real_T recording_clock_PhaseDelay;   /* Expression: 0
                                        * Referenced by: '<Root>/recording_clock'
                                        */
  real_T send_2_uart_clock_Amp;        /* Expression: 1
                                        * Referenced by: '<Root>/send_2_uart_clock'
                                        */
  real_T send_2_uart_clock_Period;     /* Expression: 2
                                        * Referenced by: '<Root>/send_2_uart_clock'
                                        */
  real_T send_2_uart_clock_Duty;       /* Expression: 1
                                        * Referenced by: '<Root>/send_2_uart_clock'
                                        */
  real_T send_2_uart_clock_PhaseDelay; /* Expression: 0
                                        * Referenced by: '<Root>/send_2_uart_clock'
                                        */
  real_T Gain_Gain;                    /* Expression: 1
                                        * Referenced by: '<S9>/Gain'
                                        */
  real_T Gain1_Gain;                   /* Expression: 1
                                        * Referenced by: '<S9>/Gain1'
                                        */
  real_T WeightedSampleTime_WtEt;      /* Computed Parameter: WeightedSampleTime_WtEt
                                        * Referenced by: '<S11>/Weighted Sample Time'
                                        */
  real_T CenterFrequency_Gain;         /* Expression: FcRadians
                                        * Referenced by: '<S11>/Center Frequency'
                                        */
  real_T Gain_Gain_h;                  /* Expression: KcRadPerV
                                        * Referenced by: '<S14>/Gain'
                                        */
  real_T Modulo2pi_Value;              /* Expression: 2*pi
                                        * Referenced by: '<S11>/Modulo 2*pi'
                                        */
  real_T WeightedSampleTime_WtEt_b;    /* Computed Parameter: WeightedSampleTime_WtEt_b
                                        * Referenced by: '<S15>/Weighted Sample Time'
                                        */
  real_T CenterFrequency_Gain_d;       /* Expression: FcRadians
                                        * Referenced by: '<S15>/Center Frequency'
                                        */
  real_T Gain_Gain_o;                  /* Expression: KcRadPerV
                                        * Referenced by: '<S18>/Gain'
                                        */
  real_T Modulo2pi_Value_h;            /* Expression: 2*pi
                                        * Referenced by: '<S15>/Modulo 2*pi'
                                        */
  real32_T Constant_Value;             /* Computed Parameter: Constant_Value
                                        * Referenced by: '<Root>/Constant'
                                        */
  real32_T Delay2_InitialCondition;    /* Computed Parameter: Delay2_InitialCondition
                                        * Referenced by: '<S5>/Delay2'
                                        */
  real32_T Constant1_Value;            /* Computed Parameter: Constant1_Value
                                        * Referenced by: '<Root>/Constant1'
                                        */
  real32_T Delay2_InitialCondition_h;  /* Computed Parameter: Delay2_InitialCondition_h
                                        * Referenced by: '<S6>/Delay2'
                                        */
  real32_T WaitforBuffertoclear3_InitialCo;/* Computed Parameter: WaitforBuffertoclear3_InitialCo
                                            * Referenced by: '<S8>/Wait for Buffer to clear3'
                                            */
  real32_T RateTransition7_InitialConditio;/* Computed Parameter: RateTransition7_InitialConditio
                                            * Referenced by: '<S8>/Rate Transition7'
                                            */
  real32_T WaitforBuffertoclear4_InitialCo;/* Computed Parameter: WaitforBuffertoclear4_InitialCo
                                            * Referenced by: '<S8>/Wait for Buffer to clear4'
                                            */
  real32_T RateTransition9_InitialConditio;/* Computed Parameter: RateTransition9_InitialConditio
                                            * Referenced by: '<S8>/Rate Transition9'
                                            */
  real32_T WaitforBuffertoclear5_InitialCo;/* Computed Parameter: WaitforBuffertoclear5_InitialCo
                                            * Referenced by: '<S8>/Wait for Buffer to clear5'
                                            */
  real32_T RateTransition13_InitialConditi;/* Computed Parameter: RateTransition13_InitialConditi
                                            * Referenced by: '<S8>/Rate Transition13'
                                            */
  real32_T WaitforBuffertoclear6_InitialCo;/* Computed Parameter: WaitforBuffertoclear6_InitialCo
                                            * Referenced by: '<S8>/Wait for Buffer to clear6'
                                            */
  real32_T RateTransition11_InitialConditi;/* Computed Parameter: RateTransition11_InitialConditi
                                            * Referenced by: '<S8>/Rate Transition11'
                                            */
  real32_T WaitforBuffertoclear2_InitialCo;/* Computed Parameter: WaitforBuffertoclear2_InitialCo
                                            * Referenced by: '<S8>/Wait for Buffer to clear2'
                                            */
  real32_T RateTransition6_InitialConditio;/* Computed Parameter: RateTransition6_InitialConditio
                                            * Referenced by: '<S8>/Rate Transition6'
                                            */
  uint32_T Delay2_DelayLength;         /* Computed Parameter: Delay2_DelayLength
                                        * Referenced by: '<S5>/Delay2'
                                        */
  uint32_T Delay2_DelayLength_f;       /* Computed Parameter: Delay2_DelayLength_f
                                        * Referenced by: '<S6>/Delay2'
                                        */
  uint32_T WaitforBuffertoclear3_DelayLeng;/* Computed Parameter: WaitforBuffertoclear3_DelayLeng
                                            * Referenced by: '<S8>/Wait for Buffer to clear3'
                                            */
  uint32_T WaitforBuffertoclear3_DelayLe_m;/* Computed Parameter: WaitforBuffertoclear3_DelayLe_m
                                            * Referenced by: '<S8>/Wait for Buffer to clear 3'
                                            */
  uint32_T WaitforBuffertoclear4_DelayLeng;/* Computed Parameter: WaitforBuffertoclear4_DelayLeng
                                            * Referenced by: '<S8>/Wait for Buffer to clear4'
                                            */
  uint32_T WaitforBuffertoclear4_DelayLe_i;/* Computed Parameter: WaitforBuffertoclear4_DelayLe_i
                                            * Referenced by: '<S8>/Wait for Buffer to clear 4'
                                            */
  uint32_T WaitforBuffertoclear5_DelayLeng;/* Computed Parameter: WaitforBuffertoclear5_DelayLeng
                                            * Referenced by: '<S8>/Wait for Buffer to clear5'
                                            */
  uint32_T WaitforBuffertoclear6_DelayLeng;/* Computed Parameter: WaitforBuffertoclear6_DelayLeng
                                            * Referenced by: '<S8>/Wait for Buffer to clear 6'
                                            */
  uint32_T WaitforBuffertoclear6_DelayLe_j;/* Computed Parameter: WaitforBuffertoclear6_DelayLe_j
                                            * Referenced by: '<S8>/Wait for Buffer to clear6'
                                            */
  uint32_T WaitforBuffertoclear5_DelayLe_g;/* Computed Parameter: WaitforBuffertoclear5_DelayLe_g
                                            * Referenced by: '<S8>/Wait for Buffer to clear 5'
                                            */
  uint32_T WaitforBuffertoclear1_DelayLeng;/* Computed Parameter: WaitforBuffertoclear1_DelayLeng
                                            * Referenced by: '<S8>/Wait for Buffer to clear1'
                                            */
  uint32_T WaitforBuffertoclear1_InitialCo;/* Computed Parameter: WaitforBuffertoclear1_InitialCo
                                            * Referenced by: '<S8>/Wait for Buffer to clear1'
                                            */
  uint32_T WaitforBuffertoclear1_DelayLe_e;/* Computed Parameter: WaitforBuffertoclear1_DelayLe_e
                                            * Referenced by: '<S8>/Wait for Buffer to clear 1'
                                            */
  uint32_T RateTransition3_InitialConditio;/* Computed Parameter: RateTransition3_InitialConditio
                                            * Referenced by: '<S8>/Rate Transition3'
                                            */
  uint32_T WaitforBuffertoclear_DelayLengt;/* Computed Parameter: WaitforBuffertoclear_DelayLengt
                                            * Referenced by: '<S8>/Wait for Buffer to clear'
                                            */
  uint32_T WaitforBuffertoclear_InitialCon;/* Computed Parameter: WaitforBuffertoclear_InitialCon
                                            * Referenced by: '<S8>/Wait for Buffer to clear'
                                            */
  uint32_T WaitforBuffertoclear_DelayLen_o;/* Computed Parameter: WaitforBuffertoclear_DelayLen_o
                                            * Referenced by: '<S8>/Wait for Buffer to clear '
                                            */
  uint32_T RateTransition4_InitialConditio;/* Computed Parameter: RateTransition4_InitialConditio
                                            * Referenced by: '<S8>/Rate Transition4'
                                            */
  uint32_T WaitforBuffertoclear2_DelayLeng;/* Computed Parameter: WaitforBuffertoclear2_DelayLeng
                                            * Referenced by: '<S8>/Wait for Buffer to clear2'
                                            */
  uint32_T WaitforBuffertoclear2_DelayLe_k;/* Computed Parameter: WaitforBuffertoclear2_DelayLe_k
                                            * Referenced by: '<S8>/Wait for Buffer to clear 2'
                                            */
  uint8_T Constant_Value_e;            /* Computed Parameter: Constant_Value_e
                                        * Referenced by: '<S28>/Constant'
                                        */
  uint8_T Switch_Threshold;            /* Computed Parameter: Switch_Threshold
                                        * Referenced by: '<Root>/Switch'
                                        */
  uint8_T Switch1_Threshold_g;         /* Computed Parameter: Switch1_Threshold_g
                                        * Referenced by: '<Root>/Switch1'
                                        */
  uint8_T WaitforBuffertoclear3_Initial_o;/* Computed Parameter: WaitforBuffertoclear3_Initial_o
                                           * Referenced by: '<S8>/Wait for Buffer to clear 3'
                                           */
  uint8_T RateTransition8_InitialConditio;/* Computed Parameter: RateTransition8_InitialConditio
                                           * Referenced by: '<S8>/Rate Transition8'
                                           */
  uint8_T WaitforBuffertoclear4_Initial_j;/* Computed Parameter: WaitforBuffertoclear4_Initial_j
                                           * Referenced by: '<S8>/Wait for Buffer to clear 4'
                                           */
  uint8_T RateTransition10_InitialConditi;/* Computed Parameter: RateTransition10_InitialConditi
                                           * Referenced by: '<S8>/Rate Transition10'
                                           */
  uint8_T WaitforBuffertoclear6_Initial_m;/* Computed Parameter: WaitforBuffertoclear6_Initial_m
                                           * Referenced by: '<S8>/Wait for Buffer to clear 6'
                                           */
  uint8_T RateTransition14_InitialConditi;/* Computed Parameter: RateTransition14_InitialConditi
                                           * Referenced by: '<S8>/Rate Transition14'
                                           */
  uint8_T WaitforBuffertoclear5_Initial_p;/* Computed Parameter: WaitforBuffertoclear5_Initial_p
                                           * Referenced by: '<S8>/Wait for Buffer to clear 5'
                                           */
  uint8_T RateTransition12_InitialConditi;/* Computed Parameter: RateTransition12_InitialConditi
                                           * Referenced by: '<S8>/Rate Transition12'
                                           */
  uint8_T WaitforBuffertoclear1_Initial_i;/* Computed Parameter: WaitforBuffertoclear1_Initial_i
                                           * Referenced by: '<S8>/Wait for Buffer to clear 1'
                                           */
  uint8_T RateTransition1_InitialConditio;/* Computed Parameter: RateTransition1_InitialConditio
                                           * Referenced by: '<S8>/Rate Transition1'
                                           */
  uint8_T WaitforBuffertoclear_InitialC_a;/* Computed Parameter: WaitforBuffertoclear_InitialC_a
                                           * Referenced by: '<S8>/Wait for Buffer to clear '
                                           */
  uint8_T RateTransition2_InitialConditio;/* Computed Parameter: RateTransition2_InitialConditio
                                           * Referenced by: '<S8>/Rate Transition2'
                                           */
  uint8_T WaitforBuffertoclear2_Initial_l;/* Computed Parameter: WaitforBuffertoclear2_Initial_l
                                           * Referenced by: '<S8>/Wait for Buffer to clear 2'
                                           */
  uint8_T RateTransition5_InitialConditio;/* Computed Parameter: RateTransition5_InitialConditio
                                           * Referenced by: '<S8>/Rate Transition5'
                                           */
};

/* Real-time Model Data Structure */
struct tag_RTM_ADXL_recorder_fast1 {
  const char_T *errorStatus;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    struct {
      uint8_T TID[3];
    } TaskCounters;
  } Timing;
};

/* Block parameters (default storage) */
extern Parameters_ADXL_recorder_fast1 ADXL_recorder_fast1_P;

/* Block signals (default storage) */
extern BlockIO_ADXL_recorder_fast1 ADXL_recorder_fast1_B;

/* Block states (default storage) */
extern D_Work_ADXL_recorder_fast1 ADXL_recorder_fast1_DWork;

/* Model entry point functions */
extern void ADXL_recorder_fast1_initialize(void);
extern void ADXL_recorder_fast1_step(void);
extern void ADXL_recorder_fast1_terminate(void);

/* Real-time Model object */
extern RT_MODEL_ADXL_recorder_fast1 *const ADXL_recorder_fast1_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'ADXL_recorder_fast1'
 * '<S1>'   : 'ADXL_recorder_fast1/Repeating Sequence Stair'
 * '<S2>'   : 'ADXL_recorder_fast1/Repeating Sequence Stair1'
 * '<S3>'   : 'ADXL_recorder_fast1/Square Wave Gen'
 * '<S4>'   : 'ADXL_recorder_fast1/Square Wave Gen1'
 * '<S5>'   : 'ADXL_recorder_fast1/ignore_bad_data'
 * '<S6>'   : 'ADXL_recorder_fast1/ignore_bad_data1'
 * '<S7>'   : 'ADXL_recorder_fast1/record_and_send_via_UART'
 * '<S8>'   : 'ADXL_recorder_fast1/set_UART_VCflag'
 * '<S9>'   : 'ADXL_recorder_fast1/wiggler'
 * '<S10>'  : 'ADXL_recorder_fast1/wiggler1'
 * '<S11>'  : 'ADXL_recorder_fast1/Square Wave Gen/Discrete-Time VCO1'
 * '<S12>'  : 'ADXL_recorder_fast1/Square Wave Gen/Discrete-Time VCO1/Check Signal Attributes'
 * '<S13>'  : 'ADXL_recorder_fast1/Square Wave Gen/Discrete-Time VCO1/Convert 2-D to 1-D'
 * '<S14>'  : 'ADXL_recorder_fast1/Square Wave Gen/Discrete-Time VCO1/Sensitivity'
 * '<S15>'  : 'ADXL_recorder_fast1/Square Wave Gen1/Discrete-Time VCO'
 * '<S16>'  : 'ADXL_recorder_fast1/Square Wave Gen1/Discrete-Time VCO/Check Signal Attributes'
 * '<S17>'  : 'ADXL_recorder_fast1/Square Wave Gen1/Discrete-Time VCO/Convert 2-D to 1-D'
 * '<S18>'  : 'ADXL_recorder_fast1/Square Wave Gen1/Discrete-Time VCO/Sensitivity'
 * '<S19>'  : 'ADXL_recorder_fast1/ignore_bad_data/Compare To Constant10'
 * '<S20>'  : 'ADXL_recorder_fast1/ignore_bad_data/Compare To Constant8'
 * '<S21>'  : 'ADXL_recorder_fast1/ignore_bad_data1/Compare To Constant10'
 * '<S22>'  : 'ADXL_recorder_fast1/ignore_bad_data1/Compare To Constant8'
 * '<S23>'  : 'ADXL_recorder_fast1/record_and_send_via_UART/Compare To Constant1'
 * '<S24>'  : 'ADXL_recorder_fast1/record_and_send_via_UART/Compare To Constant5'
 * '<S25>'  : 'ADXL_recorder_fast1/record_and_send_via_UART/Compare To Constant6'
 * '<S26>'  : 'ADXL_recorder_fast1/record_and_send_via_UART/Compare To Constant7'
 * '<S27>'  : 'ADXL_recorder_fast1/record_and_send_via_UART/Subsystem3'
 * '<S28>'  : 'ADXL_recorder_fast1/record_and_send_via_UART/set flag=0'
 * '<S29>'  : 'ADXL_recorder_fast1/set_UART_VCflag/Set UART vc Flag=1'
 * '<S30>'  : 'ADXL_recorder_fast1/set_UART_VCflag/Set UART vc Flag=2'
 * '<S31>'  : 'ADXL_recorder_fast1/set_UART_VCflag/Set UART vc Flag=3'
 * '<S32>'  : 'ADXL_recorder_fast1/set_UART_VCflag/Set UART vc Flag=4'
 * '<S33>'  : 'ADXL_recorder_fast1/set_UART_VCflag/Set UART vc Flag=5'
 * '<S34>'  : 'ADXL_recorder_fast1/set_UART_VCflag/Set UART vc Flag=6'
 * '<S35>'  : 'ADXL_recorder_fast1/set_UART_VCflag/Set UART vc Flag=7'
 * '<S36>'  : 'ADXL_recorder_fast1/set_UART_VCflag/flag_setting'
 * '<S37>'  : 'ADXL_recorder_fast1/wiggler/Compare To Constant1'
 * '<S38>'  : 'ADXL_recorder_fast1/wiggler/Compare To Constant2'
 */
#endif                                 /* RTW_HEADER_ADXL_recorder_fast1_h_ */

/* [EOF] */
