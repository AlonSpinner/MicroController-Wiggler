/*
 * File: uart_xy_wiggler.h
 *
 * Created with Waijung Blockset
 *
 * Real-Time Workshop code generated for Simulink model uart_xy_wiggler.
 *
 * Model version                        : 1.148
 * Real-Time Workshop file version      : 8.14 (R2018a) 06-Feb-2018
 * Real-Time Workshop file generated on : Sun Jul 21 14:00:36 2019
 * TLC version                          : 8.14 (Feb 22 2018)
 * C/C++ source code generated on       : Sun Jul 21 14:00:44 2019
 *
 * Target selection: stm32f4.tlc
 * Embedded hardware selection: ARM Compatible->Cortex - M4
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_uart_xy_wiggler_h_
#define RTW_HEADER_uart_xy_wiggler_h_
#include <float.h>
#include <math.h>
#include <string.h>
#ifndef uart_xy_wiggler_COMMON_INCLUDES_
# define uart_xy_wiggler_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "waijung_hwdrvlib.h"
#endif                                 /* uart_xy_wiggler_COMMON_INCLUDES_ */

#include "uart_xy_wiggler_types.h"
#include "rt_nonfinite.h"
#include "rtGetInf.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

/* Block signals for system '<Root>/Median Filter1' */
typedef struct {
  real32_T MedianFilter1;              /* '<Root>/Median Filter1' */
} rtB_MedianFilter1_uart_xy_wiggl;

/* Block states (default storage) for system '<Root>/Median Filter1' */
typedef struct {
  dsp_MedianFilter_uart_xy_wiggle obj; /* '<Root>/Median Filter1' */
  boolean_T objisempty;                /* '<Root>/Median Filter1' */
} rtDW_MedianFilter1_uart_xy_wigg;

/* Block signals (default storage) */
typedef struct {
  real_T VolatileDataStorageRead2;     /* '<Root>/Volatile Data Storage Read2' */
  real_T CalibrationVcx;               /* '<Root>/Calibration Vcx' */
  real_T CalibrationVcy;               /* '<Root>/Calibration Vcy' */
  real_T VolatileDataStorageRead5;     /* '<S2>/Volatile Data Storage Read5' */
  real_T VolatileDataStorageRead4;     /* '<S15>/Volatile Data Storage Read4' */
  real_T VolatileDataStorageRead1;     /* '<S15>/Volatile Data Storage Read1' */
  real_T VolatileDataStorageRead2_h;   /* '<S15>/Volatile Data Storage Read2' */
  real_T VolatileDataStorageRead3;     /* '<S15>/Volatile Data Storage Read3' */
  real_T VolatileDataStorageRead5_o;   /* '<S15>/Volatile Data Storage Read5' */
  real_T VolatileDataStorageRead9;     /* '<S14>/Volatile Data Storage Read9' */
  real_T VolatileDataStorageRead6;     /* '<S14>/Volatile Data Storage Read6' */
  real_T VolatileDataStorageRead7;     /* '<S14>/Volatile Data Storage Read7' */
  real_T VolatileDataStorageRead8;     /* '<S14>/Volatile Data Storage Read8' */
  real_T VolatileDataStorageRead10;    /* '<S14>/Volatile Data Storage Read10' */
  real_T VolatileDataStorageRead5_f;   /* '<S3>/Volatile Data Storage Read5' */
  real_T VolatileDataStorageRead2_hi;  /* '<S3>/Volatile Data Storage Read2' */
  real_T VolatileDataStorageRead3_n;   /* '<S3>/Volatile Data Storage Read3' */
  real_T VolatileDataStorageRead1_g;   /* '<S3>/Volatile Data Storage Read1' */
  real_T VolatileDataStorageRead4_k;   /* '<S29>/Volatile Data Storage Read4' */
  real_T VolatileDataStorageRead1_i;   /* '<S29>/Volatile Data Storage Read1' */
  real_T VolatileDataStorageRead2_m;   /* '<S29>/Volatile Data Storage Read2' */
  real_T VolatileDataStorageRead3_d;   /* '<S29>/Volatile Data Storage Read3' */
  real_T VolatileDataStorageRead5_b;   /* '<S29>/Volatile Data Storage Read5' */
  real_T VolatileDataStorageRead9_c;   /* '<S28>/Volatile Data Storage Read9' */
  real_T VolatileDataStorageRead6_p;   /* '<S28>/Volatile Data Storage Read6' */
  real_T VolatileDataStorageRead7_d;   /* '<S28>/Volatile Data Storage Read7' */
  real_T VolatileDataStorageRead8_n;   /* '<S28>/Volatile Data Storage Read8' */
  real_T VolatileDataStorageRead10_a;  /* '<S28>/Volatile Data Storage Read10' */
  real_T MultiportSwitch[2];           /* '<Root>/Multiport Switch' */
  real_T PWM_VC2;                      /* '<S9>/Gain' */
  real_T PWM_VC1;                      /* '<S9>/Gain1' */
  real_T VolatileDataStorageRead2_l;   /* '<S9>/Volatile Data Storage Read2' */
  real_T Laser;                        /* '<S9>/Volatile Data Storage Read3' */
  real_T MultiportSwitch_b;            /* '<S9>/Multiport Switch' */
  real_T VolatileDataStorageRead1_j;   /* '<S9>/Volatile Data Storage Read1' */
  real_T VolatileDataStorageRead4_l;   /* '<S2>/Volatile Data Storage Read4' */
  real_T VolatileDataStorageRead4_h;   /* '<S3>/Volatile Data Storage Read4' */
  real_T DataTypeConversion1;          /* '<S8>/Data Type Conversion1' */
  real_T DataTypeConversion2;          /* '<S8>/Data Type Conversion2' */
  real_T DataTypeConversion3;          /* '<S8>/Data Type Conversion3' */
  real_T DataTypeConversion4;          /* '<S8>/Data Type Conversion4' */
  real_T DataTypeConversion5;          /* '<S8>/Data Type Conversion5' */
  real_T DataTypeConversion1_k;        /* '<S52>/Data Type Conversion1' */
  real_T DataTypeConversion10;         /* '<S52>/Data Type Conversion10' */
  real_T DataTypeConversion2_c;        /* '<S52>/Data Type Conversion2' */
  real_T DataTypeConversion3_f;        /* '<S52>/Data Type Conversion3' */
  real_T DataTypeConversion4_e;        /* '<S52>/Data Type Conversion4' */
  real_T DataTypeConversion5_n;        /* '<S52>/Data Type Conversion5' */
  real_T DataTypeConversion6;          /* '<S52>/Data Type Conversion6' */
  real_T DataTypeConversion7;          /* '<S52>/Data Type Conversion7' */
  real_T DataTypeConversion8;          /* '<S52>/Data Type Conversion8' */
  real_T DataTypeConversion9;          /* '<S52>/Data Type Conversion9' */
  real_T DataTypeConversion1_a;        /* '<S53>/Data Type Conversion1' */
  real_T DataTypeConversion10_o;       /* '<S53>/Data Type Conversion10' */
  real_T DataTypeConversion6_i;        /* '<S53>/Data Type Conversion6' */
  real_T DataTypeConversion7_d;        /* '<S53>/Data Type Conversion7' */
  real_T DataTypeConversion8_m;        /* '<S53>/Data Type Conversion8' */
  real_T DataTypeConversion9_n;        /* '<S53>/Data Type Conversion9' */
  uint32_T UARTRx3_o2;                 /* '<S8>/UART Rx3' */
  real32_T PWMchX_o2;                  /* '<Root>/PWM chX' */
  real32_T PWMchX_o3;                  /* '<Root>/PWM chX' */
  real32_T PWMchX_o4;                  /* '<Root>/PWM chX' */
  real32_T PWMchY_o2;                  /* '<Root>/PWM chY' */
  real32_T PWMchY_o3;                  /* '<Root>/PWM chY' */
  real32_T PWMchY_o4;                  /* '<Root>/PWM chY' */
  real32_T Queue_o1[4];                /* '<S7>/Queue' */
  real32_T RateTransition4;            /* '<S8>/Rate Transition4' */
  real32_T UARTRx_o2;                  /* '<S8>/UART Rx' */
  real32_T RateTransition3;            /* '<S8>/Rate Transition3' */
  real32_T UARTRx1_o2;                 /* '<S8>/UART Rx1' */
  real32_T RateTransition8;            /* '<S8>/Rate Transition8' */
  real32_T UARTRx4_o2;                 /* '<S8>/UART Rx4' */
  real32_T RateTransition10;           /* '<S8>/Rate Transition10' */
  real32_T UARTRx5_o2;                 /* '<S8>/UART Rx5' */
  real32_T RateTransition11;           /* '<S8>/Rate Transition11' */
  real32_T UARTRx6_o2;                 /* '<S8>/UART Rx6' */
  real32_T WaitforBuffertoclear2;      /* '<S8>/Wait for Buffer to clear2' */
  real32_T RateTransition6;            /* '<S8>/Rate Transition6' */
  real32_T UARTRx2_o2;                 /* '<S8>/UART Rx2' */
  real32_T RateTransition1;            /* '<S52>/Rate Transition1' */
  real32_T UARTRx1_o2_p;               /* '<S52>/UART Rx1' */
  real32_T RateTransition21;           /* '<S52>/Rate Transition21' */
  real32_T UARTRx11_o2;                /* '<S52>/UART Rx11' */
  real32_T RateTransition3_p;          /* '<S52>/Rate Transition3' */
  real32_T UARTRx2_o2_i;               /* '<S52>/UART Rx2' */
  real32_T RateTransition5;            /* '<S52>/Rate Transition5' */
  real32_T UARTRx3_o2_g;               /* '<S52>/UART Rx3' */
  real32_T RateTransition7;            /* '<S52>/Rate Transition7' */
  real32_T UARTRx4_o2_o;               /* '<S52>/UART Rx4' */
  real32_T RateTransition11_n;         /* '<S52>/Rate Transition11' */
  real32_T UARTRx6_o2_h;               /* '<S52>/UART Rx6' */
  real32_T RateTransition13;           /* '<S52>/Rate Transition13' */
  real32_T UARTRx7_o2;                 /* '<S52>/UART Rx7' */
  real32_T RateTransition15;           /* '<S52>/Rate Transition15' */
  real32_T UARTRx8_o2;                 /* '<S52>/UART Rx8' */
  real32_T RateTransition8_c;          /* '<S52>/Rate Transition8' */
  real32_T UARTRx5_o2_h;               /* '<S52>/UART Rx5' */
  real32_T RateTransition19;           /* '<S52>/Rate Transition19' */
  real32_T UARTRx10_o2;                /* '<S52>/UART Rx10' */
  real32_T RateTransition1_l;          /* '<S53>/Rate Transition1' */
  real32_T UARTRx1_o2_i;               /* '<S53>/UART Rx1' */
  real32_T RateTransition21_c;         /* '<S53>/Rate Transition21' */
  real32_T UARTRx11_o2_a;              /* '<S53>/UART Rx11' */
  real32_T RateTransition13_f;         /* '<S53>/Rate Transition13' */
  real32_T UARTRx7_o2_k;               /* '<S53>/UART Rx7' */
  real32_T RateTransition15_e;         /* '<S53>/Rate Transition15' */
  real32_T UARTRx8_o2_g;               /* '<S53>/UART Rx8' */
  real32_T RateTransition17;           /* '<S53>/Rate Transition17' */
  real32_T UARTRx9_o2;                 /* '<S53>/UART Rx9' */
  real32_T RateTransition19_g;         /* '<S53>/Rate Transition19' */
  real32_T UARTRx10_o2_h;              /* '<S53>/UART Rx10' */
  uint8_T flag_for_recorder_uart;      /* '<Root>/flag_for_recorder_uart' */
  uint8_T PWMchX_o1;                   /* '<Root>/PWM chX' */
  uint8_T PWMchY_o1;                   /* '<Root>/PWM chY' */
  uint8_T RateTransition2;             /* '<S8>/Rate Transition2' */
  uint8_T UARTRx_o1;                   /* '<S8>/UART Rx' */
  uint8_T RateTransition1_b;           /* '<S8>/Rate Transition1' */
  uint8_T UARTRx1_o1;                  /* '<S8>/UART Rx1' */
  uint8_T RateTransition7_f;           /* '<S8>/Rate Transition7' */
  uint8_T UARTRx4_o1;                  /* '<S8>/UART Rx4' */
  uint8_T RateTransition9;             /* '<S8>/Rate Transition9' */
  uint8_T UARTRx5_o1;                  /* '<S8>/UART Rx5' */
  uint8_T RateTransition12;            /* '<S8>/Rate Transition12' */
  uint8_T UARTRx6_o1;                  /* '<S8>/UART Rx6' */
  uint8_T RateTransition5_n;           /* '<S8>/Rate Transition5' */
  uint8_T UARTRx2_o1;                  /* '<S8>/UART Rx2' */
  uint8_T UARTRx3_o1;                  /* '<S8>/UART Rx3' */
  uint8_T RateTransition2_g;           /* '<S52>/Rate Transition2' */
  uint8_T UARTRx1_o1_p;                /* '<S52>/UART Rx1' */
  uint8_T RateTransition22;            /* '<S52>/Rate Transition22' */
  uint8_T UARTRx11_o1;                 /* '<S52>/UART Rx11' */
  uint8_T RateTransition4_e;           /* '<S52>/Rate Transition4' */
  uint8_T UARTRx2_o1_p;                /* '<S52>/UART Rx2' */
  uint8_T RateTransition6_d;           /* '<S52>/Rate Transition6' */
  uint8_T UARTRx3_o1_d;                /* '<S52>/UART Rx3' */
  uint8_T RateTransition9_c;           /* '<S52>/Rate Transition9' */
  uint8_T UARTRx4_o1_f;                /* '<S52>/UART Rx4' */
  uint8_T RateTransition12_h;          /* '<S52>/Rate Transition12' */
  uint8_T UARTRx6_o1_i;                /* '<S52>/UART Rx6' */
  uint8_T RateTransition14;            /* '<S52>/Rate Transition14' */
  uint8_T UARTRx7_o1;                  /* '<S52>/UART Rx7' */
  uint8_T RateTransition16;            /* '<S52>/Rate Transition16' */
  uint8_T UARTRx8_o1;                  /* '<S52>/UART Rx8' */
  uint8_T RateTransition10_e;          /* '<S52>/Rate Transition10' */
  uint8_T UARTRx5_o1_p;                /* '<S52>/UART Rx5' */
  uint8_T RateTransition20;            /* '<S52>/Rate Transition20' */
  uint8_T UARTRx10_o1;                 /* '<S52>/UART Rx10' */
  uint8_T RateTransition2_o;           /* '<S53>/Rate Transition2' */
  uint8_T UARTRx1_o1_f;                /* '<S53>/UART Rx1' */
  uint8_T RateTransition22_n;          /* '<S53>/Rate Transition22' */
  uint8_T UARTRx11_o1_c;               /* '<S53>/UART Rx11' */
  uint8_T RateTransition14_h;          /* '<S53>/Rate Transition14' */
  uint8_T UARTRx7_o1_e;                /* '<S53>/UART Rx7' */
  uint8_T RateTransition16_o;          /* '<S53>/Rate Transition16' */
  uint8_T UARTRx8_o1_c;                /* '<S53>/UART Rx8' */
  uint8_T RateTransition18;            /* '<S53>/Rate Transition18' */
  uint8_T UARTRx9_o1;                  /* '<S53>/UART Rx9' */
  uint8_T RateTransition20_o;          /* '<S53>/Rate Transition20' */
  uint8_T UARTRx10_o1_m;               /* '<S53>/UART Rx10' */
  uint8_T DataTypeConversion;          /* '<S60>/Data Type Conversion' */
  boolean_T Compare;                   /* '<S46>/Compare' */
  boolean_T Compare_i;                 /* '<S47>/Compare' */
  boolean_T Compare_d;                 /* '<S48>/Compare' */
  boolean_T Compare_i4;                /* '<S78>/Compare' */
  boolean_T Compare_a;                 /* '<S77>/Compare' */
  rtB_MedianFilter1_uart_xy_wiggl MedianFilter;/* '<Root>/Median Filter1' */
  rtB_MedianFilter1_uart_xy_wiggl MedianFilter1;/* '<Root>/Median Filter1' */
} BlockIO_uart_xy_wiggler;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  real_T UnitDelay_DSTATE;             /* '<S13>/Unit Delay' */
  real_T UnitDelay_DSTATE_d;           /* '<S12>/Unit Delay' */
  real_T UnitDelay_DSTATE_j;           /* '<S25>/Unit Delay' */
  real_T UnitDelay_DSTATE_g;           /* '<S27>/Unit Delay' */
  real_T UnitDelay_DSTATE_i;           /* '<S24>/Unit Delay' */
  real_T UnitDelay_DSTATE_jm;          /* '<S26>/Unit Delay' */
  real_T UnitDelay_DSTATE_do;          /* '<S79>/Unit Delay' */
  real32_T Delay2_DSTATE;              /* '<S5>/Delay2' */
  real32_T Delay2_DSTATE_c;            /* '<S6>/Delay2' */
  real32_T WaitforBuffertoclear1_DSTATE[2];/* '<S8>/Wait for Buffer to clear1' */
  real32_T WaitforBuffertoclear3_DSTATE[2];/* '<S8>/Wait for Buffer to clear3' */
  real32_T WaitforBuffertoclear4_DSTATE[2];/* '<S8>/Wait for Buffer to clear4' */
  real32_T WaitforBuffertoclear5_DSTATE[2];/* '<S8>/Wait for Buffer to clear5' */
  real32_T WaitforBuffertoclear6_DSTATE[2];/* '<S8>/Wait for Buffer to clear6' */
  real32_T WaitforBuffertoclear2_DSTATE[2];/* '<S8>/Wait for Buffer to clear2' */
  real32_T WaitforBuffertoclear1_DSTATE_p[2];/* '<S52>/Wait for Buffer to clear1' */
  real32_T WaitforBuffertoclear11_DSTATE[2];/* '<S52>/Wait for Buffer to clear11' */
  real32_T WaitforBuffertoclear2_DSTATE_b[2];/* '<S52>/Wait for Buffer to clear2' */
  real32_T WaitforBuffertoclear3_DSTATE_n[2];/* '<S52>/Wait for Buffer to clear3' */
  real32_T WaitforBuffertoclear4_DSTATE_p[2];/* '<S52>/Wait for Buffer to clear4' */
  real32_T WaitforBuffertoclear6_DSTATE_b[2];/* '<S52>/Wait for Buffer to clear6' */
  real32_T WaitforBuffertoclear7_DSTATE[2];/* '<S52>/Wait for Buffer to clear7' */
  real32_T WaitforBuffertoclear8_DSTATE[2];/* '<S52>/Wait for Buffer to clear8' */
  real32_T WaitforBuffertoclear5_DSTATE_l[2];/* '<S52>/Wait for Buffer to clear5' */
  real32_T WaitforBuffertoclear10_DSTATE[2];/* '<S52>/Wait for Buffer to clear10' */
  real32_T WaitforBuffertoclear1_DSTATE_c[2];/* '<S53>/Wait for Buffer to clear1' */
  real32_T WaitforBuffertoclear11_DSTATE_g[2];/* '<S53>/Wait for Buffer to clear11' */
  real32_T WaitforBuffertoclear7_DSTATE_f[2];/* '<S53>/Wait for Buffer to clear7' */
  real32_T WaitforBuffertoclear8_DSTATE_e[2];/* '<S53>/Wait for Buffer to clear8' */
  real32_T WaitforBuffertoclear9_DSTATE[2];/* '<S53>/Wait for Buffer to clear9' */
  real32_T WaitforBuffertoclear10_DSTATE_p[2];/* '<S53>/Wait for Buffer to clear10' */
  real32_T Queue_BufferPtr[80];        /* '<S7>/Queue' */
  real32_T RateTransition4_Buffer0;    /* '<S8>/Rate Transition4' */
  real32_T RateTransition3_Buffer0;    /* '<S8>/Rate Transition3' */
  real32_T RateTransition8_Buffer0;    /* '<S8>/Rate Transition8' */
  real32_T RateTransition10_Buffer0;   /* '<S8>/Rate Transition10' */
  real32_T RateTransition11_Buffer0;   /* '<S8>/Rate Transition11' */
  real32_T RateTransition6_Buffer0;    /* '<S8>/Rate Transition6' */
  real32_T RateTransition1_Buffer0;    /* '<S52>/Rate Transition1' */
  real32_T RateTransition21_Buffer0;   /* '<S52>/Rate Transition21' */
  real32_T RateTransition3_Buffer0_o;  /* '<S52>/Rate Transition3' */
  real32_T RateTransition5_Buffer0;    /* '<S52>/Rate Transition5' */
  real32_T RateTransition7_Buffer0;    /* '<S52>/Rate Transition7' */
  real32_T RateTransition11_Buffer0_d; /* '<S52>/Rate Transition11' */
  real32_T RateTransition13_Buffer0;   /* '<S52>/Rate Transition13' */
  real32_T RateTransition15_Buffer0;   /* '<S52>/Rate Transition15' */
  real32_T RateTransition8_Buffer0_o;  /* '<S52>/Rate Transition8' */
  real32_T RateTransition19_Buffer0;   /* '<S52>/Rate Transition19' */
  real32_T RateTransition1_Buffer0_i;  /* '<S53>/Rate Transition1' */
  real32_T RateTransition21_Buffer0_p; /* '<S53>/Rate Transition21' */
  real32_T RateTransition13_Buffer0_e; /* '<S53>/Rate Transition13' */
  real32_T RateTransition15_Buffer0_l; /* '<S53>/Rate Transition15' */
  real32_T RateTransition17_Buffer0;   /* '<S53>/Rate Transition17' */
  real32_T RateTransition19_Buffer0_o; /* '<S53>/Rate Transition19' */
  int32_T clockTickCounter;            /* '<Root>/recording_clock' */
  int32_T clockTickCounter_b;          /* '<Root>/send_2_uart_clock' */
  uint32_T Queue_EPH0PrevState;        /* '<S7>/Queue' */
  uint32_T Queue_EPH1PrevState;        /* '<S7>/Queue' */
  uint32_T Queue_EPH2PrevState;        /* '<S7>/Queue' */
  uint32_T Queue_QueueFrontIdx;        /* '<S7>/Queue' */
  uint32_T Queue_NumElements;          /* '<S7>/Queue' */
  uint32_T Queue_QueueBackIdx;         /* '<S7>/Queue' */
  uint8_T WaitforBuffertoclear_DSTATE[2];/* '<S8>/Wait for Buffer to clear ' */
  uint8_T WaitforBuffertoclear1_DSTATE_l[2];/* '<S8>/Wait for Buffer to clear 1' */
  uint8_T WaitforBuffertoclear3_DSTATE_j[2];/* '<S8>/Wait for Buffer to clear 3' */
  uint8_T WaitforBuffertoclear4_DSTATE_b[2];/* '<S8>/Wait for Buffer to clear 4' */
  uint8_T WaitforBuffertoclear5_DSTATE_p[2];/* '<S8>/Wait for Buffer to clear 5' */
  uint8_T WaitforBuffertoclear2_DSTATE_l[2];/* '<S8>/Wait for Buffer to clear 2' */
  uint8_T WaitforBuffertoclear1_DSTATE_d[2];/* '<S52>/Wait for Buffer to clear 1' */
  uint8_T WaitforBuffertoclear10_DSTATE_n[2];/* '<S52>/Wait for Buffer to clear 10' */
  uint8_T WaitforBuffertoclear2_DSTATE_d[2];/* '<S52>/Wait for Buffer to clear 2' */
  uint8_T WaitforBuffertoclear3_DSTATE_c[2];/* '<S52>/Wait for Buffer to clear 3' */
  uint8_T WaitforBuffertoclear4_DSTATE_c[2];/* '<S52>/Wait for Buffer to clear 4' */
  uint8_T WaitforBuffertoclear5_DSTATE_c[2];/* '<S52>/Wait for Buffer to clear 5' */
  uint8_T WaitforBuffertoclear6_DSTATE_br[2];/* '<S52>/Wait for Buffer to clear 6' */
  uint8_T WaitforBuffertoclear7_DSTATE_a[2];/* '<S52>/Wait for Buffer to clear 7' */
  uint8_T WaitforBuffertoclear8_DSTATE_d[2];/* '<S52>/Wait for Buffer to clear 8' */
  uint8_T WaitforBuffertoclear9_DSTATE_i[2];/* '<S52>/Wait for Buffer to clear 9' */
  uint8_T WaitforBuffertoclear1_DSTATE_n[2];/* '<S53>/Wait for Buffer to clear 1' */
  uint8_T WaitforBuffertoclear10_DSTAT_nb[2];/* '<S53>/Wait for Buffer to clear 10' */
  uint8_T WaitforBuffertoclear6_DSTATE_j[2];/* '<S53>/Wait for Buffer to clear 6' */
  uint8_T WaitforBuffertoclear7_DSTATE_d[2];/* '<S53>/Wait for Buffer to clear 7' */
  uint8_T WaitforBuffertoclear8_DSTATE_j[2];/* '<S53>/Wait for Buffer to clear 8' */
  uint8_T WaitforBuffertoclear9_DSTATE_a[2];/* '<S53>/Wait for Buffer to clear 9' */
  uint8_T RateTransition2_Buffer0;     /* '<S8>/Rate Transition2' */
  uint8_T RateTransition1_Buffer0_o;   /* '<S8>/Rate Transition1' */
  uint8_T RateTransition7_Buffer0_l;   /* '<S8>/Rate Transition7' */
  uint8_T RateTransition9_Buffer0;     /* '<S8>/Rate Transition9' */
  uint8_T RateTransition12_Buffer0;    /* '<S8>/Rate Transition12' */
  uint8_T RateTransition5_Buffer0_m;   /* '<S8>/Rate Transition5' */
  uint8_T RateTransition2_Buffer0_h;   /* '<S52>/Rate Transition2' */
  uint8_T RateTransition22_Buffer0;    /* '<S52>/Rate Transition22' */
  uint8_T RateTransition4_Buffer0_k;   /* '<S52>/Rate Transition4' */
  uint8_T RateTransition6_Buffer0_c;   /* '<S52>/Rate Transition6' */
  uint8_T RateTransition9_Buffer0_c;   /* '<S52>/Rate Transition9' */
  uint8_T RateTransition12_Buffer0_i;  /* '<S52>/Rate Transition12' */
  uint8_T RateTransition14_Buffer0;    /* '<S52>/Rate Transition14' */
  uint8_T RateTransition16_Buffer0;    /* '<S52>/Rate Transition16' */
  uint8_T RateTransition10_Buffer0_g;  /* '<S52>/Rate Transition10' */
  uint8_T RateTransition20_Buffer0;    /* '<S52>/Rate Transition20' */
  uint8_T RateTransition2_Buffer0_g;   /* '<S53>/Rate Transition2' */
  uint8_T RateTransition22_Buffer0_j;  /* '<S53>/Rate Transition22' */
  uint8_T RateTransition14_Buffer0_a;  /* '<S53>/Rate Transition14' */
  uint8_T RateTransition16_Buffer0_p;  /* '<S53>/Rate Transition16' */
  uint8_T RateTransition18_Buffer0;    /* '<S53>/Rate Transition18' */
  uint8_T RateTransition20_Buffer0_e;  /* '<S53>/Rate Transition20' */
  boolean_T flag_setting_MODE;         /* '<S8>/flag_setting' */
  boolean_T SetUARTvcFlag6_MODE;       /* '<S8>/Set UART vc Flag=6' */
  boolean_T SetUARTvcFlag5_MODE;       /* '<S8>/Set UART vc Flag=5' */
  boolean_T SetUARTvcFlag4_MODE;       /* '<S8>/Set UART vc Flag=4' */
  boolean_T SetUARTvcFlag3_MODE;       /* '<S8>/Set UART vc Flag=3' */
  boolean_T SetUARTvcFlag2_MODE;       /* '<S8>/Set UART vc Flag=2' */
  boolean_T SetUARTvcFlag1_MODE;       /* '<S8>/Set UART vc Flag=1' */
  boolean_T SetUARTvcFlag9_MODE;       /* '<S53>/Set UART vc Flag=9' */
  boolean_T SetUARTvcFlag8_MODE;       /* '<S53>/Set UART vc Flag=8' */
  boolean_T SetUARTvcFlag7_MODE;       /* '<S53>/Set UART vc Flag=7' */
  boolean_T SetUARTvcFlag11_MODE;      /* '<S53>/Set UART vc Flag=11' */
  boolean_T SetUARTvcFlag10_MODE;      /* '<S53>/Set UART vc Flag=10' */
  boolean_T SetUARTvcFlag1_MODE_o;     /* '<S53>/Set UART vc Flag=1' */
  boolean_T SetUARTvcFlag8_MODE_f;     /* '<S52>/Set UART vc Flag=8' */
  boolean_T SetUARTvcFlag7_MODE_h;     /* '<S52>/Set UART vc Flag=7' */
  boolean_T SetUARTvcFlag6_MODE_g;     /* '<S52>/Set UART vc Flag=6' */
  boolean_T SetUARTvcFlag5_MODE_j;     /* '<S52>/Set UART vc Flag=5' */
  boolean_T SetUARTvcFlag4_MODE_c;     /* '<S52>/Set UART vc Flag=4' */
  boolean_T SetUARTvcFlag3_MODE_f;     /* '<S52>/Set UART vc Flag=3' */
  boolean_T SetUARTvcFlag2_MODE_k;     /* '<S52>/Set UART vc Flag=2' */
  boolean_T SetUARTvcFlag11_MODE_f;    /* '<S52>/Set UART vc Flag=11' */
  boolean_T SetUARTvcFlag10_MODE_a;    /* '<S52>/Set UART vc Flag=10' */
  boolean_T SetUARTvcFlag1_MODE_l;     /* '<S52>/Set UART vc Flag=1' */
  boolean_T setflag0_MODE;             /* '<S7>/set flag=0' */
  boolean_T Subsystem3_MODE;           /* '<S7>/Subsystem3' */
  rtDW_MedianFilter1_uart_xy_wigg MedianFilter;/* '<Root>/Median Filter1' */
  rtDW_MedianFilter1_uart_xy_wigg MedianFilter1;/* '<Root>/Median Filter1' */
} D_Work_uart_xy_wiggler;

/* Parameters (default storage) */
struct Parameters_uart_xy_wiggler_ {
  real_T DiscreteTimeVCO1_Ac;          /* Mask Parameter: DiscreteTimeVCO1_Ac
                                        * Referenced by: '<S13>/Sensitivity3'
                                        */
  real_T DiscreteTimeVCO_Ac;           /* Mask Parameter: DiscreteTimeVCO_Ac
                                        * Referenced by: '<S12>/Sensitivity3'
                                        */
  real_T Coswt_Ac;                     /* Mask Parameter: Coswt_Ac
                                        * Referenced by: '<S25>/Sensitivity3'
                                        */
  real_T Sinwt_Ac;                     /* Mask Parameter: Sinwt_Ac
                                        * Referenced by: '<S27>/Sensitivity3'
                                        */
  real_T Cos5wt_Ac;                    /* Mask Parameter: Cos5wt_Ac
                                        * Referenced by: '<S24>/Sensitivity3'
                                        */
  real_T Sin5wt_Ac;                    /* Mask Parameter: Sin5wt_Ac
                                        * Referenced by: '<S26>/Sensitivity3'
                                        */
  real_T DiscreteTimeVCO_Ac_m;         /* Mask Parameter: DiscreteTimeVCO_Ac_m
                                        * Referenced by: '<S79>/Sensitivity3'
                                        */
  real_T DiscreteTimeVCO1_Ph;          /* Mask Parameter: DiscreteTimeVCO1_Ph
                                        * Referenced by: '<S13>/Unit Delay'
                                        */
  real_T DiscreteTimeVCO_Ph;           /* Mask Parameter: DiscreteTimeVCO_Ph
                                        * Referenced by: '<S12>/Unit Delay'
                                        */
  real_T Coswt_Ph;                     /* Mask Parameter: Coswt_Ph
                                        * Referenced by: '<S25>/Unit Delay'
                                        */
  real_T Sinwt_Ph;                     /* Mask Parameter: Sinwt_Ph
                                        * Referenced by: '<S27>/Unit Delay'
                                        */
  real_T Cos5wt_Ph;                    /* Mask Parameter: Cos5wt_Ph
                                        * Referenced by: '<S24>/Unit Delay'
                                        */
  real_T Sin5wt_Ph;                    /* Mask Parameter: Sin5wt_Ph
                                        * Referenced by: '<S26>/Unit Delay'
                                        */
  real_T DiscreteTimeVCO_Ph_k;         /* Mask Parameter: DiscreteTimeVCO_Ph_k
                                        * Referenced by: '<S79>/Unit Delay'
                                        */
  real_T CompareToConstant2_const;     /* Mask Parameter: CompareToConstant2_const
                                        * Referenced by: '<S78>/Constant'
                                        */
  real_T CompareToConstant1_const;     /* Mask Parameter: CompareToConstant1_const
                                        * Referenced by: '<S77>/Constant'
                                        */
  real32_T CompareToConstant8_const;   /* Mask Parameter: CompareToConstant8_const
                                        * Referenced by: '<S43>/Constant'
                                        */
  real32_T CompareToConstant10_const;  /* Mask Parameter: CompareToConstant10_const
                                        * Referenced by: '<S42>/Constant'
                                        */
  real32_T CompareToConstant8_const_l; /* Mask Parameter: CompareToConstant8_const_l
                                        * Referenced by: '<S45>/Constant'
                                        */
  real32_T CompareToConstant10_const_o;/* Mask Parameter: CompareToConstant10_const_o
                                        * Referenced by: '<S44>/Constant'
                                        */
  uint8_T CompareToConstant1_const_c;  /* Mask Parameter: CompareToConstant1_const_c
                                        * Referenced by: '<S46>/Constant'
                                        */
  uint8_T CompareToConstant5_const;    /* Mask Parameter: CompareToConstant5_const
                                        * Referenced by: '<S47>/Constant'
                                        */
  uint8_T CompareToConstant6_const;    /* Mask Parameter: CompareToConstant6_const
                                        * Referenced by: '<S48>/Constant'
                                        */
  uint8_T CompareToConstant7_const;    /* Mask Parameter: CompareToConstant7_const
                                        * Referenced by: '<S49>/Constant'
                                        */
  real_T Constant_Value;               /* Expression: 90
                                        * Referenced by: '<S9>/Constant'
                                        */
  real_T recording_clock_Amp;          /* Expression: 1
                                        * Referenced by: '<Root>/recording_clock'
                                        */
  real_T recording_clock_Period;       /* Expression: 2
                                        * Referenced by: '<Root>/recording_clock'
                                        */
  real_T recording_clock_Duty;         /* Expression: 1
                                        * Referenced by: '<Root>/recording_clock'
                                        */
  real_T recording_clock_PhaseDelay;   /* Expression: 0
                                        * Referenced by: '<Root>/recording_clock'
                                        */
  real_T send_2_uart_clock_Amp;        /* Expression: 1
                                        * Referenced by: '<Root>/send_2_uart_clock'
                                        */
  real_T send_2_uart_clock_Period;     /* Expression: 2
                                        * Referenced by: '<Root>/send_2_uart_clock'
                                        */
  real_T send_2_uart_clock_Duty;       /* Expression: 1
                                        * Referenced by: '<Root>/send_2_uart_clock'
                                        */
  real_T send_2_uart_clock_PhaseDelay; /* Expression: 0
                                        * Referenced by: '<Root>/send_2_uart_clock'
                                        */
  real_T Gain_Gain;                    /* Expression: 1
                                        * Referenced by: '<S9>/Gain'
                                        */
  real_T Gain1_Gain;                   /* Expression: 1
                                        * Referenced by: '<S9>/Gain1'
                                        */
  real_T Constant1_Value;              /* Expression: 90
                                        * Referenced by: '<S9>/Constant1'
                                        */
  real_T WeightedSampleTime_WtEt;      /* Computed Parameter: WeightedSampleTime_WtEt
                                        * Referenced by: '<S79>/Weighted Sample Time'
                                        */
  real_T CenterFrequency_Gain;         /* Expression: FcRadians
                                        * Referenced by: '<S79>/Center Frequency'
                                        */
  real_T Gain_Gain_a;                  /* Expression: KcRadPerV
                                        * Referenced by: '<S82>/Gain'
                                        */
  real_T Modulo2pi_Value;              /* Expression: 2*pi
                                        * Referenced by: '<S79>/Modulo 2*pi'
                                        */
  real_T WeightedSampleTime_WtEt_a;    /* Computed Parameter: WeightedSampleTime_WtEt_a
                                        * Referenced by: '<S12>/Weighted Sample Time'
                                        */
  real_T CenterFrequency_Gain_a;       /* Expression: FcRadians
                                        * Referenced by: '<S12>/Center Frequency'
                                        */
  real_T Gain_Gain_e;                  /* Expression: KcRadPerV
                                        * Referenced by: '<S18>/Gain'
                                        */
  real_T Modulo2pi_Value_d;            /* Expression: 2*pi
                                        * Referenced by: '<S12>/Modulo 2*pi'
                                        */
  real_T WeightedSampleTime_WtEt_o;    /* Computed Parameter: WeightedSampleTime_WtEt_o
                                        * Referenced by: '<S13>/Weighted Sample Time'
                                        */
  real_T CenterFrequency_Gain_i;       /* Expression: FcRadians
                                        * Referenced by: '<S13>/Center Frequency'
                                        */
  real_T Gain_Gain_o;                  /* Expression: KcRadPerV
                                        * Referenced by: '<S21>/Gain'
                                        */
  real_T Modulo2pi_Value_dg;           /* Expression: 2*pi
                                        * Referenced by: '<S13>/Modulo 2*pi'
                                        */
  real_T WeightedSampleTime_WtEt_os;   /* Computed Parameter: WeightedSampleTime_WtEt_os
                                        * Referenced by: '<S24>/Weighted Sample Time'
                                        */
  real_T CenterFrequency_Gain_k;       /* Expression: FcRadians
                                        * Referenced by: '<S24>/Center Frequency'
                                        */
  real_T Gain1_Gain_m;                 /* Expression: 5
                                        * Referenced by: '<S3>/Gain1'
                                        */
  real_T Gain_Gain_g;                  /* Expression: KcRadPerV
                                        * Referenced by: '<S32>/Gain'
                                        */
  real_T Modulo2pi_Value_j;            /* Expression: 2*pi
                                        * Referenced by: '<S24>/Modulo 2*pi'
                                        */
  real_T WeightedSampleTime_WtEt_i;    /* Computed Parameter: WeightedSampleTime_WtEt_i
                                        * Referenced by: '<S25>/Weighted Sample Time'
                                        */
  real_T CenterFrequency_Gain_p;       /* Expression: FcRadians
                                        * Referenced by: '<S25>/Center Frequency'
                                        */
  real_T Gain_Gain_h;                  /* Expression: KcRadPerV
                                        * Referenced by: '<S35>/Gain'
                                        */
  real_T Modulo2pi_Value_o;            /* Expression: 2*pi
                                        * Referenced by: '<S25>/Modulo 2*pi'
                                        */
  real_T Gain_Gain_k;                  /* Expression: 5
                                        * Referenced by: '<S3>/Gain'
                                        */
  real_T WeightedSampleTime_WtEt_h;    /* Computed Parameter: WeightedSampleTime_WtEt_h
                                        * Referenced by: '<S26>/Weighted Sample Time'
                                        */
  real_T CenterFrequency_Gain_h;       /* Expression: FcRadians
                                        * Referenced by: '<S26>/Center Frequency'
                                        */
  real_T Gain_Gain_i;                  /* Expression: KcRadPerV
                                        * Referenced by: '<S38>/Gain'
                                        */
  real_T Modulo2pi_Value_h;            /* Expression: 2*pi
                                        * Referenced by: '<S26>/Modulo 2*pi'
                                        */
  real_T WeightedSampleTime_WtEt_a3;   /* Computed Parameter: WeightedSampleTime_WtEt_a3
                                        * Referenced by: '<S27>/Weighted Sample Time'
                                        */
  real_T CenterFrequency_Gain_pl;      /* Expression: FcRadians
                                        * Referenced by: '<S27>/Center Frequency'
                                        */
  real_T Gain_Gain_m;                  /* Expression: KcRadPerV
                                        * Referenced by: '<S41>/Gain'
                                        */
  real_T Modulo2pi_Value_l;            /* Expression: 2*pi
                                        * Referenced by: '<S27>/Modulo 2*pi'
                                        */
  real32_T Constant_Value_m;           /* Computed Parameter: Constant_Value_m
                                        * Referenced by: '<Root>/Constant'
                                        */
  real32_T Delay2_InitialCondition;    /* Computed Parameter: Delay2_InitialCondition
                                        * Referenced by: '<S5>/Delay2'
                                        */
  real32_T Constant1_Value_e;          /* Computed Parameter: Constant1_Value_e
                                        * Referenced by: '<Root>/Constant1'
                                        */
  real32_T Delay2_InitialCondition_h;  /* Computed Parameter: Delay2_InitialCondition_h
                                        * Referenced by: '<S6>/Delay2'
                                        */
  real32_T WaitforBuffertoclear1_InitialCo;/* Computed Parameter: WaitforBuffertoclear1_InitialCo
                                            * Referenced by: '<S8>/Wait for Buffer to clear1'
                                            */
  real32_T RateTransition4_InitialConditio;/* Computed Parameter: RateTransition4_InitialConditio
                                            * Referenced by: '<S8>/Rate Transition4'
                                            */
  real32_T WaitforBuffertoclear3_InitialCo;/* Computed Parameter: WaitforBuffertoclear3_InitialCo
                                            * Referenced by: '<S8>/Wait for Buffer to clear3'
                                            */
  real32_T RateTransition3_InitialConditio;/* Computed Parameter: RateTransition3_InitialConditio
                                            * Referenced by: '<S8>/Rate Transition3'
                                            */
  real32_T WaitforBuffertoclear4_InitialCo;/* Computed Parameter: WaitforBuffertoclear4_InitialCo
                                            * Referenced by: '<S8>/Wait for Buffer to clear4'
                                            */
  real32_T RateTransition8_InitialConditio;/* Computed Parameter: RateTransition8_InitialConditio
                                            * Referenced by: '<S8>/Rate Transition8'
                                            */
  real32_T WaitforBuffertoclear5_InitialCo;/* Computed Parameter: WaitforBuffertoclear5_InitialCo
                                            * Referenced by: '<S8>/Wait for Buffer to clear5'
                                            */
  real32_T RateTransition10_InitialConditi;/* Computed Parameter: RateTransition10_InitialConditi
                                            * Referenced by: '<S8>/Rate Transition10'
                                            */
  real32_T WaitforBuffertoclear6_InitialCo;/* Computed Parameter: WaitforBuffertoclear6_InitialCo
                                            * Referenced by: '<S8>/Wait for Buffer to clear6'
                                            */
  real32_T RateTransition11_InitialConditi;/* Computed Parameter: RateTransition11_InitialConditi
                                            * Referenced by: '<S8>/Rate Transition11'
                                            */
  real32_T WaitforBuffertoclear2_InitialCo;/* Computed Parameter: WaitforBuffertoclear2_InitialCo
                                            * Referenced by: '<S8>/Wait for Buffer to clear2'
                                            */
  real32_T RateTransition6_InitialConditio;/* Computed Parameter: RateTransition6_InitialConditio
                                            * Referenced by: '<S8>/Rate Transition6'
                                            */
  real32_T WaitforBuffertoclear1_Initial_h;/* Computed Parameter: WaitforBuffertoclear1_Initial_h
                                            * Referenced by: '<S52>/Wait for Buffer to clear1'
                                            */
  real32_T RateTransition1_InitialConditio;/* Computed Parameter: RateTransition1_InitialConditio
                                            * Referenced by: '<S52>/Rate Transition1'
                                            */
  real32_T WaitforBuffertoclear11_InitialC;/* Computed Parameter: WaitforBuffertoclear11_InitialC
                                            * Referenced by: '<S52>/Wait for Buffer to clear11'
                                            */
  real32_T RateTransition21_InitialConditi;/* Computed Parameter: RateTransition21_InitialConditi
                                            * Referenced by: '<S52>/Rate Transition21'
                                            */
  real32_T WaitforBuffertoclear2_Initial_g;/* Computed Parameter: WaitforBuffertoclear2_Initial_g
                                            * Referenced by: '<S52>/Wait for Buffer to clear2'
                                            */
  real32_T RateTransition3_InitialCondit_a;/* Computed Parameter: RateTransition3_InitialCondit_a
                                            * Referenced by: '<S52>/Rate Transition3'
                                            */
  real32_T WaitforBuffertoclear3_Initial_m;/* Computed Parameter: WaitforBuffertoclear3_Initial_m
                                            * Referenced by: '<S52>/Wait for Buffer to clear3'
                                            */
  real32_T RateTransition5_InitialConditio;/* Computed Parameter: RateTransition5_InitialConditio
                                            * Referenced by: '<S52>/Rate Transition5'
                                            */
  real32_T WaitforBuffertoclear4_Initial_d;/* Computed Parameter: WaitforBuffertoclear4_Initial_d
                                            * Referenced by: '<S52>/Wait for Buffer to clear4'
                                            */
  real32_T RateTransition7_InitialConditio;/* Computed Parameter: RateTransition7_InitialConditio
                                            * Referenced by: '<S52>/Rate Transition7'
                                            */
  real32_T WaitforBuffertoclear6_Initial_c;/* Computed Parameter: WaitforBuffertoclear6_Initial_c
                                            * Referenced by: '<S52>/Wait for Buffer to clear6'
                                            */
  real32_T RateTransition11_InitialCondi_l;/* Computed Parameter: RateTransition11_InitialCondi_l
                                            * Referenced by: '<S52>/Rate Transition11'
                                            */
  real32_T WaitforBuffertoclear7_InitialCo;/* Computed Parameter: WaitforBuffertoclear7_InitialCo
                                            * Referenced by: '<S52>/Wait for Buffer to clear7'
                                            */
  real32_T RateTransition13_InitialConditi;/* Computed Parameter: RateTransition13_InitialConditi
                                            * Referenced by: '<S52>/Rate Transition13'
                                            */
  real32_T WaitforBuffertoclear8_InitialCo;/* Computed Parameter: WaitforBuffertoclear8_InitialCo
                                            * Referenced by: '<S52>/Wait for Buffer to clear8'
                                            */
  real32_T RateTransition15_InitialConditi;/* Computed Parameter: RateTransition15_InitialConditi
                                            * Referenced by: '<S52>/Rate Transition15'
                                            */
  real32_T WaitforBuffertoclear5_Initial_l;/* Computed Parameter: WaitforBuffertoclear5_Initial_l
                                            * Referenced by: '<S52>/Wait for Buffer to clear5'
                                            */
  real32_T RateTransition8_InitialCondit_i;/* Computed Parameter: RateTransition8_InitialCondit_i
                                            * Referenced by: '<S52>/Rate Transition8'
                                            */
  real32_T WaitforBuffertoclear10_InitialC;/* Computed Parameter: WaitforBuffertoclear10_InitialC
                                            * Referenced by: '<S52>/Wait for Buffer to clear10'
                                            */
  real32_T RateTransition19_InitialConditi;/* Computed Parameter: RateTransition19_InitialConditi
                                            * Referenced by: '<S52>/Rate Transition19'
                                            */
  real32_T WaitforBuffertoclear1_Initial_a;/* Computed Parameter: WaitforBuffertoclear1_Initial_a
                                            * Referenced by: '<S53>/Wait for Buffer to clear1'
                                            */
  real32_T RateTransition1_InitialCondit_n;/* Computed Parameter: RateTransition1_InitialCondit_n
                                            * Referenced by: '<S53>/Rate Transition1'
                                            */
  real32_T WaitforBuffertoclear11_Initia_f;/* Computed Parameter: WaitforBuffertoclear11_Initia_f
                                            * Referenced by: '<S53>/Wait for Buffer to clear11'
                                            */
  real32_T RateTransition21_InitialCondi_e;/* Computed Parameter: RateTransition21_InitialCondi_e
                                            * Referenced by: '<S53>/Rate Transition21'
                                            */
  real32_T WaitforBuffertoclear7_Initial_b;/* Computed Parameter: WaitforBuffertoclear7_Initial_b
                                            * Referenced by: '<S53>/Wait for Buffer to clear7'
                                            */
  real32_T RateTransition13_InitialCondi_a;/* Computed Parameter: RateTransition13_InitialCondi_a
                                            * Referenced by: '<S53>/Rate Transition13'
                                            */
  real32_T WaitforBuffertoclear8_Initial_m;/* Computed Parameter: WaitforBuffertoclear8_Initial_m
                                            * Referenced by: '<S53>/Wait for Buffer to clear8'
                                            */
  real32_T RateTransition15_InitialCondi_n;/* Computed Parameter: RateTransition15_InitialCondi_n
                                            * Referenced by: '<S53>/Rate Transition15'
                                            */
  real32_T WaitforBuffertoclear9_InitialCo;/* Computed Parameter: WaitforBuffertoclear9_InitialCo
                                            * Referenced by: '<S53>/Wait for Buffer to clear9'
                                            */
  real32_T RateTransition17_InitialConditi;/* Computed Parameter: RateTransition17_InitialConditi
                                            * Referenced by: '<S53>/Rate Transition17'
                                            */
  real32_T WaitforBuffertoclear10_Initia_o;/* Computed Parameter: WaitforBuffertoclear10_Initia_o
                                            * Referenced by: '<S53>/Wait for Buffer to clear10'
                                            */
  real32_T RateTransition19_InitialCondi_j;/* Computed Parameter: RateTransition19_InitialCondi_j
                                            * Referenced by: '<S53>/Rate Transition19'
                                            */
  uint32_T Delay2_DelayLength;         /* Computed Parameter: Delay2_DelayLength
                                        * Referenced by: '<S5>/Delay2'
                                        */
  uint32_T Delay2_DelayLength_f;       /* Computed Parameter: Delay2_DelayLength_f
                                        * Referenced by: '<S6>/Delay2'
                                        */
  uint32_T WaitforBuffertoclear1_DelayLeng;/* Computed Parameter: WaitforBuffertoclear1_DelayLeng
                                            * Referenced by: '<S8>/Wait for Buffer to clear1'
                                            */
  uint32_T WaitforBuffertoclear_DelayLengt;/* Computed Parameter: WaitforBuffertoclear_DelayLengt
                                            * Referenced by: '<S8>/Wait for Buffer to clear '
                                            */
  uint32_T WaitforBuffertoclear3_DelayLeng;/* Computed Parameter: WaitforBuffertoclear3_DelayLeng
                                            * Referenced by: '<S8>/Wait for Buffer to clear3'
                                            */
  uint32_T WaitforBuffertoclear1_DelayLe_f;/* Computed Parameter: WaitforBuffertoclear1_DelayLe_f
                                            * Referenced by: '<S8>/Wait for Buffer to clear 1'
                                            */
  uint32_T WaitforBuffertoclear4_DelayLeng;/* Computed Parameter: WaitforBuffertoclear4_DelayLeng
                                            * Referenced by: '<S8>/Wait for Buffer to clear4'
                                            */
  uint32_T WaitforBuffertoclear3_DelayLe_k;/* Computed Parameter: WaitforBuffertoclear3_DelayLe_k
                                            * Referenced by: '<S8>/Wait for Buffer to clear 3'
                                            */
  uint32_T WaitforBuffertoclear5_DelayLeng;/* Computed Parameter: WaitforBuffertoclear5_DelayLeng
                                            * Referenced by: '<S8>/Wait for Buffer to clear5'
                                            */
  uint32_T WaitforBuffertoclear4_DelayLe_n;/* Computed Parameter: WaitforBuffertoclear4_DelayLe_n
                                            * Referenced by: '<S8>/Wait for Buffer to clear 4'
                                            */
  uint32_T WaitforBuffertoclear6_DelayLeng;/* Computed Parameter: WaitforBuffertoclear6_DelayLeng
                                            * Referenced by: '<S8>/Wait for Buffer to clear6'
                                            */
  uint32_T WaitforBuffertoclear5_DelayLe_d;/* Computed Parameter: WaitforBuffertoclear5_DelayLe_d
                                            * Referenced by: '<S8>/Wait for Buffer to clear 5'
                                            */
  uint32_T WaitforBuffertoclear2_DelayLeng;/* Computed Parameter: WaitforBuffertoclear2_DelayLeng
                                            * Referenced by: '<S8>/Wait for Buffer to clear2'
                                            */
  uint32_T WaitforBuffertoclear2_DelayLe_k;/* Computed Parameter: WaitforBuffertoclear2_DelayLe_k
                                            * Referenced by: '<S8>/Wait for Buffer to clear 2'
                                            */
  uint32_T WaitforBuffertoclear1_DelayLe_o;/* Computed Parameter: WaitforBuffertoclear1_DelayLe_o
                                            * Referenced by: '<S52>/Wait for Buffer to clear1'
                                            */
  uint32_T WaitforBuffertoclear1_DelayLe_n;/* Computed Parameter: WaitforBuffertoclear1_DelayLe_n
                                            * Referenced by: '<S52>/Wait for Buffer to clear 1'
                                            */
  uint32_T WaitforBuffertoclear11_DelayLen;/* Computed Parameter: WaitforBuffertoclear11_DelayLen
                                            * Referenced by: '<S52>/Wait for Buffer to clear11'
                                            */
  uint32_T WaitforBuffertoclear10_DelayLen;/* Computed Parameter: WaitforBuffertoclear10_DelayLen
                                            * Referenced by: '<S52>/Wait for Buffer to clear 10'
                                            */
  uint32_T WaitforBuffertoclear2_DelayLe_e;/* Computed Parameter: WaitforBuffertoclear2_DelayLe_e
                                            * Referenced by: '<S52>/Wait for Buffer to clear2'
                                            */
  uint32_T WaitforBuffertoclear2_DelayLe_c;/* Computed Parameter: WaitforBuffertoclear2_DelayLe_c
                                            * Referenced by: '<S52>/Wait for Buffer to clear 2'
                                            */
  uint32_T WaitforBuffertoclear3_DelayLe_c;/* Computed Parameter: WaitforBuffertoclear3_DelayLe_c
                                            * Referenced by: '<S52>/Wait for Buffer to clear3'
                                            */
  uint32_T WaitforBuffertoclear3_DelayLe_h;/* Computed Parameter: WaitforBuffertoclear3_DelayLe_h
                                            * Referenced by: '<S52>/Wait for Buffer to clear 3'
                                            */
  uint32_T WaitforBuffertoclear4_DelayLe_g;/* Computed Parameter: WaitforBuffertoclear4_DelayLe_g
                                            * Referenced by: '<S52>/Wait for Buffer to clear4'
                                            */
  uint32_T WaitforBuffertoclear4_DelayLe_c;/* Computed Parameter: WaitforBuffertoclear4_DelayLe_c
                                            * Referenced by: '<S52>/Wait for Buffer to clear 4'
                                            */
  uint32_T WaitforBuffertoclear6_DelayLe_a;/* Computed Parameter: WaitforBuffertoclear6_DelayLe_a
                                            * Referenced by: '<S52>/Wait for Buffer to clear6'
                                            */
  uint32_T WaitforBuffertoclear5_DelayLe_k;/* Computed Parameter: WaitforBuffertoclear5_DelayLe_k
                                            * Referenced by: '<S52>/Wait for Buffer to clear 5'
                                            */
  uint32_T WaitforBuffertoclear7_DelayLeng;/* Computed Parameter: WaitforBuffertoclear7_DelayLeng
                                            * Referenced by: '<S52>/Wait for Buffer to clear7'
                                            */
  uint32_T WaitforBuffertoclear6_DelayLe_m;/* Computed Parameter: WaitforBuffertoclear6_DelayLe_m
                                            * Referenced by: '<S52>/Wait for Buffer to clear 6'
                                            */
  uint32_T WaitforBuffertoclear8_DelayLeng;/* Computed Parameter: WaitforBuffertoclear8_DelayLeng
                                            * Referenced by: '<S52>/Wait for Buffer to clear8'
                                            */
  uint32_T WaitforBuffertoclear7_DelayLe_c;/* Computed Parameter: WaitforBuffertoclear7_DelayLe_c
                                            * Referenced by: '<S52>/Wait for Buffer to clear 7'
                                            */
  uint32_T WaitforBuffertoclear5_DelayLe_a;/* Computed Parameter: WaitforBuffertoclear5_DelayLe_a
                                            * Referenced by: '<S52>/Wait for Buffer to clear5'
                                            */
  uint32_T WaitforBuffertoclear8_DelayLe_c;/* Computed Parameter: WaitforBuffertoclear8_DelayLe_c
                                            * Referenced by: '<S52>/Wait for Buffer to clear 8'
                                            */
  uint32_T WaitforBuffertoclear10_DelayL_f;/* Computed Parameter: WaitforBuffertoclear10_DelayL_f
                                            * Referenced by: '<S52>/Wait for Buffer to clear10'
                                            */
  uint32_T WaitforBuffertoclear9_DelayLeng;/* Computed Parameter: WaitforBuffertoclear9_DelayLeng
                                            * Referenced by: '<S52>/Wait for Buffer to clear 9'
                                            */
  uint32_T WaitforBuffertoclear1_DelayL_f0;/* Computed Parameter: WaitforBuffertoclear1_DelayL_f0
                                            * Referenced by: '<S53>/Wait for Buffer to clear1'
                                            */
  uint32_T WaitforBuffertoclear1_DelayLe_j;/* Computed Parameter: WaitforBuffertoclear1_DelayLe_j
                                            * Referenced by: '<S53>/Wait for Buffer to clear 1'
                                            */
  uint32_T WaitforBuffertoclear11_DelayL_m;/* Computed Parameter: WaitforBuffertoclear11_DelayL_m
                                            * Referenced by: '<S53>/Wait for Buffer to clear11'
                                            */
  uint32_T WaitforBuffertoclear10_DelayL_n;/* Computed Parameter: WaitforBuffertoclear10_DelayL_n
                                            * Referenced by: '<S53>/Wait for Buffer to clear 10'
                                            */
  uint32_T WaitforBuffertoclear7_DelayLe_j;/* Computed Parameter: WaitforBuffertoclear7_DelayLe_j
                                            * Referenced by: '<S53>/Wait for Buffer to clear7'
                                            */
  uint32_T WaitforBuffertoclear6_DelayLe_e;/* Computed Parameter: WaitforBuffertoclear6_DelayLe_e
                                            * Referenced by: '<S53>/Wait for Buffer to clear 6'
                                            */
  uint32_T WaitforBuffertoclear8_DelayLe_n;/* Computed Parameter: WaitforBuffertoclear8_DelayLe_n
                                            * Referenced by: '<S53>/Wait for Buffer to clear8'
                                            */
  uint32_T WaitforBuffertoclear7_DelayLe_o;/* Computed Parameter: WaitforBuffertoclear7_DelayLe_o
                                            * Referenced by: '<S53>/Wait for Buffer to clear 7'
                                            */
  uint32_T WaitforBuffertoclear9_DelayLe_o;/* Computed Parameter: WaitforBuffertoclear9_DelayLe_o
                                            * Referenced by: '<S53>/Wait for Buffer to clear9'
                                            */
  uint32_T WaitforBuffertoclear8_DelayLe_b;/* Computed Parameter: WaitforBuffertoclear8_DelayLe_b
                                            * Referenced by: '<S53>/Wait for Buffer to clear 8'
                                            */
  uint32_T WaitforBuffertoclear10_Delay_nh;/* Computed Parameter: WaitforBuffertoclear10_Delay_nh
                                            * Referenced by: '<S53>/Wait for Buffer to clear10'
                                            */
  uint32_T WaitforBuffertoclear9_DelayLe_h;/* Computed Parameter: WaitforBuffertoclear9_DelayLe_h
                                            * Referenced by: '<S53>/Wait for Buffer to clear 9'
                                            */
  uint8_T Constant_Value_e;            /* Computed Parameter: Constant_Value_e
                                        * Referenced by: '<S51>/Constant'
                                        */
  uint8_T WaitforBuffertoclear_InitialCon;/* Computed Parameter: WaitforBuffertoclear_InitialCon
                                           * Referenced by: '<S8>/Wait for Buffer to clear '
                                           */
  uint8_T RateTransition2_InitialConditio;/* Computed Parameter: RateTransition2_InitialConditio
                                           * Referenced by: '<S8>/Rate Transition2'
                                           */
  uint8_T WaitforBuffertoclear1_Initial_n;/* Computed Parameter: WaitforBuffertoclear1_Initial_n
                                           * Referenced by: '<S8>/Wait for Buffer to clear 1'
                                           */
  uint8_T RateTransition1_InitialCondit_g;/* Computed Parameter: RateTransition1_InitialCondit_g
                                           * Referenced by: '<S8>/Rate Transition1'
                                           */
  uint8_T WaitforBuffertoclear3_Initia_mg;/* Computed Parameter: WaitforBuffertoclear3_Initia_mg
                                           * Referenced by: '<S8>/Wait for Buffer to clear 3'
                                           */
  uint8_T RateTransition7_InitialCondit_j;/* Computed Parameter: RateTransition7_InitialCondit_j
                                           * Referenced by: '<S8>/Rate Transition7'
                                           */
  uint8_T WaitforBuffertoclear4_Initial_k;/* Computed Parameter: WaitforBuffertoclear4_Initial_k
                                           * Referenced by: '<S8>/Wait for Buffer to clear 4'
                                           */
  uint8_T RateTransition9_InitialConditio;/* Computed Parameter: RateTransition9_InitialConditio
                                           * Referenced by: '<S8>/Rate Transition9'
                                           */
  uint8_T WaitforBuffertoclear5_Initia_lu;/* Computed Parameter: WaitforBuffertoclear5_Initia_lu
                                           * Referenced by: '<S8>/Wait for Buffer to clear 5'
                                           */
  uint8_T RateTransition12_InitialConditi;/* Computed Parameter: RateTransition12_InitialConditi
                                           * Referenced by: '<S8>/Rate Transition12'
                                           */
  uint8_T WaitforBuffertoclear2_Initial_l;/* Computed Parameter: WaitforBuffertoclear2_Initial_l
                                           * Referenced by: '<S8>/Wait for Buffer to clear 2'
                                           */
  uint8_T RateTransition5_InitialCondit_e;/* Computed Parameter: RateTransition5_InitialCondit_e
                                           * Referenced by: '<S8>/Rate Transition5'
                                           */
  uint8_T WaitforBuffertoclear1_Initial_c;/* Computed Parameter: WaitforBuffertoclear1_Initial_c
                                           * Referenced by: '<S52>/Wait for Buffer to clear 1'
                                           */
  uint8_T RateTransition2_InitialCondit_i;/* Computed Parameter: RateTransition2_InitialCondit_i
                                           * Referenced by: '<S52>/Rate Transition2'
                                           */
  uint8_T WaitforBuffertoclear10_Initia_l;/* Computed Parameter: WaitforBuffertoclear10_Initia_l
                                           * Referenced by: '<S52>/Wait for Buffer to clear 10'
                                           */
  uint8_T RateTransition22_InitialConditi;/* Computed Parameter: RateTransition22_InitialConditi
                                           * Referenced by: '<S52>/Rate Transition22'
                                           */
  uint8_T WaitforBuffertoclear2_Initial_k;/* Computed Parameter: WaitforBuffertoclear2_Initial_k
                                           * Referenced by: '<S52>/Wait for Buffer to clear 2'
                                           */
  uint8_T RateTransition4_InitialCondit_e;/* Computed Parameter: RateTransition4_InitialCondit_e
                                           * Referenced by: '<S52>/Rate Transition4'
                                           */
  uint8_T WaitforBuffertoclear3_Initial_j;/* Computed Parameter: WaitforBuffertoclear3_Initial_j
                                           * Referenced by: '<S52>/Wait for Buffer to clear 3'
                                           */
  uint8_T RateTransition6_InitialCondit_b;/* Computed Parameter: RateTransition6_InitialCondit_b
                                           * Referenced by: '<S52>/Rate Transition6'
                                           */
  uint8_T WaitforBuffertoclear4_Initial_h;/* Computed Parameter: WaitforBuffertoclear4_Initial_h
                                           * Referenced by: '<S52>/Wait for Buffer to clear 4'
                                           */
  uint8_T RateTransition9_InitialCondit_c;/* Computed Parameter: RateTransition9_InitialCondit_c
                                           * Referenced by: '<S52>/Rate Transition9'
                                           */
  uint8_T WaitforBuffertoclear5_Initial_n;/* Computed Parameter: WaitforBuffertoclear5_Initial_n
                                           * Referenced by: '<S52>/Wait for Buffer to clear 5'
                                           */
  uint8_T RateTransition12_InitialCondi_e;/* Computed Parameter: RateTransition12_InitialCondi_e
                                           * Referenced by: '<S52>/Rate Transition12'
                                           */
  uint8_T WaitforBuffertoclear6_Initial_m;/* Computed Parameter: WaitforBuffertoclear6_Initial_m
                                           * Referenced by: '<S52>/Wait for Buffer to clear 6'
                                           */
  uint8_T RateTransition14_InitialConditi;/* Computed Parameter: RateTransition14_InitialConditi
                                           * Referenced by: '<S52>/Rate Transition14'
                                           */
  uint8_T WaitforBuffertoclear7_Initial_j;/* Computed Parameter: WaitforBuffertoclear7_Initial_j
                                           * Referenced by: '<S52>/Wait for Buffer to clear 7'
                                           */
  uint8_T RateTransition16_InitialConditi;/* Computed Parameter: RateTransition16_InitialConditi
                                           * Referenced by: '<S52>/Rate Transition16'
                                           */
  uint8_T WaitforBuffertoclear8_Initial_i;/* Computed Parameter: WaitforBuffertoclear8_Initial_i
                                           * Referenced by: '<S52>/Wait for Buffer to clear 8'
                                           */
  uint8_T RateTransition10_InitialCondi_d;/* Computed Parameter: RateTransition10_InitialCondi_d
                                           * Referenced by: '<S52>/Rate Transition10'
                                           */
  uint8_T WaitforBuffertoclear9_Initial_n;/* Computed Parameter: WaitforBuffertoclear9_Initial_n
                                           * Referenced by: '<S52>/Wait for Buffer to clear 9'
                                           */
  uint8_T RateTransition20_InitialConditi;/* Computed Parameter: RateTransition20_InitialConditi
                                           * Referenced by: '<S52>/Rate Transition20'
                                           */
  uint8_T WaitforBuffertoclear1_Initial_b;/* Computed Parameter: WaitforBuffertoclear1_Initial_b
                                           * Referenced by: '<S53>/Wait for Buffer to clear 1'
                                           */
  uint8_T RateTransition2_InitialCondit_e;/* Computed Parameter: RateTransition2_InitialCondit_e
                                           * Referenced by: '<S53>/Rate Transition2'
                                           */
  uint8_T WaitforBuffertoclear10_Initi_ow;/* Computed Parameter: WaitforBuffertoclear10_Initi_ow
                                           * Referenced by: '<S53>/Wait for Buffer to clear 10'
                                           */
  uint8_T RateTransition22_InitialCondi_h;/* Computed Parameter: RateTransition22_InitialCondi_h
                                           * Referenced by: '<S53>/Rate Transition22'
                                           */
  uint8_T WaitforBuffertoclear6_Initial_b;/* Computed Parameter: WaitforBuffertoclear6_Initial_b
                                           * Referenced by: '<S53>/Wait for Buffer to clear 6'
                                           */
  uint8_T RateTransition14_InitialCondi_e;/* Computed Parameter: RateTransition14_InitialCondi_e
                                           * Referenced by: '<S53>/Rate Transition14'
                                           */
  uint8_T WaitforBuffertoclear7_Initial_l;/* Computed Parameter: WaitforBuffertoclear7_Initial_l
                                           * Referenced by: '<S53>/Wait for Buffer to clear 7'
                                           */
  uint8_T RateTransition16_InitialCondi_b;/* Computed Parameter: RateTransition16_InitialCondi_b
                                           * Referenced by: '<S53>/Rate Transition16'
                                           */
  uint8_T WaitforBuffertoclear8_Initial_c;/* Computed Parameter: WaitforBuffertoclear8_Initial_c
                                           * Referenced by: '<S53>/Wait for Buffer to clear 8'
                                           */
  uint8_T RateTransition18_InitialConditi;/* Computed Parameter: RateTransition18_InitialConditi
                                           * Referenced by: '<S53>/Rate Transition18'
                                           */
  uint8_T WaitforBuffertoclear9_Initial_h;/* Computed Parameter: WaitforBuffertoclear9_Initial_h
                                           * Referenced by: '<S53>/Wait for Buffer to clear 9'
                                           */
  uint8_T RateTransition20_InitialCondi_j;/* Computed Parameter: RateTransition20_InitialCondi_j
                                           * Referenced by: '<S53>/Rate Transition20'
                                           */
};

/* Real-time Model Data Structure */
struct tag_RTM_uart_xy_wiggler {
  const char_T *errorStatus;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    struct {
      uint8_T TID[3];
    } TaskCounters;
  } Timing;
};

/* Block parameters (default storage) */
extern Parameters_uart_xy_wiggler uart_xy_wiggler_P;

/* Block signals (default storage) */
extern BlockIO_uart_xy_wiggler uart_xy_wiggler_B;

/* Block states (default storage) */
extern D_Work_uart_xy_wiggler uart_xy_wiggler_DWork;

/* Model entry point functions */
extern void uart_xy_wiggler_initialize(void);
extern void uart_xy_wiggler_step(void);
extern void uart_xy_wiggler_terminate(void);

/* Real-time Model object */
extern RT_MODEL_uart_xy_wiggler *const uart_xy_wiggler_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'uart_xy_wiggler'
 * '<S1>'   : 'uart_xy_wiggler/Calibration Data'
 * '<S2>'   : 'uart_xy_wiggler/Circle'
 * '<S3>'   : 'uart_xy_wiggler/Lissajous'
 * '<S4>'   : 'uart_xy_wiggler/Lissajous Data'
 * '<S5>'   : 'uart_xy_wiggler/ignore_bad_data'
 * '<S6>'   : 'uart_xy_wiggler/ignore_bad_data1'
 * '<S7>'   : 'uart_xy_wiggler/record_and_send_via_UART'
 * '<S8>'   : 'uart_xy_wiggler/set_UART_VCflag'
 * '<S9>'   : 'uart_xy_wiggler/wiggler'
 * '<S10>'  : 'uart_xy_wiggler/Circle/Calibration Y'
 * '<S11>'  : 'uart_xy_wiggler/Circle/Calibrtaion X'
 * '<S12>'  : 'uart_xy_wiggler/Circle/Discrete-Time VCO'
 * '<S13>'  : 'uart_xy_wiggler/Circle/Discrete-Time VCO1'
 * '<S14>'  : 'uart_xy_wiggler/Circle/Calibration Y/Subsystem1'
 * '<S15>'  : 'uart_xy_wiggler/Circle/Calibrtaion X/Subsystem'
 * '<S16>'  : 'uart_xy_wiggler/Circle/Discrete-Time VCO/Check Signal Attributes'
 * '<S17>'  : 'uart_xy_wiggler/Circle/Discrete-Time VCO/Convert 2-D to 1-D'
 * '<S18>'  : 'uart_xy_wiggler/Circle/Discrete-Time VCO/Sensitivity'
 * '<S19>'  : 'uart_xy_wiggler/Circle/Discrete-Time VCO1/Check Signal Attributes'
 * '<S20>'  : 'uart_xy_wiggler/Circle/Discrete-Time VCO1/Convert 2-D to 1-D'
 * '<S21>'  : 'uart_xy_wiggler/Circle/Discrete-Time VCO1/Sensitivity'
 * '<S22>'  : 'uart_xy_wiggler/Lissajous/Calibration Y'
 * '<S23>'  : 'uart_xy_wiggler/Lissajous/Calibrtaion X'
 * '<S24>'  : 'uart_xy_wiggler/Lissajous/Cos(5wt)'
 * '<S25>'  : 'uart_xy_wiggler/Lissajous/Cos(wt)'
 * '<S26>'  : 'uart_xy_wiggler/Lissajous/Sin(5wt)'
 * '<S27>'  : 'uart_xy_wiggler/Lissajous/Sin(wt)'
 * '<S28>'  : 'uart_xy_wiggler/Lissajous/Calibration Y/Subsystem1'
 * '<S29>'  : 'uart_xy_wiggler/Lissajous/Calibrtaion X/Subsystem'
 * '<S30>'  : 'uart_xy_wiggler/Lissajous/Cos(5wt)/Check Signal Attributes'
 * '<S31>'  : 'uart_xy_wiggler/Lissajous/Cos(5wt)/Convert 2-D to 1-D'
 * '<S32>'  : 'uart_xy_wiggler/Lissajous/Cos(5wt)/Sensitivity'
 * '<S33>'  : 'uart_xy_wiggler/Lissajous/Cos(wt)/Check Signal Attributes'
 * '<S34>'  : 'uart_xy_wiggler/Lissajous/Cos(wt)/Convert 2-D to 1-D'
 * '<S35>'  : 'uart_xy_wiggler/Lissajous/Cos(wt)/Sensitivity'
 * '<S36>'  : 'uart_xy_wiggler/Lissajous/Sin(5wt)/Check Signal Attributes'
 * '<S37>'  : 'uart_xy_wiggler/Lissajous/Sin(5wt)/Convert 2-D to 1-D'
 * '<S38>'  : 'uart_xy_wiggler/Lissajous/Sin(5wt)/Sensitivity'
 * '<S39>'  : 'uart_xy_wiggler/Lissajous/Sin(wt)/Check Signal Attributes'
 * '<S40>'  : 'uart_xy_wiggler/Lissajous/Sin(wt)/Convert 2-D to 1-D'
 * '<S41>'  : 'uart_xy_wiggler/Lissajous/Sin(wt)/Sensitivity'
 * '<S42>'  : 'uart_xy_wiggler/ignore_bad_data/Compare To Constant10'
 * '<S43>'  : 'uart_xy_wiggler/ignore_bad_data/Compare To Constant8'
 * '<S44>'  : 'uart_xy_wiggler/ignore_bad_data1/Compare To Constant10'
 * '<S45>'  : 'uart_xy_wiggler/ignore_bad_data1/Compare To Constant8'
 * '<S46>'  : 'uart_xy_wiggler/record_and_send_via_UART/Compare To Constant1'
 * '<S47>'  : 'uart_xy_wiggler/record_and_send_via_UART/Compare To Constant5'
 * '<S48>'  : 'uart_xy_wiggler/record_and_send_via_UART/Compare To Constant6'
 * '<S49>'  : 'uart_xy_wiggler/record_and_send_via_UART/Compare To Constant7'
 * '<S50>'  : 'uart_xy_wiggler/record_and_send_via_UART/Subsystem3'
 * '<S51>'  : 'uart_xy_wiggler/record_and_send_via_UART/set flag=0'
 * '<S52>'  : 'uart_xy_wiggler/set_UART_VCflag/Calibration Data Uart'
 * '<S53>'  : 'uart_xy_wiggler/set_UART_VCflag/Lissajous Data Uart'
 * '<S54>'  : 'uart_xy_wiggler/set_UART_VCflag/Set UART vc Flag=1'
 * '<S55>'  : 'uart_xy_wiggler/set_UART_VCflag/Set UART vc Flag=2'
 * '<S56>'  : 'uart_xy_wiggler/set_UART_VCflag/Set UART vc Flag=3'
 * '<S57>'  : 'uart_xy_wiggler/set_UART_VCflag/Set UART vc Flag=4'
 * '<S58>'  : 'uart_xy_wiggler/set_UART_VCflag/Set UART vc Flag=5'
 * '<S59>'  : 'uart_xy_wiggler/set_UART_VCflag/Set UART vc Flag=6'
 * '<S60>'  : 'uart_xy_wiggler/set_UART_VCflag/flag_setting'
 * '<S61>'  : 'uart_xy_wiggler/set_UART_VCflag/Calibration Data Uart/Set UART vc Flag=1'
 * '<S62>'  : 'uart_xy_wiggler/set_UART_VCflag/Calibration Data Uart/Set UART vc Flag=10'
 * '<S63>'  : 'uart_xy_wiggler/set_UART_VCflag/Calibration Data Uart/Set UART vc Flag=11'
 * '<S64>'  : 'uart_xy_wiggler/set_UART_VCflag/Calibration Data Uart/Set UART vc Flag=2'
 * '<S65>'  : 'uart_xy_wiggler/set_UART_VCflag/Calibration Data Uart/Set UART vc Flag=3'
 * '<S66>'  : 'uart_xy_wiggler/set_UART_VCflag/Calibration Data Uart/Set UART vc Flag=4'
 * '<S67>'  : 'uart_xy_wiggler/set_UART_VCflag/Calibration Data Uart/Set UART vc Flag=5'
 * '<S68>'  : 'uart_xy_wiggler/set_UART_VCflag/Calibration Data Uart/Set UART vc Flag=6'
 * '<S69>'  : 'uart_xy_wiggler/set_UART_VCflag/Calibration Data Uart/Set UART vc Flag=7'
 * '<S70>'  : 'uart_xy_wiggler/set_UART_VCflag/Calibration Data Uart/Set UART vc Flag=8'
 * '<S71>'  : 'uart_xy_wiggler/set_UART_VCflag/Lissajous Data Uart/Set UART vc Flag=1'
 * '<S72>'  : 'uart_xy_wiggler/set_UART_VCflag/Lissajous Data Uart/Set UART vc Flag=10'
 * '<S73>'  : 'uart_xy_wiggler/set_UART_VCflag/Lissajous Data Uart/Set UART vc Flag=11'
 * '<S74>'  : 'uart_xy_wiggler/set_UART_VCflag/Lissajous Data Uart/Set UART vc Flag=7'
 * '<S75>'  : 'uart_xy_wiggler/set_UART_VCflag/Lissajous Data Uart/Set UART vc Flag=8'
 * '<S76>'  : 'uart_xy_wiggler/set_UART_VCflag/Lissajous Data Uart/Set UART vc Flag=9'
 * '<S77>'  : 'uart_xy_wiggler/wiggler/Compare To Constant1'
 * '<S78>'  : 'uart_xy_wiggler/wiggler/Compare To Constant2'
 * '<S79>'  : 'uart_xy_wiggler/wiggler/Discrete-Time VCO'
 * '<S80>'  : 'uart_xy_wiggler/wiggler/Discrete-Time VCO/Check Signal Attributes'
 * '<S81>'  : 'uart_xy_wiggler/wiggler/Discrete-Time VCO/Convert 2-D to 1-D'
 * '<S82>'  : 'uart_xy_wiggler/wiggler/Discrete-Time VCO/Sensitivity'
 */
#endif                                 /* RTW_HEADER_uart_xy_wiggler_h_ */

/* [EOF] */
