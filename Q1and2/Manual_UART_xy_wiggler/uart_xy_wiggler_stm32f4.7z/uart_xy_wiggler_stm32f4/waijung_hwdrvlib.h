/*
 * File: waijung_hwdrvlib.h
 *
 * Created with Waijung Blockset
 *
 * Real-Time Workshop code generated for Simulink model uart_xy_wiggler.
 *
 * Model version                        : 1.148
 * Real-Time Workshop file version      : 8.14 (R2018a) 06-Feb-2018
 * Real-Time Workshop file generated on : Sun Jul 21 14:00:36 2019
 * TLC version                          : 8.14 (Feb 22 2018)
 * C/C++ source code generated on       : Sun Jul 21 14:00:44 2019
 *
 * Target selection: stm32f4.tlc
 * Embedded hardware selection: ARM Compatible->Cortex - M4
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_waijung_hwdrvlib_h_
#define RTW_HEADER_waijung_hwdrvlib_h_
#include <string.h>
#include "rtwtypes.h"
#include "stm32f4xx.h"

/*
 * Bit banding
 *
 * The Cortex memory map includes two bit-band regions.
 * These regions map each word in an alias region of memory to a bit in
 * a bit-band region of memory. Writing to a word in the alias region
 * has the same effect as a read-modify-write operation on the targeted bit
 * in the bit-band region.
 *
 * In the STM32F4xxx both peripheral registers and SRAM are mapped in
 * a bit-band region. This allows single bit-band write and read operations
 * to be performed.
 *
 * A mapping formula shows how to reference each word in the alias region
 * to a corresponding bit in the bit-band region. The mapping formula is:
 * bit_word_addr = bit_band_base + (byte_offset x 32) + (bit_number � 4)
 *
 * BB_base      is the base address of the bit-band region for a register. (PERIPH_BB_BASE at 0x42000000 or SRAM_BB_BASE at 0x22000000)
 * Reg_base     is the base address of a register in the memory region. (PERIPH_BASE at 0x40000000 or SRAM_BASE at 0x20000000)
 * Register     is a register in the memory region that contains the targeted bit.
 * Bit_number   is the targeted bit number (0 - 31).
 *
 * PERIPH_BB_BASE, SRAM_BB_BASE, PERIPH_BASE, and SRAM_BASE are defined in stm32f10x.h
 *
 * Example for determining bit banding bit.
 * Determine DMA Transfer Complete Flag using bit banding.
 * TCIFx is the flag for DMA Channel x
 * This bit is set by hardware. It is cleared by software writing 1 to
 * the corresponding bit in the DMA_IFCR register.
 * TCIFx = 0: No transfer complete (TC) event on channel x
 * TCIFx = 1: A transfer complete (TC) event occurred on channel x
 *
 * DMA Channel:       1 2 3  4  5  6  7
 * Flag bit position: 1 5 9 13 17 21 25 (in DMA_ISR register)
 * (For DMA2 Channel 6 and 7 is irrelevant since it only has 5 channels.)
 *
 * CTCIFx: Channel x transfer complete clear (x = 1 ..7)
 * This bit is set and cleared by software.
 * CTCIFx = 0: No effect
 * CTCIFx = 1: Clear the corresponding TCIF flag in the DMA_ISR register
 *
 */
#define BitBanding(Register, Bit_number, Reg_base, BB_base) ((volatile uint32_t*) ((BB_base) + (((uint32_t) &(Register)) - ((Reg_base))<<5) + ((Bit_number)<<2)))
#define Peripheral_BB(Register, Bit_number) BitBanding(Register, Bit_number, PERIPH_BASE, PERIPH_BB_BASE)
#define SRAM_BB(Register, Bit_number)  BitBanding(Register, Bit_number, SRAM_BASE, SRAM_BB_BASE)

/*
 * Sample usage:
 * USART1->SR can be found from "stm32f4xx.h" and USART_FLAG_TC (6) can be found from "stm32f4xx_usart.h"
 * #define USART1_TC Peripheral_BB(USART1->SR, 6) USART_SR.TC bit
 *
 * Another example:
 * #define GPIOC_8 Peripheral_BB(GPIOC->ODR, 8)
 * *GPIOC_8 = 1;
 */

/*
 * Systick is configured such that the SysTick interrupt every 0.001 sec
 * which is the base sample time of the system.
 */
#define SYSTICKRELOADVALUE             180000

/*
 * HCLK (Hz)
 */
#define HCLK                           180000000

/*
 * Each Systick counter is TIMEPERSYSTICK sec.
 */
#define TIMEPERSYSTICK                 0.001 / 180000

/* ########################################################################
 * Timer
 * ########################################################################
 */
#define SYS_CURRENT_TICK               (SysTick->VAL)
#define SYS_TICKSTEP                   0.001f

typedef struct {
  uint32_t start;
  uint32_t length;
} SYS_TIMER_STRUCT;

#define SYSTIMER_FLAGS_TIMEOUT         0x01

typedef struct {
  uint8_t flags;
  uint32_t tid;                        /* Tick count */
  uint32_t tick;                       /* Capture cuttent tick */
  uint32_t target_us;                  /* Target of systick */
} SYS_TIMER_uS_STRUCT;

extern volatile unsigned int systick_count;
void SysTimer_Start(SYS_TIMER_STRUCT* timer, uint32_t ms);
void SysTimer_uS_Start(SYS_TIMER_uS_STRUCT *timer, uint32_t us);
int SysTimer_IsTimeout(SYS_TIMER_STRUCT* timer);
int SysTimer_uS_IsTimeout(SYS_TIMER_uS_STRUCT* timer);
void SysTimer_delay_us(uint32_t us);

/* ########################################################################
 * Name: <S7>/DC_enable
 * Id: record_and_send_via_UARTDC_enable
 * ########################################################################
 */
#define record_and_send_via_UARTDC_enable_B0 Peripheral_BB(GPIOB->ODR, 0) /* Output pin */
#define record_and_send_via_UARTDC_enable_B7 Peripheral_BB(GPIOB->ODR, 7) /* Output pin */
#define record_and_send_via_UARTDC_enable_B14 Peripheral_BB(GPIOB->ODR, 14) /* Output pin */

/*
 * Define PWM Generation Scale Factor
 * From TIMx_CCRx = TIMx_ARR * (Duty Cycle / 100)
 * TIMx_CCRx = (TIMx_ARR/100) * Duty Cycle
 */
#define wigglerBasicPWM_TIM3_ARR       4500
#define wigglerBasicPWM_SF             ((float)wigglerBasicPWM_TIM3_ARR / 100)

/* ########################################################################
 * Name: <S9>/Digital Output1
 * Id: wigglerDigitalOutput1
 * ########################################################################
 */
#define wigglerDigitalOutput1_F13      Peripheral_BB(GPIOF->ODR, 13) /* Output pin */
#define wigglerDigitalOutput1_F14      Peripheral_BB(GPIOF->ODR, 14) /* Output pin */

/* ########################################################################
 * Name: <S9>/Digital Output2
 * Id: wigglerDigitalOutput2
 * ########################################################################
 */
#define wigglerDigitalOutput2_D0       Peripheral_BB(GPIOD->ODR, 0) /* Output pin */
#define wigglerDigitalOutput2_D7       Peripheral_BB(GPIOD->ODR, 7) /* Output pin */

extern volatile unsigned int systick_count;

/* S-Function Block: <S1>/Volatile Data Storage1 */
extern volatile double CalibrationDataVolatileDataStorage1_ab3;

/* S-Function Block: <S1>/Volatile Data Storage11 */
extern volatile double CalibrationDataVolatileDataStorage11_ab1;

/* S-Function Block: <S1>/Volatile Data Storage12 */
extern volatile double CalibrationDataVolatileDataStorage12_ab2;

/* S-Function Block: <S1>/Volatile Data Storage2 */
extern volatile double CalibrationDataVolatileDataStorage2_ab4;

/* S-Function Block: <S1>/Volatile Data Storage3 */
extern volatile double CalibrationDataVolatileDataStorage3_ab5;

/* S-Function Block: <S1>/Volatile Data Storage4 */
extern volatile double CalibrationDataVolatileDataStorage4_ab6;

/* S-Function Block: <S1>/Volatile Data Storage5 */
extern volatile double CalibrationDataVolatileDataStorage5_ab7;

/* S-Function Block: <S1>/Volatile Data Storage6 */
extern volatile double CalibrationDataVolatileDataStorage6_ab8;

/* S-Function Block: <S1>/Volatile Data Storage7 */
extern volatile double CalibrationDataVolatileDataStorage7_ab9;

/* S-Function Block: <S1>/Volatile Data Storage8 */
extern volatile double CalibrationDataVolatileDataStorage8_ab10;

/* S-Function Block: <S4>/Volatile Data Storage10 */
extern volatile double LissajousDataVolatileDataStorage10_Ays;

/* S-Function Block: <S4>/Volatile Data Storage11 */
extern volatile double LissajousDataVolatileDataStorage11_Ayc;

/* S-Function Block: <S4>/Volatile Data Storage12 */
extern volatile double LissajousDataVolatileDataStorage12_Axs;

/* S-Function Block: <S4>/Volatile Data Storage7 */
extern volatile double LissajousDataVolatileDataStorage7_A_Laser;

/* S-Function Block: <S4>/Volatile Data Storage8 */
extern volatile double LissajousDataVolatileDataStorage8_LissaFreq;

/* S-Function Block: <S4>/Volatile Data Storage9 */
extern volatile double LissajousDataVolatileDataStorage9_Axc;

/* S-Function Block: <Root>/Volatile Data Storage1 */
extern volatile float VolatileDataStorage1_Laser;

/* S-Function Block: <Root>/Volatile Data Storage2 */
extern volatile double VolatileDataStorage2_vcx;

/* S-Function Block: <Root>/Volatile Data Storage3 */
extern volatile uint8_t VolatileDataStorage3_flag;

/* S-Function Block: <Root>/Volatile Data Storage4 */
extern volatile double VolatileDataStorage4_CircleFlag;

/* S-Function Block: <Root>/Volatile Data Storage5 */
extern volatile double VolatileDataStorage5_CircleFrequency;

/* S-Function Block: <Root>/Volatile Data Storage6 */
extern volatile double VolatileDataStorage6_vcy;

/* S-Function Block: <Root>/Volatile Data Storage7 */
extern volatile double VolatileDataStorage7_CircleR;

/* ########################################################################
 * UART Utilities for packet processing
 * ########################################################################
 */
/* UART packet process struct */
typedef enum {
  txIdle = 0,
  txBusy
} UART_TX_STATE;

/* Data read structure */
typedef struct {
  uint16_t index;                      /* Index of data in buffer */
  uint16_t count;                      /* Return data count */
  uint8_t *buffer;                     /* Return buffer pointer of valid data */
} UARTRX_BUFFER_READ_STRUCT;

/* ########################################################################
 * Name: <S50>/UART Tx3
 * Id: record_and_send_via_UARTSubsystem3UARTTx3
 * ########################################################################
 */
void enable_record_and_send_via_UARTSubsystem3UARTTx3(void);

/* ########################################################################
 * Name: <Root>/UART Setup
 * Id: UARTSetup
 * ########################################################################
 */
#define UTX3_BUFFER_SIZE               512

extern uint8_t UART3_Tx_Buffer[];
extern UART_TX_STATE UARTSetup_Tx_State;
extern void UART3_TxUpdate(uint16_t count);

#define URX3_BUFFER_SIZE               512

extern uint8_t UART3_Rx_Buffer[];
extern uint8_t UART3_Temp_Buffer[];
uint16_t UART3_ReadLine(UARTRX_BUFFER_READ_STRUCT *read_struct, const char
  *terminator, uint16_t terminator_count, uint8_t *buffer, uint16_t buffer_size);
uint8_t UART3_ReadBinary(UARTRX_BUFFER_READ_STRUCT *read_struct, const char
  *header, uint16_t header_count, const char *terminator, uint16_t
  terminator_count, uint8_t *buffer, uint16_t data_count);
void UART3_RestoreBytes(UARTRX_BUFFER_READ_STRUCT *read_struct, uint16_t count);
extern uint16_t UART3_GetInitNDTR(void);
void UART3_Read(UARTRX_BUFFER_READ_STRUCT *read_struct);
void UART3_ReadEx(UARTRX_BUFFER_READ_STRUCT *read_struct, uint8_t *buffer,
                  uint16_t buffer_size, uint16_t*reading_count);
extern void UART3_Write(uint8_t* data, uint16_t count);
extern UART_TX_STATE UART3_FlushTxBuffer(void);
void waijung_usart3_initial(void);

#define WAIJUNG_USARt3_INIT()          waijung_usart3_initial()

void enable_UARTSetup(void);

/* record_and_send_via_UARTDC_enable */
void enable_record_and_send_via_UARTDC_enable(void);

/* ########################################################################
 * Name: <Root>/PWM chX
 * Id: PWMchX
 * ########################################################################
 */
void PWMchX_GetCaptured(float *pos_width, float *pos_duty, float *freq, uint8_t *
  ready);
void enable_PWMchX(void);

/* ########################################################################
 * Name: <Root>/PWM chY
 * Id: PWMchY
 * ########################################################################
 */
void PWMchY_GetCaptured(float *pos_width, float *pos_duty, float *freq, uint8_t *
  ready);
void enable_PWMchY(void);
void enable_wigglerBasicPWM(void);     /* wigglerBasicPWM */

/* wigglerDigitalOutput1 */
void enable_wigglerDigitalOutput1(void);

/* wigglerDigitalOutput2 */
void enable_wigglerDigitalOutput2(void);

/* ########################################################################
 * Name: <S8>/UART Rx
 * Id: set_UART_VCflagUARTRx
 * ########################################################################
 */
extern UARTRX_BUFFER_READ_STRUCT set_UART_VCflagUARTRx_read_structure;
uint8_t set_UART_VCflagUARTRx_Receive(uint8_t *buffer, uint16_t size);

/* Data */
extern float set_UART_VCflagUARTRx_data0;

#define set_UART_VCflagUARTRx_terminator_SIZE 2

extern const char set_UART_VCflagUARTRx_terminator[];
void enable_set_UART_VCflagUARTRx(void);

/* ########################################################################
 * Name: <S8>/UART Rx1
 * Id: set_UART_VCflagUARTRx1
 * ########################################################################
 */
extern UARTRX_BUFFER_READ_STRUCT set_UART_VCflagUARTRx1_read_structure;
uint8_t set_UART_VCflagUARTRx1_Receive(uint8_t *buffer, uint16_t size);

/* Data */
extern float set_UART_VCflagUARTRx1_data0;

#define set_UART_VCflagUARTRx1_terminator_SIZE 2

extern const char set_UART_VCflagUARTRx1_terminator[];
void enable_set_UART_VCflagUARTRx1(void);

/* ########################################################################
 * Name: <S8>/UART Rx4
 * Id: set_UART_VCflagUARTRx4
 * ########################################################################
 */
extern UARTRX_BUFFER_READ_STRUCT set_UART_VCflagUARTRx4_read_structure;
uint8_t set_UART_VCflagUARTRx4_Receive(uint8_t *buffer, uint16_t size);

/* Data */
extern float set_UART_VCflagUARTRx4_data0;

#define set_UART_VCflagUARTRx4_terminator_SIZE 2

extern const char set_UART_VCflagUARTRx4_terminator[];
void enable_set_UART_VCflagUARTRx4(void);

/* ########################################################################
 * Name: <S8>/UART Rx5
 * Id: set_UART_VCflagUARTRx5
 * ########################################################################
 */
extern UARTRX_BUFFER_READ_STRUCT set_UART_VCflagUARTRx5_read_structure;
uint8_t set_UART_VCflagUARTRx5_Receive(uint8_t *buffer, uint16_t size);

/* Data */
extern float set_UART_VCflagUARTRx5_data0;

#define set_UART_VCflagUARTRx5_terminator_SIZE 2

extern const char set_UART_VCflagUARTRx5_terminator[];
void enable_set_UART_VCflagUARTRx5(void);

/* ########################################################################
 * Name: <S8>/UART Rx6
 * Id: set_UART_VCflagUARTRx6
 * ########################################################################
 */
extern UARTRX_BUFFER_READ_STRUCT set_UART_VCflagUARTRx6_read_structure;
uint8_t set_UART_VCflagUARTRx6_Receive(uint8_t *buffer, uint16_t size);

/* Data */
extern float set_UART_VCflagUARTRx6_data0;

#define set_UART_VCflagUARTRx6_terminator_SIZE 2

extern const char set_UART_VCflagUARTRx6_terminator[];
void enable_set_UART_VCflagUARTRx6(void);

/* ########################################################################
 * Name: <S8>/UART Rx2
 * Id: set_UART_VCflagUARTRx2
 * ########################################################################
 */
extern UARTRX_BUFFER_READ_STRUCT set_UART_VCflagUARTRx2_read_structure;
uint8_t set_UART_VCflagUARTRx2_Receive(uint8_t *buffer, uint16_t size);

/* Data */
extern float set_UART_VCflagUARTRx2_data0;

#define set_UART_VCflagUARTRx2_terminator_SIZE 2

extern const char set_UART_VCflagUARTRx2_terminator[];
void enable_set_UART_VCflagUARTRx2(void);

/* ########################################################################
 * Name: <S8>/UART Rx3
 * Id: set_UART_VCflagUARTRx3
 * ########################################################################
 */
extern UARTRX_BUFFER_READ_STRUCT set_UART_VCflagUARTRx3_read_structure;
uint8_t set_UART_VCflagUARTRx3_Receive(uint8_t *buffer, uint16_t size);

/* Data */
extern uint32_t set_UART_VCflagUARTRx3_data0;

#define set_UART_VCflagUARTRx3_terminator_SIZE 2

extern const char set_UART_VCflagUARTRx3_terminator[];
void enable_set_UART_VCflagUARTRx3(void);

/* ########################################################################
 * Name: <S52>/UART Rx1
 * Id: set_UART_VCflagCalibrationDataUartUARTRx1
 * ########################################################################
 */
extern UARTRX_BUFFER_READ_STRUCT
  set_UART_VCflagCalibrationDataUartUARTRx1_read_structure;
uint8_t set_UART_VCflagCalibrationDataUartUARTRx1_Receive(uint8_t *buffer,
  uint16_t size);

/* Data */
extern float set_UART_VCflagCalibrationDataUartUARTRx1_data0;

#define set_UART_VCflagCalibrationDataUartUARTRx1_terminator_SIZE 2

extern const char set_UART_VCflagCalibrationDataUartUARTRx1_terminator[];
void enable_set_UART_VCflagCalibrationDataUartUARTRx1(void);

/* ########################################################################
 * Name: <S52>/UART Rx11
 * Id: set_UART_VCflagCalibrationDataUartUARTRx11
 * ########################################################################
 */
extern UARTRX_BUFFER_READ_STRUCT
  set_UART_VCflagCalibrationDataUartUARTRx11_read_structure;
uint8_t set_UART_VCflagCalibrationDataUartUARTRx11_Receive(uint8_t *buffer,
  uint16_t size);

/* Data */
extern float set_UART_VCflagCalibrationDataUartUARTRx11_data0;

#define set_UART_VCflagCalibrationDataUartUARTRx11_terminator_SIZE 2

extern const char set_UART_VCflagCalibrationDataUartUARTRx11_terminator[];
void enable_set_UART_VCflagCalibrationDataUartUARTRx11(void);

/* ########################################################################
 * Name: <S52>/UART Rx2
 * Id: set_UART_VCflagCalibrationDataUartUARTRx2
 * ########################################################################
 */
extern UARTRX_BUFFER_READ_STRUCT
  set_UART_VCflagCalibrationDataUartUARTRx2_read_structure;
uint8_t set_UART_VCflagCalibrationDataUartUARTRx2_Receive(uint8_t *buffer,
  uint16_t size);

/* Data */
extern float set_UART_VCflagCalibrationDataUartUARTRx2_data0;

#define set_UART_VCflagCalibrationDataUartUARTRx2_terminator_SIZE 2

extern const char set_UART_VCflagCalibrationDataUartUARTRx2_terminator[];
void enable_set_UART_VCflagCalibrationDataUartUARTRx2(void);

/* ########################################################################
 * Name: <S52>/UART Rx3
 * Id: set_UART_VCflagCalibrationDataUartUARTRx3
 * ########################################################################
 */
extern UARTRX_BUFFER_READ_STRUCT
  set_UART_VCflagCalibrationDataUartUARTRx3_read_structure;
uint8_t set_UART_VCflagCalibrationDataUartUARTRx3_Receive(uint8_t *buffer,
  uint16_t size);

/* Data */
extern float set_UART_VCflagCalibrationDataUartUARTRx3_data0;

#define set_UART_VCflagCalibrationDataUartUARTRx3_terminator_SIZE 2

extern const char set_UART_VCflagCalibrationDataUartUARTRx3_terminator[];
void enable_set_UART_VCflagCalibrationDataUartUARTRx3(void);

/* ########################################################################
 * Name: <S52>/UART Rx4
 * Id: set_UART_VCflagCalibrationDataUartUARTRx4
 * ########################################################################
 */
extern UARTRX_BUFFER_READ_STRUCT
  set_UART_VCflagCalibrationDataUartUARTRx4_read_structure;
uint8_t set_UART_VCflagCalibrationDataUartUARTRx4_Receive(uint8_t *buffer,
  uint16_t size);

/* Data */
extern float set_UART_VCflagCalibrationDataUartUARTRx4_data0;

#define set_UART_VCflagCalibrationDataUartUARTRx4_terminator_SIZE 2

extern const char set_UART_VCflagCalibrationDataUartUARTRx4_terminator[];
void enable_set_UART_VCflagCalibrationDataUartUARTRx4(void);

/* ########################################################################
 * Name: <S52>/UART Rx6
 * Id: set_UART_VCflagCalibrationDataUartUARTRx6
 * ########################################################################
 */
extern UARTRX_BUFFER_READ_STRUCT
  set_UART_VCflagCalibrationDataUartUARTRx6_read_structure;
uint8_t set_UART_VCflagCalibrationDataUartUARTRx6_Receive(uint8_t *buffer,
  uint16_t size);

/* Data */
extern float set_UART_VCflagCalibrationDataUartUARTRx6_data0;

#define set_UART_VCflagCalibrationDataUartUARTRx6_terminator_SIZE 2

extern const char set_UART_VCflagCalibrationDataUartUARTRx6_terminator[];
void enable_set_UART_VCflagCalibrationDataUartUARTRx6(void);

/* ########################################################################
 * Name: <S52>/UART Rx7
 * Id: set_UART_VCflagCalibrationDataUartUARTRx7
 * ########################################################################
 */
extern UARTRX_BUFFER_READ_STRUCT
  set_UART_VCflagCalibrationDataUartUARTRx7_read_structure;
uint8_t set_UART_VCflagCalibrationDataUartUARTRx7_Receive(uint8_t *buffer,
  uint16_t size);

/* Data */
extern float set_UART_VCflagCalibrationDataUartUARTRx7_data0;

#define set_UART_VCflagCalibrationDataUartUARTRx7_terminator_SIZE 2

extern const char set_UART_VCflagCalibrationDataUartUARTRx7_terminator[];
void enable_set_UART_VCflagCalibrationDataUartUARTRx7(void);

/* ########################################################################
 * Name: <S52>/UART Rx8
 * Id: set_UART_VCflagCalibrationDataUartUARTRx8
 * ########################################################################
 */
extern UARTRX_BUFFER_READ_STRUCT
  set_UART_VCflagCalibrationDataUartUARTRx8_read_structure;
uint8_t set_UART_VCflagCalibrationDataUartUARTRx8_Receive(uint8_t *buffer,
  uint16_t size);

/* Data */
extern float set_UART_VCflagCalibrationDataUartUARTRx8_data0;

#define set_UART_VCflagCalibrationDataUartUARTRx8_terminator_SIZE 2

extern const char set_UART_VCflagCalibrationDataUartUARTRx8_terminator[];
void enable_set_UART_VCflagCalibrationDataUartUARTRx8(void);

/* ########################################################################
 * Name: <S52>/UART Rx5
 * Id: set_UART_VCflagCalibrationDataUartUARTRx5
 * ########################################################################
 */
extern UARTRX_BUFFER_READ_STRUCT
  set_UART_VCflagCalibrationDataUartUARTRx5_read_structure;
uint8_t set_UART_VCflagCalibrationDataUartUARTRx5_Receive(uint8_t *buffer,
  uint16_t size);

/* Data */
extern float set_UART_VCflagCalibrationDataUartUARTRx5_data0;

#define set_UART_VCflagCalibrationDataUartUARTRx5_terminator_SIZE 2

extern const char set_UART_VCflagCalibrationDataUartUARTRx5_terminator[];
void enable_set_UART_VCflagCalibrationDataUartUARTRx5(void);

/* ########################################################################
 * Name: <S52>/UART Rx10
 * Id: set_UART_VCflagCalibrationDataUartUARTRx10
 * ########################################################################
 */
extern UARTRX_BUFFER_READ_STRUCT
  set_UART_VCflagCalibrationDataUartUARTRx10_read_structure;
uint8_t set_UART_VCflagCalibrationDataUartUARTRx10_Receive(uint8_t *buffer,
  uint16_t size);

/* Data */
extern float set_UART_VCflagCalibrationDataUartUARTRx10_data0;

#define set_UART_VCflagCalibrationDataUartUARTRx10_terminator_SIZE 2

extern const char set_UART_VCflagCalibrationDataUartUARTRx10_terminator[];
void enable_set_UART_VCflagCalibrationDataUartUARTRx10(void);

/* ########################################################################
 * Name: <S53>/UART Rx1
 * Id: set_UART_VCflagLissajousDataUartUARTRx1
 * ########################################################################
 */
extern UARTRX_BUFFER_READ_STRUCT
  set_UART_VCflagLissajousDataUartUARTRx1_read_structure;
uint8_t set_UART_VCflagLissajousDataUartUARTRx1_Receive(uint8_t *buffer,
  uint16_t size);

/* Data */
extern float set_UART_VCflagLissajousDataUartUARTRx1_data0;

#define set_UART_VCflagLissajousDataUartUARTRx1_terminator_SIZE 2

extern const char set_UART_VCflagLissajousDataUartUARTRx1_terminator[];
void enable_set_UART_VCflagLissajousDataUartUARTRx1(void);

/* ########################################################################
 * Name: <S53>/UART Rx11
 * Id: set_UART_VCflagLissajousDataUartUARTRx11
 * ########################################################################
 */
extern UARTRX_BUFFER_READ_STRUCT
  set_UART_VCflagLissajousDataUartUARTRx11_read_structure;
uint8_t set_UART_VCflagLissajousDataUartUARTRx11_Receive(uint8_t *buffer,
  uint16_t size);

/* Data */
extern float set_UART_VCflagLissajousDataUartUARTRx11_data0;

#define set_UART_VCflagLissajousDataUartUARTRx11_terminator_SIZE 2

extern const char set_UART_VCflagLissajousDataUartUARTRx11_terminator[];
void enable_set_UART_VCflagLissajousDataUartUARTRx11(void);

/* ########################################################################
 * Name: <S53>/UART Rx7
 * Id: set_UART_VCflagLissajousDataUartUARTRx7
 * ########################################################################
 */
extern UARTRX_BUFFER_READ_STRUCT
  set_UART_VCflagLissajousDataUartUARTRx7_read_structure;
uint8_t set_UART_VCflagLissajousDataUartUARTRx7_Receive(uint8_t *buffer,
  uint16_t size);

/* Data */
extern float set_UART_VCflagLissajousDataUartUARTRx7_data0;

#define set_UART_VCflagLissajousDataUartUARTRx7_terminator_SIZE 2

extern const char set_UART_VCflagLissajousDataUartUARTRx7_terminator[];
void enable_set_UART_VCflagLissajousDataUartUARTRx7(void);

/* ########################################################################
 * Name: <S53>/UART Rx8
 * Id: set_UART_VCflagLissajousDataUartUARTRx8
 * ########################################################################
 */
extern UARTRX_BUFFER_READ_STRUCT
  set_UART_VCflagLissajousDataUartUARTRx8_read_structure;
uint8_t set_UART_VCflagLissajousDataUartUARTRx8_Receive(uint8_t *buffer,
  uint16_t size);

/* Data */
extern float set_UART_VCflagLissajousDataUartUARTRx8_data0;

#define set_UART_VCflagLissajousDataUartUARTRx8_terminator_SIZE 2

extern const char set_UART_VCflagLissajousDataUartUARTRx8_terminator[];
void enable_set_UART_VCflagLissajousDataUartUARTRx8(void);

/* ########################################################################
 * Name: <S53>/UART Rx9
 * Id: set_UART_VCflagLissajousDataUartUARTRx9
 * ########################################################################
 */
extern UARTRX_BUFFER_READ_STRUCT
  set_UART_VCflagLissajousDataUartUARTRx9_read_structure;
uint8_t set_UART_VCflagLissajousDataUartUARTRx9_Receive(uint8_t *buffer,
  uint16_t size);

/* Data */
extern float set_UART_VCflagLissajousDataUartUARTRx9_data0;

#define set_UART_VCflagLissajousDataUartUARTRx9_terminator_SIZE 2

extern const char set_UART_VCflagLissajousDataUartUARTRx9_terminator[];
void enable_set_UART_VCflagLissajousDataUartUARTRx9(void);

/* ########################################################################
 * Name: <S53>/UART Rx10
 * Id: set_UART_VCflagLissajousDataUartUARTRx10
 * ########################################################################
 */
extern UARTRX_BUFFER_READ_STRUCT
  set_UART_VCflagLissajousDataUartUARTRx10_read_structure;
uint8_t set_UART_VCflagLissajousDataUartUARTRx10_Receive(uint8_t *buffer,
  uint16_t size);

/* Data */
extern float set_UART_VCflagLissajousDataUartUARTRx10_data0;

#define set_UART_VCflagLissajousDataUartUARTRx10_terminator_SIZE 2

extern const char set_UART_VCflagLissajousDataUartUARTRx10_terminator[];
void enable_set_UART_VCflagLissajousDataUartUARTRx10(void);

#endif                                 /* RTW_HEADER_waijung_hwdrvlib_h_ */

/* [EOF] */
