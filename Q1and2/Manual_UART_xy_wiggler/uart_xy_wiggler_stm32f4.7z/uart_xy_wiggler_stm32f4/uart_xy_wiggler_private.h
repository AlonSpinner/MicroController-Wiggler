/*
 * File: uart_xy_wiggler_private.h
 *
 * Created with Waijung Blockset
 *
 * Real-Time Workshop code generated for Simulink model uart_xy_wiggler.
 *
 * Model version                        : 1.148
 * Real-Time Workshop file version      : 8.14 (R2018a) 06-Feb-2018
 * Real-Time Workshop file generated on : Sun Jul 21 14:00:36 2019
 * TLC version                          : 8.14 (Feb 22 2018)
 * C/C++ source code generated on       : Sun Jul 21 14:00:44 2019
 *
 * Target selection: stm32f4.tlc
 * Embedded hardware selection: ARM Compatible->Cortex - M4
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_uart_xy_wiggler_private_h_
#define RTW_HEADER_uart_xy_wiggler_private_h_
#include "rtwtypes.h"
#include "uart_xy_wiggler.h"
#include "dsp_rt.h"                    /* DSP System Toolbox general run time support functions */
#include "dspeph_rt.h"                 /* DSP System Toolbox run time support library */

extern real_T rt_modd_snf(real_T u0, real_T u1);
extern void uart_xy_wigg_MedianFilter1_Init(rtDW_MedianFilter1_uart_xy_wigg
  *localDW);
extern void uart_xy_wig_MedianFilter1_Start(rtDW_MedianFilter1_uart_xy_wigg
  *localDW);
extern void uart_xy_wiggler_MedianFilter1(real32_T rtu_0,
  rtB_MedianFilter1_uart_xy_wiggl *localB, rtDW_MedianFilter1_uart_xy_wigg
  *localDW);
extern void uart_xy_wigg_MedianFilter1_Term(rtDW_MedianFilter1_uart_xy_wigg
  *localDW);

#endif                                 /* RTW_HEADER_uart_xy_wiggler_private_h_ */

/* [EOF] */
