/*
 * File: waijung_hwdrvlib.c
 *
 * Created with Waijung Blockset
 *
 * Real-Time Workshop code generated for Simulink model uart_xy_wiggler.
 *
 * Model version                        : 1.148
 * Real-Time Workshop file version      : 8.14 (R2018a) 06-Feb-2018
 * Real-Time Workshop file generated on : Sun Jul 21 14:00:36 2019
 * TLC version                          : 8.14 (Feb 22 2018)
 * C/C++ source code generated on       : Sun Jul 21 14:00:44 2019
 *
 * Target selection: stm32f4.tlc
 * Embedded hardware selection: ARM Compatible->Cortex - M4
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "waijung_hwdrvlib.h"

/* S-Function Block: <S1>/Volatile Data Storage1 */
volatile double CalibrationDataVolatileDataStorage1_ab3;

/* S-Function Block: <S1>/Volatile Data Storage11 */
volatile double CalibrationDataVolatileDataStorage11_ab1;

/* S-Function Block: <S1>/Volatile Data Storage12 */
volatile double CalibrationDataVolatileDataStorage12_ab2;

/* S-Function Block: <S1>/Volatile Data Storage2 */
volatile double CalibrationDataVolatileDataStorage2_ab4;

/* S-Function Block: <S1>/Volatile Data Storage3 */
volatile double CalibrationDataVolatileDataStorage3_ab5;

/* S-Function Block: <S1>/Volatile Data Storage4 */
volatile double CalibrationDataVolatileDataStorage4_ab6;

/* S-Function Block: <S1>/Volatile Data Storage5 */
volatile double CalibrationDataVolatileDataStorage5_ab7;

/* S-Function Block: <S1>/Volatile Data Storage6 */
volatile double CalibrationDataVolatileDataStorage6_ab8;

/* S-Function Block: <S1>/Volatile Data Storage7 */
volatile double CalibrationDataVolatileDataStorage7_ab9;

/* S-Function Block: <S1>/Volatile Data Storage8 */
volatile double CalibrationDataVolatileDataStorage8_ab10;

/* S-Function Block: <S4>/Volatile Data Storage10 */
volatile double LissajousDataVolatileDataStorage10_Ays;

/* S-Function Block: <S4>/Volatile Data Storage11 */
volatile double LissajousDataVolatileDataStorage11_Ayc;

/* S-Function Block: <S4>/Volatile Data Storage12 */
volatile double LissajousDataVolatileDataStorage12_Axs;

/* S-Function Block: <S4>/Volatile Data Storage7 */
volatile double LissajousDataVolatileDataStorage7_A_Laser;

/* S-Function Block: <S4>/Volatile Data Storage8 */
volatile double LissajousDataVolatileDataStorage8_LissaFreq;

/* S-Function Block: <S4>/Volatile Data Storage9 */
volatile double LissajousDataVolatileDataStorage9_Axc;

/* S-Function Block: <Root>/Volatile Data Storage1 */
volatile float VolatileDataStorage1_Laser;

/* S-Function Block: <Root>/Volatile Data Storage2 */
volatile double VolatileDataStorage2_vcx;

/* S-Function Block: <Root>/Volatile Data Storage3 */
volatile uint8_t VolatileDataStorage3_flag;

/* S-Function Block: <Root>/Volatile Data Storage4 */
volatile double VolatileDataStorage4_CircleFlag;

/* S-Function Block: <Root>/Volatile Data Storage5 */
volatile double VolatileDataStorage5_CircleFrequency;

/* S-Function Block: <Root>/Volatile Data Storage6 */
volatile double VolatileDataStorage6_vcy;

/* S-Function Block: <Root>/Volatile Data Storage7 */
volatile double VolatileDataStorage7_CircleR;

/* ########################################################################
 * Name: <S50>/UART Tx3
 * Id: record_and_send_via_UARTSubsystem3UARTTx3
 * ########################################################################
 */

/* Enable UART-DMA module */
void enable_record_and_send_via_UARTSubsystem3UARTTx3(void)
{
  WAIJUNG_USARt3_INIT();
}

/* ########################################################################
 * Timer
 * ########################################################################
 */

/* Low precision non-Blocking delay timer.
 ** Relolution of timer is one TICK step interrupt.
 */
void SysTimer_Start(SYS_TIMER_STRUCT* timer, uint32_t ms)
{
  /* Calculate amount of tick count */
  timer->length = (uint32_t)((float)ms/(1000*SYS_TICKSTEP));

  /* Capture current tick */
  timer->start = (uint32_t)systick_count;
}

int SysTimer_IsTimeout(SYS_TIMER_STRUCT* timer)
{
  uint32_t Capture;

  /* Capture current tick */
  Capture = (uint32_t)systick_count;

  /* Check */
  if (Capture >= timer->start) {
    if ((Capture - timer->start) >= timer->length)
      return 1;
  } else {
    if (((0xFFFFFFFF - timer->start)+Capture) >= timer->length)
      return 1;
  }

  return 0;
}

/* Improved precision non-Blocking delay timer.
 ** Relolution of timer is 1uS.
 */
void SysTimer_uS_Start(SYS_TIMER_uS_STRUCT *timer, uint32_t us)
{
  /* Tick */
  timer->tick = SYS_CURRENT_TICK;

  /* Tick overflow count */
  timer->tid = (uint32_t)systick_count;

  /* Target */
  timer->target_us = us*((uint32_t)HCLK/1000000);
}

int SysTimer_uS_IsTimeout(SYS_TIMER_uS_STRUCT* timer)
{
  uint32_t curr_tick;
  uint32_t curr_tid;

  /* Already timeout ? */
  if (timer->target_us == 0) {
    return 1;
  }

  /* Capture current tick */
  curr_tick = SYS_CURRENT_TICK;
  curr_tid = systick_count;

  /* Processing TID*/
  while (timer->tid != curr_tid) {
    if (timer->target_us > timer->tick) {
      timer->target_us -= timer->tick;
      timer->tid ++;
      timer->tick = SYSTICKRELOADVALUE-1;
    } else {
      timer->target_us = 0;
      return 1;                        /* Timeout */
    }
  }

  /* Processing Tick */
  if ((timer->tick > curr_tick) && ((timer->tick - curr_tick) > timer->target_us))
  {
    timer->target_us = 0;
    return 1;                          /* Timeout */
  }

  /* Need wait */
  return 0;
}

/* Blocking delay, uS */
void SysTimer_delay_us(uint32_t us)
{
  SYS_TIMER_uS_STRUCT timer;
  SysTimer_uS_Start(&timer, us);
  while (SysTimer_uS_IsTimeout(&timer) == 0) ;
}

/* Blocking delay, mS */
void SysTimer_delay_ms(uint32_t ms)
{
  SYS_TIMER_STRUCT timer;
  SysTimer_Start(&timer, ms);
  while (SysTimer_IsTimeout(&timer) == 0) ;
}

/* ########################################################################
 * Name: <Root>/UART Setup
 * Id: UARTSetup
 * ########################################################################
 */

/* Tx buffer */
uint8_t UART3_Tx_Buffer[UTX3_BUFFER_SIZE];
UART_TX_STATE UARTSetup_Tx_State;

/* Rx buffer */
uint8_t UART3_Rx_Buffer[URX3_BUFFER_SIZE];
uint8_t UART3_Temp_Buffer[URX3_BUFFER_SIZE];

/* DMA Init struct */
DMA_InitTypeDef UARTSetup_DMA_Init;

/* Init buffer read */
void UART3_RestoreBytes(UARTRX_BUFFER_READ_STRUCT *read_struct, uint16_t count)
{
  uint16_t roll_count = count;

  /* Remove overflow buffer */
  while (roll_count > URX3_BUFFER_SIZE)
    roll_count -= URX3_BUFFER_SIZE;

  /* Return bytes back into buffer */
  if (roll_count > read_struct->index) {
    read_struct->index = URX3_BUFFER_SIZE - roll_count + read_struct->index;
  } else {
    read_struct->index -= roll_count;
  }
}

/* Read buffer from DMA
 ** Return value: Number of bytes vaiable.
 */
void UART3_Read(UARTRX_BUFFER_READ_STRUCT *read_struct)
{
  __IO uint16_t dma_curr_ndtr;
  __IO uint16_t dma_curr_index;
  uint16_t data_index = 0;
  uint16_t data_count = 0;

  /* Get current NDTR */
  if ((dma_curr_ndtr = DMA1_Stream1->NDTR) == 0) {/* Not initialize or turn-around state*/
    read_struct->count = 0;
    return;
  }

  /* Get current data indexs */
  dma_curr_index = URX3_BUFFER_SIZE - dma_curr_ndtr;
  if (read_struct->index < dma_curr_index) {
    /* Data is available */
    data_index = read_struct->index;
    data_count = dma_curr_index - read_struct->index;
    read_struct->index += data_count;
    read_struct->index &= (URX3_BUFFER_SIZE-1);
  } else if (read_struct->index > dma_curr_index) {
    /* Data is available with overlap */
    data_index = read_struct->index;
    data_count = URX3_BUFFER_SIZE-read_struct->index;
    read_struct->index = 0;
  } else {                             /* No new data */
  }

  /* Return the reading */
  if (data_count > 0) {
    read_struct->buffer = &UART3_Rx_Buffer[data_index];
    read_struct->count = data_count;
  } else {
    read_struct->count = 0;
  }
}

void UART3_ReadEx(UARTRX_BUFFER_READ_STRUCT *read_struct, uint8_t *buffer,
                  uint16_t buffer_size, uint16_t*reading_count)
{
  uint16_t bytes_to_read, data_read_index;
  bytes_to_read = buffer_size;         /* Tracking count of data readings */
  data_read_index = 0;                 /* Increment buffer index */
  do {
    UART3_Read(read_struct);
    if (read_struct->count <= bytes_to_read) {
      memcpy(&buffer[data_read_index], read_struct->buffer, read_struct->count);
      data_read_index += read_struct->count;
      bytes_to_read -= read_struct->count;
    } else {
      /* Return some byte back to buffer */
      //read_struct->index -= (read_struct->count - bytes_to_read);
      UART3_RestoreBytes(read_struct, (read_struct->count - bytes_to_read));/* Fixed: Waijung 14.05a */

      /* Return reading data */
      memcpy(&buffer[data_read_index], read_struct->buffer, bytes_to_read);
      bytes_to_read = 0;
    }
  } while ((bytes_to_read > 0) && (read_struct->count > 0));

  /* Number of reading bytes */
  *reading_count = buffer_size - bytes_to_read;
}

/* Read Ascii packet
 * Return char count, exclude NULL
 * Terminator: "\n", "\r", "\r\n"
 */
uint16_t UART3_ReadLine(UARTRX_BUFFER_READ_STRUCT *read_struct, const char
  *terminator, uint16_t terminator_count, uint8_t *buffer, uint16_t buffer_size)
{
  uint16_t count, packet_len = 0, receive_count = 0;
  uint16_t i;
  uint16_t terminator_found = 0;

  /* Determine maximum number of bytes to read */
  count = buffer_size - 1;
  if (count >= URX3_BUFFER_SIZE)
    count = URX3_BUFFER_SIZE-1;

  /* Ignore terminator is invalid */
  if (terminator_count < 1)
    return 0;

  /* Read packet */
  do {
    terminator_found = 0;
    UART3_Read(read_struct);           /* Check DMA buffer */
    receive_count += read_struct->count;/* Total number of data received */

    /* Search terminator */
    i = 0;
    while (!(terminator_found == terminator_count) && (i < read_struct->count))
    {
      if (read_struct->buffer[i] == (uint8_t)terminator[terminator_found/*terminator_count - 1*/
          ])
        terminator_found ++;
      i++;
    }

    packet_len += i;
    if (terminator_found == terminator_count) {
      terminator_found = 0;

      /* Roll-back buffer index */
      if ((packet_len > count) || (packet_len < terminator_count)) {/* Packet count is invalid, drop it */
        UART3_RestoreBytes(read_struct, (receive_count-packet_len));

        /* Reset */
        packet_len = 0;
        receive_count = 0;
      } else {
        UART3_RestoreBytes(read_struct, receive_count);

        /* Load data into buffer */
        UART3_ReadEx(read_struct, buffer, packet_len, &i);
        buffer[packet_len] = '\0';     /* Append NULL */

        /* Validate terminator */
        if (!strncmp((char *)&buffer[packet_len-terminator_count], terminator,
                     terminator_count)) {
          return packet_len;           /* packet reading success, return number of received bytes */
        } else {
          /* Invalid terminator */
          packet_len = 0;
          receive_count = 0;
        }
      }
    }
  } while (read_struct->count > 0);

  /* Could not find the packet terminator, reset reading struct to its original position */
  if (receive_count > 0) {
    UART3_RestoreBytes(read_struct, receive_count);
  }

  /* No byte receive */
  return 0;
}

/* Read Binary packet
 * 0: Not ready, 1: Data is ready
 */
uint8_t UART3_ReadBinary(UARTRX_BUFFER_READ_STRUCT *read_struct, const char
  *header, uint16_t header_count, const char *terminator, uint16_t
  terminator_count, uint8_t *buffer, uint16_t data_count)
{
  uint16_t receive_count = 0, drop_count = 0, binary_state = 0, binary_index = 0;
  uint16_t i;
  do {
    UART3_Read(read_struct);           /* Check DMA buffer */
    receive_count += read_struct->count;/* Total number of data received */

    /* Binary packet processing */
    for (i=0; i<read_struct->count; i++) {
      switch ( binary_state ) {
       case 0:                         /* Search for header */
        if (binary_index < header_count) {
          if (read_struct->buffer[i] == header[binary_index]) {
            binary_index ++;
          } else {
            binary_index = 0;
            drop_count = receive_count - (read_struct->count - i - 1);/* Drop packet */
          }
          break;
        } else {                       /* Change to DATA state */
          binary_index = 0;
          binary_state ++;
        }

       case 1:                         /* Wait for data */
        /* Wait for DATA */
        if (binary_index < data_count) {
          buffer[binary_index] = read_struct->buffer[i];
          binary_index ++;

          /* Check if ready (No terminator) */
          if ((binary_index >= data_count) && (terminator_count == 0)) {
            UART3_RestoreBytes(read_struct, (read_struct->count - i - 1));/* Restore some bytes */
            return 1;                  /* Return success status */
          }
          break;
        } else {                       /* Change to Terminator state */
          binary_index = 0;
          binary_state ++;
        }

       case 2:                         /* Scan for terminator */
        if (binary_index < terminator_count) {
          if (read_struct->buffer[i] == terminator[binary_index]) {
            binary_index ++;
          } else {
            binary_state = 0;
            binary_index = 0;
            drop_count = receive_count - (read_struct->count - i - 1);/* Drop packet */
          }
        }

        if (binary_index >= terminator_count) {/* Success */
          /* Restore some bytes */
          UART3_RestoreBytes(read_struct, (read_struct->count - i - 1));
          return 1;                    /* Return success status */
        }
        break;
      }
    }
  } while (read_struct->count > 0);

  /* Restore bytes */
  UART3_RestoreBytes(read_struct, (receive_count - drop_count));
  return 0;
}

/* Wait for DMA transfer to completion */
UART_TX_STATE UART3_FlushTxBuffer(void)
{
  if (UARTSetup_Tx_State != txIdle) {
    /* Chehck last DMA transmit */
    while ((DMA_GetFlagStatus(DMA1_Stream3, DMA_FLAG_TCIF3) == RESET)
           || (USART_GetFlagStatus(USART3, USART_FLAG_TC) == RESET)) {
    }

    /* Clear DMA Streams flags */
    DMA_ClearFlag(DMA1_Stream3, DMA_FLAG_HTIF3 | DMA_FLAG_TCIF3);

    /* Disable the DMA Streams */
    DMA_Cmd(DMA1_Stream3, DISABLE);

    /* Disable the USART Tx DMA request */
    USART_DMACmd(USART3, USART_DMAReq_Tx, DISABLE);

    /* Update state */
    UARTSetup_Tx_State = txIdle;
  }

  return UARTSetup_Tx_State;
}

/* Write to DMA buffer */
void UART3_Write(uint8_t* data, uint16_t count)
{
  if (count > 0) {
    /* Wait for Tx state to idle */
    UART3_FlushTxBuffer();

    /* Setup */
    memcpy(UART3_Tx_Buffer, data, count);

    /* Update */
    UART3_TxUpdate(count);
  }
}

/* Update transmit buffer */
void UART3_TxUpdate(uint16_t count)
{
  if (count > 0) {
    /* Wait for Tx state to idle */
    UART3_FlushTxBuffer();
    UARTSetup_DMA_Init.DMA_BufferSize = (uint16_t)count;
    DMA_Init(DMA1_Stream3, &UARTSetup_DMA_Init);

    /* Enable */
    USART_DMACmd(USART3, USART_DMAReq_Tx, ENABLE);
    USART_ClearFlag(USART3, USART_FLAG_TC);
    DMA_Cmd(DMA1_Stream3, ENABLE);

    /* Tx is busy */
    UARTSetup_Tx_State = txBusy;
  }
}

static uint8_t waijung_usart3_ready = 0;
void waijung_usart3_initial(void)
{
  USART_InitTypeDef USART_InitStructure;
  GPIO_InitTypeDef GPIO_InitStructure;
  if (!waijung_usart3_ready) {
    waijung_usart3_ready = 1;

    /* Enable GPIO clock */
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);

    /* Enable UART clock */
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);

    /* Enable the DMA clock */
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA1, ENABLE);

    /* Connect PXx to USARTx_Tx*/
    GPIO_PinAFConfig(GPIOD, GPIO_PinSource8, GPIO_AF_USART3);

    /* Connect PXx to USARTx_Rx*/
    GPIO_PinAFConfig(GPIOD, GPIO_PinSource9, GPIO_AF_USART3);

    /* Configure USART pin as alternate function  */
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;

    /* Configure USART Tx */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
    GPIO_Init(GPIOD, &GPIO_InitStructure);

    /* Configure USART Rx */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
    GPIO_Init(GPIOD, &GPIO_InitStructure);

    /* USART Configuration */
    USART_InitStructure.USART_BaudRate = 115200;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl =
      USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;

    /* Over sampling x8 */
    USART_OverSampling8Cmd(USART3, ENABLE);

    /* USART configuration */
    USART_Init(USART3, &USART_InitStructure);

    /* Enable USART */
    USART_Cmd(USART3, ENABLE);

    /* DMA init struct configuration */
    UARTSetup_DMA_Init.DMA_PeripheralBaseAddr = (uint32_t)(&USART3->DR);
    UARTSetup_DMA_Init.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    UARTSetup_DMA_Init.DMA_MemoryInc = DMA_MemoryInc_Enable;
    UARTSetup_DMA_Init.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
    UARTSetup_DMA_Init.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
    UARTSetup_DMA_Init.DMA_FIFOMode = DMA_FIFOMode_Disable;
    UARTSetup_DMA_Init.DMA_FIFOThreshold = DMA_FIFOThreshold_Full;
    UARTSetup_DMA_Init.DMA_MemoryBurst = DMA_MemoryBurst_Single;
    UARTSetup_DMA_Init.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;

    /* Configure DMA controller to manage RX DMA request */
    UARTSetup_DMA_Init.DMA_Channel = DMA_Channel_4;
    UARTSetup_DMA_Init.DMA_Memory0BaseAddr = (uint32_t)UART3_Rx_Buffer;
    UARTSetup_DMA_Init.DMA_DIR = DMA_DIR_PeripheralToMemory;
    UARTSetup_DMA_Init.DMA_BufferSize = (uint16_t)URX3_BUFFER_SIZE;
    UARTSetup_DMA_Init.DMA_Mode = DMA_Mode_Circular;
    UARTSetup_DMA_Init.DMA_Priority = DMA_Priority_VeryHigh;
    DMA_Init(DMA1_Stream1, &UARTSetup_DMA_Init);

    /* Enable the USART Rx DMA requests */
    USART_DMACmd(USART3, USART_DMAReq_Rx , ENABLE);

    /* Enable the DMA Stream */
    DMA_Cmd(DMA1_Stream1, ENABLE);

    /* Configure DMA controller to manage TX DMA request */
    UARTSetup_DMA_Init.DMA_Channel = DMA_Channel_4;
    UARTSetup_DMA_Init.DMA_Memory0BaseAddr = (uint32_t)UART3_Tx_Buffer;
    UARTSetup_DMA_Init.DMA_DIR = DMA_DIR_MemoryToPeripheral;
    UARTSetup_DMA_Init.DMA_BufferSize = (uint16_t)UTX3_BUFFER_SIZE;
    UARTSetup_DMA_Init.DMA_Mode = DMA_Mode_Normal;
    UARTSetup_DMA_Init.DMA_Priority = DMA_Priority_High;

    /* Init Tx state */
    UARTSetup_Tx_State = txIdle;
  }
}

/* Enable UART-DMA module */
void enable_UARTSetup(void)
{
  WAIJUNG_USARt3_INIT();
}

/* ########################################################################
 * Name: <S7>/DC_enable
 * Id: record_and_send_via_UARTDC_enable
 * ########################################################################
 */
void enable_record_and_send_via_UARTDC_enable(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);

  /* Configure PB in output Push Pull mode for record_and_send_via_UARTDC_enable Block*/
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_7 | GPIO_Pin_14;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;/* Waijung 14.xx */
  GPIO_Init(GPIOB, &GPIO_InitStructure);
}

/* ########################################################################
 * Name: <Root>/PWM chX
 * Id: PWMchX
 * ########################################################################
 */
SYS_TIMER_STRUCT PWMchX_timer = { 0, 0 };

/* Value */
__IO uint32_t PWMchX_PositiveWidth = 0;
__IO uint32_t PWMchX_Period = 0;
__IO uint8_t PWMchX_Ready = 0;

/* CC */
__IO uint32_t PWMchX_CC1 = 0;
__IO uint32_t PWMchX_CC2 = 0;
void TIM2_IRQHandler(void)
{
  /* === 32 bit timer === */
  if (TIM_GetITStatus(TIM2, TIM_IT_CC2) == SET) {
    PWMchX_CC1 = TIM_GetCapture1(TIM2);
    PWMchX_CC2 = TIM_GetCapture2(TIM2);

    /* Capture: Rising edge */
    PWMchX_Period = PWMchX_CC2;
    PWMchX_PositiveWidth = PWMchX_CC1;
    if (PWMchX_Period > 0)
      PWMchX_Ready = 1;                /* Activate capture is ready */

    /* Clear interrupt */
    TIM_ClearITPendingBit(TIM2, TIM_IT_CC2);
  }
}

void PWMchX_GetCaptured(float *pos_width, float *pos_duty, float *freq, uint8_t *
  ready)
{
  RCC_ClocksTypeDef RCC_Clocks;
  uint32_t capture_clock;
  __IO uint32_t width;
  __IO uint32_t period;
  __IO uint32_t tmp_ready;

  /* Critical section */
  __disable_irq();
  tmp_ready = PWMchX_Ready;
  width = PWMchX_PositiveWidth;
  period = PWMchX_Period;
  PWMchX_Ready = 0;                    /* Clear Ready state */
  __enable_irq();

  /* Get clock */
  RCC_GetClocksFreq(&RCC_Clocks);
  if (RCC_Clocks.HCLK_Frequency == RCC_Clocks.PCLK1_Frequency)/* Prescale = 1, then x1 */
    capture_clock = RCC_Clocks.PCLK1_Frequency;
  else                                 /* Prescale != 1, then x2 */
    capture_clock = RCC_Clocks.PCLK1_Frequency * 2;
  if (tmp_ready) {
    /* Calculation */
    *freq = (float)capture_clock/ period;/* Frequency in unit Hz */
    *pos_width = (float)width/ capture_clock;/* Positive pulse width in unit seconds */
    *pos_duty = (float)width * 100 / period;/* Positive duty cycle, 0-100% */

    /* Reset timer */
    SysTimer_Start(&PWMchX_timer, 4000);/* 4 sec */

    /* Ready */
    *ready = 1;
  } else {                             /* Estimation */
    if (SysTimer_IsTimeout(&PWMchX_timer)) {
      if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_3)) {/* Held High */
        *pos_duty = 99.99;
        *pos_width = (float)TIM_GetCapture2(TIM2)/ capture_clock;
      } else {                         /* Held Low */
        *pos_duty = 0.0;
        *pos_width = 0.0;
      }

      *freq = 0.0;
      *ready = 1;
    } else {                           /* Keep last captured value */
      *ready = 0;
    }
  }
}

void enable_PWMchX(void)
{
  TIM_ICInitTypeDef TIM_ICInitStructure;
  GPIO_InitTypeDef GPIO_InitStructure;
  NVIC_InitTypeDef NVIC_InitStructure;

  /* TIM2 clock enable */
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);

  /* GPIOB clock enable */
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);

  /* TIM2 chennel2 configuration : PB3 */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP ;
  GPIO_Init(GPIOB, &GPIO_InitStructure);

  /* Connect TIM pin to AF */
  GPIO_PinAFConfig(GPIOB, GPIO_PinSource3, GPIO_AF_TIM2);

  /* Enable the TIM2 global Interrupt */
  NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);

  /* Input capture channel */
  TIM_ICInitStructure.TIM_Channel = TIM_Channel_2;
  TIM_ICInitStructure.TIM_ICPolarity = TIM_ICPolarity_Rising;
  TIM_ICInitStructure.TIM_ICSelection = TIM_ICSelection_DirectTI;
  TIM_ICInitStructure.TIM_ICPrescaler = TIM_ICPSC_DIV1;
  TIM_ICInitStructure.TIM_ICFilter = 0x0;
  TIM_PWMIConfig(TIM2, &TIM_ICInitStructure);

  /* Select the TIM2 Input Trigger: TI2FP2 */
  TIM_SelectInputTrigger(TIM2, TIM_TS_TI2FP2);

  /* Select the slave Mode: Reset Mode */
  TIM_SelectSlaveMode(TIM2, TIM_SlaveMode_Reset);
  TIM_SelectMasterSlaveMode(TIM2,TIM_MasterSlaveMode_Enable);

  /* TIM enable counter */
  TIM_Cmd(TIM2, ENABLE);

  /* Enable the CCx Interrupt Request */
  TIM_ITConfig(TIM2, TIM_IT_CC2, ENABLE);
}

/* ########################################################################
 * Name: <Root>/PWM chY
 * Id: PWMchY
 * ########################################################################
 */
SYS_TIMER_STRUCT PWMchY_timer = { 0, 0 };

/* Value */
__IO uint32_t PWMchY_PositiveWidth = 0;
__IO uint32_t PWMchY_Period = 0;
__IO uint8_t PWMchY_Ready = 0;

/* CC */
__IO uint32_t PWMchY_CC1 = 0;
__IO uint32_t PWMchY_CC2 = 0;
void TIM5_IRQHandler(void)
{
  /* === 32 bit timer === */
  if (TIM_GetITStatus(TIM5, TIM_IT_CC1) == SET) {
    PWMchY_CC2 = TIM_GetCapture2(TIM5);
    PWMchY_CC1 = TIM_GetCapture1(TIM5);

    /* Capture: Rising edge */
    PWMchY_Period = PWMchY_CC1;
    PWMchY_PositiveWidth = PWMchY_CC2;
    if (PWMchY_Period > 0)
      PWMchY_Ready = 1;                /* Activate capture is ready */

    /* Clear interrupt */
    TIM_ClearITPendingBit(TIM5, TIM_IT_CC1);
  }
}

void PWMchY_GetCaptured(float *pos_width, float *pos_duty, float *freq, uint8_t *
  ready)
{
  RCC_ClocksTypeDef RCC_Clocks;
  uint32_t capture_clock;
  __IO uint32_t width;
  __IO uint32_t period;
  __IO uint32_t tmp_ready;

  /* Critical section */
  __disable_irq();
  tmp_ready = PWMchY_Ready;
  width = PWMchY_PositiveWidth;
  period = PWMchY_Period;
  PWMchY_Ready = 0;                    /* Clear Ready state */
  __enable_irq();

  /* Get clock */
  RCC_GetClocksFreq(&RCC_Clocks);
  if (RCC_Clocks.HCLK_Frequency == RCC_Clocks.PCLK1_Frequency)/* Prescale = 1, then x1 */
    capture_clock = RCC_Clocks.PCLK1_Frequency;
  else                                 /* Prescale != 1, then x2 */
    capture_clock = RCC_Clocks.PCLK1_Frequency * 2;
  if (tmp_ready) {
    /* Calculation */
    *freq = (float)capture_clock/ period;/* Frequency in unit Hz */
    *pos_width = (float)width/ capture_clock;/* Positive pulse width in unit seconds */
    *pos_duty = (float)width * 100 / period;/* Positive duty cycle, 0-100% */

    /* Reset timer */
    SysTimer_Start(&PWMchY_timer, 4000);/* 4 sec */

    /* Ready */
    *ready = 1;
  } else {                             /* Estimation */
    if (SysTimer_IsTimeout(&PWMchY_timer)) {
      if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0)) {/* Held High */
        *pos_duty = 99.99;
        *pos_width = (float)TIM_GetCapture1(TIM5)/ capture_clock;
      } else {                         /* Held Low */
        *pos_duty = 0.0;
        *pos_width = 0.0;
      }

      *freq = 0.0;
      *ready = 1;
    } else {                           /* Keep last captured value */
      *ready = 0;
    }
  }
}

void enable_PWMchY(void)
{
  TIM_ICInitTypeDef TIM_ICInitStructure;
  GPIO_InitTypeDef GPIO_InitStructure;
  NVIC_InitTypeDef NVIC_InitStructure;

  /* TIM5 clock enable */
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5, ENABLE);

  /* GPIOB clock enable */
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);

  /* TIM5 chennel2 configuration : PA0 */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP ;
  GPIO_Init(GPIOA, &GPIO_InitStructure);

  /* Connect TIM pin to AF */
  GPIO_PinAFConfig(GPIOA, GPIO_PinSource0, GPIO_AF_TIM5);

  /* Enable the TIM5 global Interrupt */
  NVIC_InitStructure.NVIC_IRQChannel = TIM5_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);

  /* Input capture channel */
  TIM_ICInitStructure.TIM_Channel = TIM_Channel_1;
  TIM_ICInitStructure.TIM_ICPolarity = TIM_ICPolarity_Rising;
  TIM_ICInitStructure.TIM_ICSelection = TIM_ICSelection_DirectTI;
  TIM_ICInitStructure.TIM_ICPrescaler = TIM_ICPSC_DIV1;
  TIM_ICInitStructure.TIM_ICFilter = 0x0;
  TIM_PWMIConfig(TIM5, &TIM_ICInitStructure);

  /* Select the TIM5 Input Trigger: TI1FP1 */
  TIM_SelectInputTrigger(TIM5, TIM_TS_TI1FP1);

  /* Select the slave Mode: Reset Mode */
  TIM_SelectSlaveMode(TIM5, TIM_SlaveMode_Reset);
  TIM_SelectMasterSlaveMode(TIM5,TIM_MasterSlaveMode_Enable);

  /* TIM enable counter */
  TIM_Cmd(TIM5, ENABLE);

  /* Enable the CCx Interrupt Request */
  TIM_ITConfig(TIM5, TIM_IT_CC1, ENABLE);
}

void enable_wigglerBasicPWM(void)
{
  /* Block: wigglerBasicPWM */
  GPIO_InitTypeDef GPIO_InitStructure;
  TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
  TIM_OCInitTypeDef TIM_OCInitStructure;

  /* TIM3 clock enable */
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);

  /* GPIOC clock enable */
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);

  /* GPIOC configuration */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
  GPIO_Init(GPIOC, &GPIO_InitStructure);

  /* Connect TIM3 pins to AF */
  GPIO_PinAFConfig(GPIOC, GPIO_PinSource7, GPIO_AF_TIM3);
  GPIO_PinAFConfig(GPIOC, GPIO_PinSource8, GPIO_AF_TIM3);
  GPIO_PinAFConfig(GPIOC, GPIO_PinSource9, GPIO_AF_TIM3);

  /* Time base configuration */
  TIM_TimeBaseStructure.TIM_Period = wigglerBasicPWM_TIM3_ARR-1;/* 5.0E-5 sec */
  TIM_TimeBaseStructure.TIM_Prescaler = 0;
  TIM_TimeBaseStructure.TIM_ClockDivision = 0;
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
  TIM_TimeBaseStructure.TIM_RepetitionCounter = 0x0000;
  TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);

  /* Init OC */
  TIM_OCStructInit(&TIM_OCInitStructure);
  TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
  TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;

  /* PWM1 Mode configuration: Channel 2 */
  TIM_OC2Init(TIM3, &TIM_OCInitStructure);
  TIM_OC2PreloadConfig(TIM3, TIM_OCPreload_Enable);

  /* PWM1 Mode configuration: Channel 3 */
  TIM_OC3Init(TIM3, &TIM_OCInitStructure);
  TIM_OC3PreloadConfig(TIM3, TIM_OCPreload_Enable);

  /* PWM1 Mode configuration: Channel 4 */
  TIM_OC4Init(TIM3, &TIM_OCInitStructure);
  TIM_OC4PreloadConfig(TIM3, TIM_OCPreload_Enable);

  /* TIM3 configure auto reload */
  TIM_ARRPreloadConfig(TIM3, ENABLE);

  /* TIM3 enable counter */
  TIM_Cmd(TIM3, ENABLE);
}

void disable_wigglerBasicPWM(void)
{
  TIM_Cmd(TIM3, DISABLE);
}

void terminate_wigglerBasicPWM(void)
{
  TIM_Cmd(TIM3, DISABLE);
}

/* ########################################################################
 * Name: <S9>/Digital Output1
 * Id: wigglerDigitalOutput1
 * ########################################################################
 */
void enable_wigglerDigitalOutput1(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOF, ENABLE);

  /* Configure PF in output Push Pull mode for wigglerDigitalOutput1 Block*/
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13 | GPIO_Pin_14;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;/* Waijung 14.xx */
  GPIO_Init(GPIOF, &GPIO_InitStructure);
}

/* ########################################################################
 * Name: <S9>/Digital Output2
 * Id: wigglerDigitalOutput2
 * ########################################################################
 */
void enable_wigglerDigitalOutput2(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);

  /* Configure PD in output Push Pull mode for wigglerDigitalOutput2 Block*/
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_7;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;/* Waijung 14.xx */
  GPIO_Init(GPIOD, &GPIO_InitStructure);
}

/* ########################################################################
 * Name: <S8>/UART Rx
 * Id: set_UART_VCflagUARTRx
 * ########################################################################
 */

/* Data read structure */
UARTRX_BUFFER_READ_STRUCT set_UART_VCflagUARTRx_read_structure = { 0, 0,
  (uint8_t *)0 };

/* Data */
float set_UART_VCflagUARTRx_data0 = 0;

/* Non-Blocking */
uint8_t set_UART_VCflagUARTRx_Receive(uint8_t *buffer, uint16_t size)
{
  uint8_T ready = 0;
  const char terminator[2] = { 13, 10 };/* Terminator */

  /* Rx Non-Blocking */
  if (UART3_ReadLine(&set_UART_VCflagUARTRx_read_structure, terminator, 2,
                     buffer, size) > 0) {
    ready = (uint8_t)(sscanf((const char*)buffer,"vcx=%f\r\n" ,
      &set_UART_VCflagUARTRx_data0 ) == 1);
  }

  return ready;
}

/* Enable UART-DMA module */
void enable_set_UART_VCflagUARTRx(void)
{
  WAIJUNG_USARt3_INIT();
}

/* ########################################################################
 * Name: <S8>/UART Rx1
 * Id: set_UART_VCflagUARTRx1
 * ########################################################################
 */

/* Data read structure */
UARTRX_BUFFER_READ_STRUCT set_UART_VCflagUARTRx1_read_structure = { 0, 0,
  (uint8_t *)0 };

/* Data */
float set_UART_VCflagUARTRx1_data0 = 0;

/* Non-Blocking */
uint8_t set_UART_VCflagUARTRx1_Receive(uint8_t *buffer, uint16_t size)
{
  uint8_T ready = 0;
  const char terminator[2] = { 13, 10 };/* Terminator */

  /* Rx Non-Blocking */
  if (UART3_ReadLine(&set_UART_VCflagUARTRx1_read_structure, terminator, 2,
                     buffer, size) > 0) {
    ready = (uint8_t)(sscanf((const char*)buffer,"vcy=%f\r\n" ,
      &set_UART_VCflagUARTRx1_data0 ) == 1);
  }

  return ready;
}

/* Enable UART-DMA module */
void enable_set_UART_VCflagUARTRx1(void)
{
  WAIJUNG_USARt3_INIT();
}

/* ########################################################################
 * Name: <S8>/UART Rx4
 * Id: set_UART_VCflagUARTRx4
 * ########################################################################
 */

/* Data read structure */
UARTRX_BUFFER_READ_STRUCT set_UART_VCflagUARTRx4_read_structure = { 0, 0,
  (uint8_t *)0 };

/* Data */
float set_UART_VCflagUARTRx4_data0 = 0;

/* Non-Blocking */
uint8_t set_UART_VCflagUARTRx4_Receive(uint8_t *buffer, uint16_t size)
{
  uint8_T ready = 0;
  const char terminator[2] = { 13, 10 };/* Terminator */

  /* Rx Non-Blocking */
  if (UART3_ReadLine(&set_UART_VCflagUARTRx4_read_structure, terminator, 2,
                     buffer, size) > 0) {
    ready = (uint8_t)(sscanf((const char*)buffer,"CircleFlag=%f\r\n" ,
      &set_UART_VCflagUARTRx4_data0 ) == 1);
  }

  return ready;
}

/* Enable UART-DMA module */
void enable_set_UART_VCflagUARTRx4(void)
{
  WAIJUNG_USARt3_INIT();
}

/* ########################################################################
 * Name: <S8>/UART Rx5
 * Id: set_UART_VCflagUARTRx5
 * ########################################################################
 */

/* Data read structure */
UARTRX_BUFFER_READ_STRUCT set_UART_VCflagUARTRx5_read_structure = { 0, 0,
  (uint8_t *)0 };

/* Data */
float set_UART_VCflagUARTRx5_data0 = 0;

/* Non-Blocking */
uint8_t set_UART_VCflagUARTRx5_Receive(uint8_t *buffer, uint16_t size)
{
  uint8_T ready = 0;
  const char terminator[2] = { 13, 10 };/* Terminator */

  /* Rx Non-Blocking */
  if (UART3_ReadLine(&set_UART_VCflagUARTRx5_read_structure, terminator, 2,
                     buffer, size) > 0) {
    ready = (uint8_t)(sscanf((const char*)buffer,"CircleFrequency=%f\r\n" ,
      &set_UART_VCflagUARTRx5_data0 ) == 1);
  }

  return ready;
}

/* Enable UART-DMA module */
void enable_set_UART_VCflagUARTRx5(void)
{
  WAIJUNG_USARt3_INIT();
}

/* ########################################################################
 * Name: <S8>/UART Rx6
 * Id: set_UART_VCflagUARTRx6
 * ########################################################################
 */

/* Data read structure */
UARTRX_BUFFER_READ_STRUCT set_UART_VCflagUARTRx6_read_structure = { 0, 0,
  (uint8_t *)0 };

/* Data */
float set_UART_VCflagUARTRx6_data0 = 0;

/* Non-Blocking */
uint8_t set_UART_VCflagUARTRx6_Receive(uint8_t *buffer, uint16_t size)
{
  uint8_T ready = 0;
  const char terminator[2] = { 13, 10 };/* Terminator */

  /* Rx Non-Blocking */
  if (UART3_ReadLine(&set_UART_VCflagUARTRx6_read_structure, terminator, 2,
                     buffer, size) > 0) {
    ready = (uint8_t)(sscanf((const char*)buffer,"CircleR=%f\r\n" ,
      &set_UART_VCflagUARTRx6_data0 ) == 1);
  }

  return ready;
}

/* Enable UART-DMA module */
void enable_set_UART_VCflagUARTRx6(void)
{
  WAIJUNG_USARt3_INIT();
}

/* ########################################################################
 * Name: <S8>/UART Rx2
 * Id: set_UART_VCflagUARTRx2
 * ########################################################################
 */

/* Data read structure */
UARTRX_BUFFER_READ_STRUCT set_UART_VCflagUARTRx2_read_structure = { 0, 0,
  (uint8_t *)0 };

/* Data */
float set_UART_VCflagUARTRx2_data0 = 0;

/* Non-Blocking */
uint8_t set_UART_VCflagUARTRx2_Receive(uint8_t *buffer, uint16_t size)
{
  uint8_T ready = 0;
  const char terminator[2] = { 13, 10 };/* Terminator */

  /* Rx Non-Blocking */
  if (UART3_ReadLine(&set_UART_VCflagUARTRx2_read_structure, terminator, 2,
                     buffer, size) > 0) {
    ready = (uint8_t)(sscanf((const char*)buffer,"laser=%f\r\n" ,
      &set_UART_VCflagUARTRx2_data0 ) == 1);
  }

  return ready;
}

/* Enable UART-DMA module */
void enable_set_UART_VCflagUARTRx2(void)
{
  WAIJUNG_USARt3_INIT();
}

/* ########################################################################
 * Name: <S8>/UART Rx3
 * Id: set_UART_VCflagUARTRx3
 * ########################################################################
 */

/* Data read structure */
UARTRX_BUFFER_READ_STRUCT set_UART_VCflagUARTRx3_read_structure = { 0, 0,
  (uint8_t *)0 };

/* Data */
uint32_t set_UART_VCflagUARTRx3_data0 = 0;

/* Non-Blocking */
uint8_t set_UART_VCflagUARTRx3_Receive(uint8_t *buffer, uint16_t size)
{
  uint8_T ready = 0;
  const char terminator[2] = { 13, 10 };/* Terminator */

  /* Rx Non-Blocking */
  if (UART3_ReadLine(&set_UART_VCflagUARTRx3_read_structure, terminator, 2,
                     buffer, size) > 0) {
    ready = (uint8_t)(sscanf((const char*)buffer,"flag=%u\r\n" ,
      &set_UART_VCflagUARTRx3_data0 ) == 1);
  }

  return ready;
}

/* Enable UART-DMA module */
void enable_set_UART_VCflagUARTRx3(void)
{
  WAIJUNG_USARt3_INIT();
}

/* ########################################################################
 * Name: <S52>/UART Rx1
 * Id: set_UART_VCflagCalibrationDataUartUARTRx1
 * ########################################################################
 */

/* Data read structure */
UARTRX_BUFFER_READ_STRUCT
  set_UART_VCflagCalibrationDataUartUARTRx1_read_structure = { 0, 0, (uint8_t *)
  0 };

/* Data */
float set_UART_VCflagCalibrationDataUartUARTRx1_data0 = 0;

/* Non-Blocking */
uint8_t set_UART_VCflagCalibrationDataUartUARTRx1_Receive(uint8_t *buffer,
  uint16_t size)
{
  uint8_T ready = 0;
  const char terminator[2] = { 13, 10 };/* Terminator */

  /* Rx Non-Blocking */
  if (UART3_ReadLine(&set_UART_VCflagCalibrationDataUartUARTRx1_read_structure,
                     terminator, 2, buffer, size) > 0) {
    ready = (uint8_t)(sscanf((const char*)buffer,"ab3=%f\r\n" ,
      &set_UART_VCflagCalibrationDataUartUARTRx1_data0 ) == 1);
  }

  return ready;
}

/* Enable UART-DMA module */
void enable_set_UART_VCflagCalibrationDataUartUARTRx1(void)
{
  WAIJUNG_USARt3_INIT();
}

/* ########################################################################
 * Name: <S52>/UART Rx11
 * Id: set_UART_VCflagCalibrationDataUartUARTRx11
 * ########################################################################
 */

/* Data read structure */
UARTRX_BUFFER_READ_STRUCT
  set_UART_VCflagCalibrationDataUartUARTRx11_read_structure = { 0, 0, (uint8_t *)
  0 };

/* Data */
float set_UART_VCflagCalibrationDataUartUARTRx11_data0 = 0;

/* Non-Blocking */
uint8_t set_UART_VCflagCalibrationDataUartUARTRx11_Receive(uint8_t *buffer,
  uint16_t size)
{
  uint8_T ready = 0;
  const char terminator[2] = { 13, 10 };/* Terminator */

  /* Rx Non-Blocking */
  if (UART3_ReadLine(&set_UART_VCflagCalibrationDataUartUARTRx11_read_structure,
                     terminator, 2, buffer, size) > 0) {
    ready = (uint8_t)(sscanf((const char*)buffer,"ab2=%f\r\n" ,
      &set_UART_VCflagCalibrationDataUartUARTRx11_data0 ) == 1);
  }

  return ready;
}

/* Enable UART-DMA module */
void enable_set_UART_VCflagCalibrationDataUartUARTRx11(void)
{
  WAIJUNG_USARt3_INIT();
}

/* ########################################################################
 * Name: <S52>/UART Rx2
 * Id: set_UART_VCflagCalibrationDataUartUARTRx2
 * ########################################################################
 */

/* Data read structure */
UARTRX_BUFFER_READ_STRUCT
  set_UART_VCflagCalibrationDataUartUARTRx2_read_structure = { 0, 0, (uint8_t *)
  0 };

/* Data */
float set_UART_VCflagCalibrationDataUartUARTRx2_data0 = 0;

/* Non-Blocking */
uint8_t set_UART_VCflagCalibrationDataUartUARTRx2_Receive(uint8_t *buffer,
  uint16_t size)
{
  uint8_T ready = 0;
  const char terminator[2] = { 13, 10 };/* Terminator */

  /* Rx Non-Blocking */
  if (UART3_ReadLine(&set_UART_VCflagCalibrationDataUartUARTRx2_read_structure,
                     terminator, 2, buffer, size) > 0) {
    ready = (uint8_t)(sscanf((const char*)buffer,"ab4=%f\r\n" ,
      &set_UART_VCflagCalibrationDataUartUARTRx2_data0 ) == 1);
  }

  return ready;
}

/* Enable UART-DMA module */
void enable_set_UART_VCflagCalibrationDataUartUARTRx2(void)
{
  WAIJUNG_USARt3_INIT();
}

/* ########################################################################
 * Name: <S52>/UART Rx3
 * Id: set_UART_VCflagCalibrationDataUartUARTRx3
 * ########################################################################
 */

/* Data read structure */
UARTRX_BUFFER_READ_STRUCT
  set_UART_VCflagCalibrationDataUartUARTRx3_read_structure = { 0, 0, (uint8_t *)
  0 };

/* Data */
float set_UART_VCflagCalibrationDataUartUARTRx3_data0 = 0;

/* Non-Blocking */
uint8_t set_UART_VCflagCalibrationDataUartUARTRx3_Receive(uint8_t *buffer,
  uint16_t size)
{
  uint8_T ready = 0;
  const char terminator[2] = { 13, 10 };/* Terminator */

  /* Rx Non-Blocking */
  if (UART3_ReadLine(&set_UART_VCflagCalibrationDataUartUARTRx3_read_structure,
                     terminator, 2, buffer, size) > 0) {
    ready = (uint8_t)(sscanf((const char*)buffer,"ab5=%f\r\n" ,
      &set_UART_VCflagCalibrationDataUartUARTRx3_data0 ) == 1);
  }

  return ready;
}

/* Enable UART-DMA module */
void enable_set_UART_VCflagCalibrationDataUartUARTRx3(void)
{
  WAIJUNG_USARt3_INIT();
}

/* ########################################################################
 * Name: <S52>/UART Rx4
 * Id: set_UART_VCflagCalibrationDataUartUARTRx4
 * ########################################################################
 */

/* Data read structure */
UARTRX_BUFFER_READ_STRUCT
  set_UART_VCflagCalibrationDataUartUARTRx4_read_structure = { 0, 0, (uint8_t *)
  0 };

/* Data */
float set_UART_VCflagCalibrationDataUartUARTRx4_data0 = 0;

/* Non-Blocking */
uint8_t set_UART_VCflagCalibrationDataUartUARTRx4_Receive(uint8_t *buffer,
  uint16_t size)
{
  uint8_T ready = 0;
  const char terminator[2] = { 13, 10 };/* Terminator */

  /* Rx Non-Blocking */
  if (UART3_ReadLine(&set_UART_VCflagCalibrationDataUartUARTRx4_read_structure,
                     terminator, 2, buffer, size) > 0) {
    ready = (uint8_t)(sscanf((const char*)buffer,"ab8=%f\r\n" ,
      &set_UART_VCflagCalibrationDataUartUARTRx4_data0 ) == 1);
  }

  return ready;
}

/* Enable UART-DMA module */
void enable_set_UART_VCflagCalibrationDataUartUARTRx4(void)
{
  WAIJUNG_USARt3_INIT();
}

/* ########################################################################
 * Name: <S52>/UART Rx6
 * Id: set_UART_VCflagCalibrationDataUartUARTRx6
 * ########################################################################
 */

/* Data read structure */
UARTRX_BUFFER_READ_STRUCT
  set_UART_VCflagCalibrationDataUartUARTRx6_read_structure = { 0, 0, (uint8_t *)
  0 };

/* Data */
float set_UART_VCflagCalibrationDataUartUARTRx6_data0 = 0;

/* Non-Blocking */
uint8_t set_UART_VCflagCalibrationDataUartUARTRx6_Receive(uint8_t *buffer,
  uint16_t size)
{
  uint8_T ready = 0;
  const char terminator[2] = { 13, 10 };/* Terminator */

  /* Rx Non-Blocking */
  if (UART3_ReadLine(&set_UART_VCflagCalibrationDataUartUARTRx6_read_structure,
                     terminator, 2, buffer, size) > 0) {
    ready = (uint8_t)(sscanf((const char*)buffer,"ab7=%f\r\n" ,
      &set_UART_VCflagCalibrationDataUartUARTRx6_data0 ) == 1);
  }

  return ready;
}

/* Enable UART-DMA module */
void enable_set_UART_VCflagCalibrationDataUartUARTRx6(void)
{
  WAIJUNG_USARt3_INIT();
}

/* ########################################################################
 * Name: <S52>/UART Rx7
 * Id: set_UART_VCflagCalibrationDataUartUARTRx7
 * ########################################################################
 */

/* Data read structure */
UARTRX_BUFFER_READ_STRUCT
  set_UART_VCflagCalibrationDataUartUARTRx7_read_structure = { 0, 0, (uint8_t *)
  0 };

/* Data */
float set_UART_VCflagCalibrationDataUartUARTRx7_data0 = 0;

/* Non-Blocking */
uint8_t set_UART_VCflagCalibrationDataUartUARTRx7_Receive(uint8_t *buffer,
  uint16_t size)
{
  uint8_T ready = 0;
  const char terminator[2] = { 13, 10 };/* Terminator */

  /* Rx Non-Blocking */
  if (UART3_ReadLine(&set_UART_VCflagCalibrationDataUartUARTRx7_read_structure,
                     terminator, 2, buffer, size) > 0) {
    ready = (uint8_t)(sscanf((const char*)buffer,"ab9=%f\r\n" ,
      &set_UART_VCflagCalibrationDataUartUARTRx7_data0 ) == 1);
  }

  return ready;
}

/* Enable UART-DMA module */
void enable_set_UART_VCflagCalibrationDataUartUARTRx7(void)
{
  WAIJUNG_USARt3_INIT();
}

/* ########################################################################
 * Name: <S52>/UART Rx8
 * Id: set_UART_VCflagCalibrationDataUartUARTRx8
 * ########################################################################
 */

/* Data read structure */
UARTRX_BUFFER_READ_STRUCT
  set_UART_VCflagCalibrationDataUartUARTRx8_read_structure = { 0, 0, (uint8_t *)
  0 };

/* Data */
float set_UART_VCflagCalibrationDataUartUARTRx8_data0 = 0;

/* Non-Blocking */
uint8_t set_UART_VCflagCalibrationDataUartUARTRx8_Receive(uint8_t *buffer,
  uint16_t size)
{
  uint8_T ready = 0;
  const char terminator[2] = { 13, 10 };/* Terminator */

  /* Rx Non-Blocking */
  if (UART3_ReadLine(&set_UART_VCflagCalibrationDataUartUARTRx8_read_structure,
                     terminator, 2, buffer, size) > 0) {
    ready = (uint8_t)(sscanf((const char*)buffer,"ab10=%f\r\n" ,
      &set_UART_VCflagCalibrationDataUartUARTRx8_data0 ) == 1);
  }

  return ready;
}

/* Enable UART-DMA module */
void enable_set_UART_VCflagCalibrationDataUartUARTRx8(void)
{
  WAIJUNG_USARt3_INIT();
}

/* ########################################################################
 * Name: <S52>/UART Rx5
 * Id: set_UART_VCflagCalibrationDataUartUARTRx5
 * ########################################################################
 */

/* Data read structure */
UARTRX_BUFFER_READ_STRUCT
  set_UART_VCflagCalibrationDataUartUARTRx5_read_structure = { 0, 0, (uint8_t *)
  0 };

/* Data */
float set_UART_VCflagCalibrationDataUartUARTRx5_data0 = 0;

/* Non-Blocking */
uint8_t set_UART_VCflagCalibrationDataUartUARTRx5_Receive(uint8_t *buffer,
  uint16_t size)
{
  uint8_T ready = 0;
  const char terminator[2] = { 13, 10 };/* Terminator */

  /* Rx Non-Blocking */
  if (UART3_ReadLine(&set_UART_VCflagCalibrationDataUartUARTRx5_read_structure,
                     terminator, 2, buffer, size) > 0) {
    ready = (uint8_t)(sscanf((const char*)buffer,"ab6=%f\r\n" ,
      &set_UART_VCflagCalibrationDataUartUARTRx5_data0 ) == 1);
  }

  return ready;
}

/* Enable UART-DMA module */
void enable_set_UART_VCflagCalibrationDataUartUARTRx5(void)
{
  WAIJUNG_USARt3_INIT();
}

/* ########################################################################
 * Name: <S52>/UART Rx10
 * Id: set_UART_VCflagCalibrationDataUartUARTRx10
 * ########################################################################
 */

/* Data read structure */
UARTRX_BUFFER_READ_STRUCT
  set_UART_VCflagCalibrationDataUartUARTRx10_read_structure = { 0, 0, (uint8_t *)
  0 };

/* Data */
float set_UART_VCflagCalibrationDataUartUARTRx10_data0 = 0;

/* Non-Blocking */
uint8_t set_UART_VCflagCalibrationDataUartUARTRx10_Receive(uint8_t *buffer,
  uint16_t size)
{
  uint8_T ready = 0;
  const char terminator[2] = { 13, 10 };/* Terminator */

  /* Rx Non-Blocking */
  if (UART3_ReadLine(&set_UART_VCflagCalibrationDataUartUARTRx10_read_structure,
                     terminator, 2, buffer, size) > 0) {
    ready = (uint8_t)(sscanf((const char*)buffer,"ab1=%f\r\n" ,
      &set_UART_VCflagCalibrationDataUartUARTRx10_data0 ) == 1);
  }

  return ready;
}

/* Enable UART-DMA module */
void enable_set_UART_VCflagCalibrationDataUartUARTRx10(void)
{
  WAIJUNG_USARt3_INIT();
}

/* ########################################################################
 * Name: <S53>/UART Rx1
 * Id: set_UART_VCflagLissajousDataUartUARTRx1
 * ########################################################################
 */

/* Data read structure */
UARTRX_BUFFER_READ_STRUCT set_UART_VCflagLissajousDataUartUARTRx1_read_structure
  = { 0, 0, (uint8_t *)0 };

/* Data */
float set_UART_VCflagLissajousDataUartUARTRx1_data0 = 0;

/* Non-Blocking */
uint8_t set_UART_VCflagLissajousDataUartUARTRx1_Receive(uint8_t *buffer,
  uint16_t size)
{
  uint8_T ready = 0;
  const char terminator[2] = { 13, 10 };/* Terminator */

  /* Rx Non-Blocking */
  if (UART3_ReadLine(&set_UART_VCflagLissajousDataUartUARTRx1_read_structure,
                     terminator, 2, buffer, size) > 0) {
    ready = (uint8_t)(sscanf((const char*)buffer,"A_Laser=%f\r\n" ,
      &set_UART_VCflagLissajousDataUartUARTRx1_data0 ) == 1);
  }

  return ready;
}

/* Enable UART-DMA module */
void enable_set_UART_VCflagLissajousDataUartUARTRx1(void)
{
  WAIJUNG_USARt3_INIT();
}

/* ########################################################################
 * Name: <S53>/UART Rx11
 * Id: set_UART_VCflagLissajousDataUartUARTRx11
 * ########################################################################
 */

/* Data read structure */
UARTRX_BUFFER_READ_STRUCT
  set_UART_VCflagLissajousDataUartUARTRx11_read_structure = { 0, 0, (uint8_t *)0
};

/* Data */
float set_UART_VCflagLissajousDataUartUARTRx11_data0 = 0;

/* Non-Blocking */
uint8_t set_UART_VCflagLissajousDataUartUARTRx11_Receive(uint8_t *buffer,
  uint16_t size)
{
  uint8_T ready = 0;
  const char terminator[2] = { 13, 10 };/* Terminator */

  /* Rx Non-Blocking */
  if (UART3_ReadLine(&set_UART_VCflagLissajousDataUartUARTRx11_read_structure,
                     terminator, 2, buffer, size) > 0) {
    ready = (uint8_t)(sscanf((const char*)buffer,"Axs=%f\r\n" ,
      &set_UART_VCflagLissajousDataUartUARTRx11_data0 ) == 1);
  }

  return ready;
}

/* Enable UART-DMA module */
void enable_set_UART_VCflagLissajousDataUartUARTRx11(void)
{
  WAIJUNG_USARt3_INIT();
}

/* ########################################################################
 * Name: <S53>/UART Rx7
 * Id: set_UART_VCflagLissajousDataUartUARTRx7
 * ########################################################################
 */

/* Data read structure */
UARTRX_BUFFER_READ_STRUCT set_UART_VCflagLissajousDataUartUARTRx7_read_structure
  = { 0, 0, (uint8_t *)0 };

/* Data */
float set_UART_VCflagLissajousDataUartUARTRx7_data0 = 0;

/* Non-Blocking */
uint8_t set_UART_VCflagLissajousDataUartUARTRx7_Receive(uint8_t *buffer,
  uint16_t size)
{
  uint8_T ready = 0;
  const char terminator[2] = { 13, 10 };/* Terminator */

  /* Rx Non-Blocking */
  if (UART3_ReadLine(&set_UART_VCflagLissajousDataUartUARTRx7_read_structure,
                     terminator, 2, buffer, size) > 0) {
    ready = (uint8_t)(sscanf((const char*)buffer,"LissaFreq=%f\r\n" ,
      &set_UART_VCflagLissajousDataUartUARTRx7_data0 ) == 1);
  }

  return ready;
}

/* Enable UART-DMA module */
void enable_set_UART_VCflagLissajousDataUartUARTRx7(void)
{
  WAIJUNG_USARt3_INIT();
}

/* ########################################################################
 * Name: <S53>/UART Rx8
 * Id: set_UART_VCflagLissajousDataUartUARTRx8
 * ########################################################################
 */

/* Data read structure */
UARTRX_BUFFER_READ_STRUCT set_UART_VCflagLissajousDataUartUARTRx8_read_structure
  = { 0, 0, (uint8_t *)0 };

/* Data */
float set_UART_VCflagLissajousDataUartUARTRx8_data0 = 0;

/* Non-Blocking */
uint8_t set_UART_VCflagLissajousDataUartUARTRx8_Receive(uint8_t *buffer,
  uint16_t size)
{
  uint8_T ready = 0;
  const char terminator[2] = { 13, 10 };/* Terminator */

  /* Rx Non-Blocking */
  if (UART3_ReadLine(&set_UART_VCflagLissajousDataUartUARTRx8_read_structure,
                     terminator, 2, buffer, size) > 0) {
    ready = (uint8_t)(sscanf((const char*)buffer,"Axc=%f\r\n" ,
      &set_UART_VCflagLissajousDataUartUARTRx8_data0 ) == 1);
  }

  return ready;
}

/* Enable UART-DMA module */
void enable_set_UART_VCflagLissajousDataUartUARTRx8(void)
{
  WAIJUNG_USARt3_INIT();
}

/* ########################################################################
 * Name: <S53>/UART Rx9
 * Id: set_UART_VCflagLissajousDataUartUARTRx9
 * ########################################################################
 */

/* Data read structure */
UARTRX_BUFFER_READ_STRUCT set_UART_VCflagLissajousDataUartUARTRx9_read_structure
  = { 0, 0, (uint8_t *)0 };

/* Data */
float set_UART_VCflagLissajousDataUartUARTRx9_data0 = 0;

/* Non-Blocking */
uint8_t set_UART_VCflagLissajousDataUartUARTRx9_Receive(uint8_t *buffer,
  uint16_t size)
{
  uint8_T ready = 0;
  const char terminator[2] = { 13, 10 };/* Terminator */

  /* Rx Non-Blocking */
  if (UART3_ReadLine(&set_UART_VCflagLissajousDataUartUARTRx9_read_structure,
                     terminator, 2, buffer, size) > 0) {
    ready = (uint8_t)(sscanf((const char*)buffer,"Ays=%f\r\n" ,
      &set_UART_VCflagLissajousDataUartUARTRx9_data0 ) == 1);
  }

  return ready;
}

/* Enable UART-DMA module */
void enable_set_UART_VCflagLissajousDataUartUARTRx9(void)
{
  WAIJUNG_USARt3_INIT();
}

/* ########################################################################
 * Name: <S53>/UART Rx10
 * Id: set_UART_VCflagLissajousDataUartUARTRx10
 * ########################################################################
 */

/* Data read structure */
UARTRX_BUFFER_READ_STRUCT
  set_UART_VCflagLissajousDataUartUARTRx10_read_structure = { 0, 0, (uint8_t *)0
};

/* Data */
float set_UART_VCflagLissajousDataUartUARTRx10_data0 = 0;

/* Non-Blocking */
uint8_t set_UART_VCflagLissajousDataUartUARTRx10_Receive(uint8_t *buffer,
  uint16_t size)
{
  uint8_T ready = 0;
  const char terminator[2] = { 13, 10 };/* Terminator */

  /* Rx Non-Blocking */
  if (UART3_ReadLine(&set_UART_VCflagLissajousDataUartUARTRx10_read_structure,
                     terminator, 2, buffer, size) > 0) {
    ready = (uint8_t)(sscanf((const char*)buffer,"Ayc=%f\r\n" ,
      &set_UART_VCflagLissajousDataUartUARTRx10_data0 ) == 1);
  }

  return ready;
}

/* Enable UART-DMA module */
void enable_set_UART_VCflagLissajousDataUartUARTRx10(void)
{
  WAIJUNG_USARt3_INIT();
}

/* [EOF] */
