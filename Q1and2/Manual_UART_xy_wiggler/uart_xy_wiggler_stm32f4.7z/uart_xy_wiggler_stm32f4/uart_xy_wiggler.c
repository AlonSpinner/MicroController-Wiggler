/*
 * File: uart_xy_wiggler.c
 *
 * Created with Waijung Blockset
 *
 * Real-Time Workshop code generated for Simulink model uart_xy_wiggler.
 *
 * Model version                        : 1.148
 * Real-Time Workshop file version      : 8.14 (R2018a) 06-Feb-2018
 * Real-Time Workshop file generated on : Sun Jul 21 14:00:36 2019
 * TLC version                          : 8.14 (Feb 22 2018)
 * C/C++ source code generated on       : Sun Jul 21 14:00:44 2019
 *
 * Target selection: stm32f4.tlc
 * Embedded hardware selection: ARM Compatible->Cortex - M4
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "uart_xy_wiggler.h"
#include "uart_xy_wiggler_private.h"

/* Block signals (default storage) */
BlockIO_uart_xy_wiggler uart_xy_wiggler_B;

/* Block states (default storage) */
D_Work_uart_xy_wiggler uart_xy_wiggler_DWork;

/* Real-time model */
RT_MODEL_uart_xy_wiggler uart_xy_wiggler_M_;
RT_MODEL_uart_xy_wiggler *const uart_xy_wiggler_M = &uart_xy_wiggler_M_;

/* Forward declaration for local functions */
static void uart_x_MedianFilterCG_resetImpl(dsp_private_MedianFilterCG_uart *obj);
static void u_MedianFilterCG_trickleDownMax(dsp_private_MedianFilterCG_uart *obj,
  real32_T i);
static void u_MedianFilterCG_trickleDownMin(dsp_private_MedianFilterCG_uart *obj,
  real32_T i);
static void SystemProp_matlabCodegenSetAnyP(dsp_MedianFilter_uart_xy_wiggle *obj,
  boolean_T value);
static void uart_xy_wigg_SystemCore_release(dsp_MedianFilter_uart_xy_wiggle *obj);
static void uart_xy_wiggl_SystemCore_delete(dsp_MedianFilter_uart_xy_wiggle *obj);
static void matlabCodegenHandle_matlabCodeg(dsp_MedianFilter_uart_xy_wiggle *obj);
static void rate_scheduler(void);

/*
 *   This function updates active task flag for each subrate.
 * The function is called at model base rate, hence the
 * generated code self-manages all its subrates.
 */
static void rate_scheduler(void)
{
  /* Compute which subrates run during the next base time step.  Subrates
   * are an integer multiple of the base rate counter.  Therefore, the subtask
   * counter is reset when it reaches its limit (zero means run).
   */
  (uart_xy_wiggler_M->Timing.TaskCounters.TID[1])++;
  if ((uart_xy_wiggler_M->Timing.TaskCounters.TID[1]) > 9) {/* Sample time: [0.01s, 0.0s] */
    uart_xy_wiggler_M->Timing.TaskCounters.TID[1] = 0;
  }

  (uart_xy_wiggler_M->Timing.TaskCounters.TID[2])++;
  if ((uart_xy_wiggler_M->Timing.TaskCounters.TID[2]) > 99) {/* Sample time: [0.1s, 0.0s] */
    uart_xy_wiggler_M->Timing.TaskCounters.TID[2] = 0;
  }
}

static void uart_x_MedianFilterCG_resetImpl(dsp_private_MedianFilterCG_uart *obj)
{
  real32_T cnt1;
  real32_T cnt2;
  int32_T i;
  for (i = 0; i < 5; i++) {
    obj->pBuf[i] = 0.0F;
    obj->pPos[i] = 0.0F;
    obj->pHeap[i] = 0.0F;
  }

  obj->pWinLen = 5.0F;
  obj->pIdx = obj->pWinLen;
  obj->pMidHeap = (real32_T)ceil((obj->pWinLen + 1.0F) / 2.0F);
  cnt1 = (obj->pWinLen - 1.0F) / 2.0F;
  if (cnt1 < 0.0F) {
    obj->pMinHeapLength = (real32_T)ceil(cnt1);
  } else {
    obj->pMinHeapLength = (real32_T)floor(cnt1);
  }

  cnt1 = obj->pWinLen / 2.0F;
  if (cnt1 < 0.0F) {
    obj->pMaxHeapLength = (real32_T)ceil(cnt1);
  } else {
    obj->pMaxHeapLength = (real32_T)floor(cnt1);
  }

  cnt1 = 1.0F;
  cnt2 = obj->pWinLen;
  for (i = 0; i < 5; i++) {
    if ((int32_T)(real32_T)fmod(5.0F + -(real32_T)i, 2.0) == 0) {
      obj->pPos[(5 - i) - 1] = cnt1;
      cnt1++;
    } else {
      obj->pPos[(5 - i) - 1] = cnt2;
      cnt2--;
    }

    obj->pHeap[(int32_T)obj->pPos[(5 - i) - 1] - 1] = 5.0F + -(real32_T)i;
  }
}

static void u_MedianFilterCG_trickleDownMax(dsp_private_MedianFilterCG_uart *obj,
  real32_T i)
{
  real32_T temp;
  real32_T u;
  real32_T ind2;
  int32_T temp_tmp;
  boolean_T exitg1;
  exitg1 = false;
  while ((!exitg1) && (i >= -obj->pMaxHeapLength)) {
    if ((i < -1.0F) && (i > -obj->pMaxHeapLength) && (obj->pBuf[(int32_T)
         obj->pHeap[(int32_T)(i + obj->pMidHeap) - 1] - 1] < obj->pBuf[(int32_T)
         obj->pHeap[(int32_T)((i - 1.0F) + obj->pMidHeap) - 1] - 1])) {
      i--;
    }

    u = i / 2.0F;
    if (u < 0.0F) {
      u = (real32_T)ceil(u);
    } else {
      u = (real32_T)floor(u);
    }

    ind2 = i + obj->pMidHeap;
    if (!(obj->pBuf[(int32_T)obj->pHeap[(int32_T)(u + obj->pMidHeap) - 1] - 1] <
          obj->pBuf[(int32_T)obj->pHeap[(int32_T)ind2 - 1] - 1])) {
      exitg1 = true;
    } else {
      u = i / 2.0F;
      if (u < 0.0F) {
        u = (real32_T)ceil(u);
      } else {
        u = (real32_T)floor(u);
      }

      u += obj->pMidHeap;
      temp_tmp = (int32_T)u - 1;
      temp = obj->pHeap[temp_tmp];
      obj->pHeap[temp_tmp] = obj->pHeap[(int32_T)ind2 - 1];
      obj->pHeap[(int32_T)ind2 - 1] = temp;
      obj->pPos[(int32_T)obj->pHeap[(int32_T)u - 1] - 1] = u;
      obj->pPos[(int32_T)obj->pHeap[(int32_T)ind2 - 1] - 1] = ind2;
      i *= 2.0F;
    }
  }
}

static void u_MedianFilterCG_trickleDownMin(dsp_private_MedianFilterCG_uart *obj,
  real32_T i)
{
  real32_T temp;
  real32_T u;
  real32_T ind1;
  int32_T tmp;
  boolean_T exitg1;
  exitg1 = false;
  while ((!exitg1) && (i <= obj->pMinHeapLength)) {
    if ((i > 1.0F) && (i < obj->pMinHeapLength) && (obj->pBuf[(int32_T)
         obj->pHeap[(int32_T)((i + 1.0F) + obj->pMidHeap) - 1] - 1] < obj->pBuf
         [(int32_T)obj->pHeap[(int32_T)(i + obj->pMidHeap) - 1] - 1])) {
      i++;
    }

    u = i / 2.0F;
    if (u < 0.0F) {
      u = (real32_T)ceil(u);
    } else {
      u = (real32_T)floor(u);
    }

    ind1 = i + obj->pMidHeap;
    if (!(obj->pBuf[(int32_T)obj->pHeap[(int32_T)ind1 - 1] - 1] < obj->pBuf
          [(int32_T)obj->pHeap[(int32_T)(u + obj->pMidHeap) - 1] - 1])) {
      exitg1 = true;
    } else {
      u = i / 2.0F;
      if (u < 0.0F) {
        u = (real32_T)ceil(u);
      } else {
        u = (real32_T)floor(u);
      }

      u += obj->pMidHeap;
      temp = obj->pHeap[(int32_T)ind1 - 1];
      tmp = (int32_T)u - 1;
      obj->pHeap[(int32_T)ind1 - 1] = obj->pHeap[tmp];
      obj->pHeap[tmp] = temp;
      obj->pPos[(int32_T)obj->pHeap[(int32_T)ind1 - 1] - 1] = ind1;
      obj->pPos[(int32_T)obj->pHeap[(int32_T)u - 1] - 1] = u;
      i *= 2.0F;
    }
  }
}

static void SystemProp_matlabCodegenSetAnyP(dsp_MedianFilter_uart_xy_wiggle *obj,
  boolean_T value)
{
  obj->matlabCodegenIsDeleted = value;
}

static void uart_xy_wigg_SystemCore_release(dsp_MedianFilter_uart_xy_wiggle *obj)
{
  if ((obj->isInitialized == 1) && obj->isSetupComplete) {
    obj->NumChannels = -1;
    if (obj->pMID.isInitialized == 1) {
      obj->pMID.isInitialized = 2;
    }
  }
}

static void uart_xy_wiggl_SystemCore_delete(dsp_MedianFilter_uart_xy_wiggle *obj)
{
  uart_xy_wigg_SystemCore_release(obj);
}

static void matlabCodegenHandle_matlabCodeg(dsp_MedianFilter_uart_xy_wiggle *obj)
{
  if (!obj->matlabCodegenIsDeleted) {
    SystemProp_matlabCodegenSetAnyP(obj, true);
    uart_xy_wiggl_SystemCore_delete(obj);
  }
}

/*
 * System initialize for atomic system:
 *    synthesized block
 *    synthesized block
 */
void uart_xy_wigg_MedianFilter1_Init(rtDW_MedianFilter1_uart_xy_wigg *localDW)
{
  /* InitializeConditions for MATLABSystem: '<Root>/Median Filter1' */
  if (localDW->obj.pMID.isInitialized == 1) {
    uart_x_MedianFilterCG_resetImpl(&localDW->obj.pMID);
  }

  /* End of InitializeConditions for MATLABSystem: '<Root>/Median Filter1' */
}

/*
 * Start for atomic system:
 *    synthesized block
 *    synthesized block
 */
void uart_xy_wig_MedianFilter1_Start(rtDW_MedianFilter1_uart_xy_wigg *localDW)
{
  dsp_MedianFilter_uart_xy_wiggle *obj;

  /* Start for MATLABSystem: '<Root>/Median Filter1' */
  localDW->obj.matlabCodegenIsDeleted = true;
  localDW->obj.isInitialized = 0;
  localDW->obj.NumChannels = -1;
  localDW->obj.matlabCodegenIsDeleted = false;
  localDW->objisempty = true;
  obj = &localDW->obj;
  localDW->obj.isSetupComplete = false;
  localDW->obj.isInitialized = 1;
  localDW->obj.NumChannels = 1;
  obj->pMID.isInitialized = 0;
  localDW->obj.isSetupComplete = true;
}

/*
 * Output and update for atomic system:
 *    synthesized block
 *    synthesized block
 */
void uart_xy_wiggler_MedianFilter1(real32_T rtu_0,
  rtB_MedianFilter1_uart_xy_wiggl *localB, rtDW_MedianFilter1_uart_xy_wigg
  *localDW)
{
  dsp_MedianFilter_uart_xy_wiggle *obj;
  dsp_private_MedianFilterCG_uart *obj_0;
  real32_T vprev;
  real32_T p;
  boolean_T flag;
  real32_T temp;
  int32_T vprev_tmp;
  real32_T flag_tmp;
  real32_T tmp;
  boolean_T exitg1;

  /* MATLABSystem: '<Root>/Median Filter1' */
  obj = &localDW->obj;
  obj_0 = &localDW->obj.pMID;
  if (obj->pMID.isInitialized != 1) {
    obj->pMID.isSetupComplete = false;
    obj->pMID.isInitialized = 1;
    obj->pMID.isSetupComplete = true;
    uart_x_MedianFilterCG_resetImpl(&obj->pMID);
  }

  vprev_tmp = (int32_T)obj->pMID.pIdx - 1;
  vprev = obj->pMID.pBuf[vprev_tmp];
  vprev_tmp = (int32_T)obj->pMID.pIdx - 1;
  obj->pMID.pBuf[vprev_tmp] = rtu_0;
  vprev_tmp = (int32_T)obj->pMID.pIdx - 1;
  p = obj->pMID.pPos[vprev_tmp];
  obj->pMID.pIdx++;
  if (obj->pMID.pWinLen + 1.0F == obj->pMID.pIdx) {
    obj->pMID.pIdx = 1.0F;
  }

  if (p > obj->pMID.pMidHeap) {
    if (vprev < rtu_0) {
      vprev = p - obj->pMID.pMidHeap;
      u_MedianFilterCG_trickleDownMin(&obj->pMID, vprev * 2.0F);
    } else {
      vprev = p - obj->pMID.pMidHeap;
      exitg1 = false;
      while ((!exitg1) && (vprev > 0.0F)) {
        flag_tmp = vprev + obj_0->pMidHeap;
        p = (real32_T)floor(vprev / 2.0F);
        temp = p + obj_0->pMidHeap;
        flag = (obj_0->pBuf[(int32_T)obj_0->pHeap[(int32_T)flag_tmp - 1] - 1] <
                obj_0->pBuf[(int32_T)obj_0->pHeap[(int32_T)temp - 1] - 1]);
        if (!flag) {
          exitg1 = true;
        } else {
          tmp = vprev + obj_0->pMidHeap;
          flag_tmp = (real32_T)floor(vprev / 2.0F) + obj_0->pMidHeap;
          temp = obj_0->pHeap[(int32_T)tmp - 1];
          obj_0->pHeap[(int32_T)tmp - 1] = obj_0->pHeap[(int32_T)flag_tmp - 1];
          obj_0->pHeap[(int32_T)flag_tmp - 1] = temp;
          obj_0->pPos[(int32_T)obj_0->pHeap[(int32_T)tmp - 1] - 1] = tmp;
          obj_0->pPos[(int32_T)obj_0->pHeap[(int32_T)flag_tmp - 1] - 1] =
            flag_tmp;
          vprev = p;
        }
      }

      if (vprev == 0.0F) {
        u_MedianFilterCG_trickleDownMax(&obj->pMID, -1.0F);
      }
    }
  } else if (p < obj->pMID.pMidHeap) {
    if (rtu_0 < vprev) {
      vprev = p - obj->pMID.pMidHeap;
      u_MedianFilterCG_trickleDownMax(&obj->pMID, vprev * 2.0F);
    } else {
      vprev = p - obj->pMID.pMidHeap;
      exitg1 = false;
      while ((!exitg1) && (vprev < 0.0F)) {
        p = vprev / 2.0F;
        if (p < 0.0F) {
          p = (real32_T)ceil(p);
        } else {
          p = -0.0F;
        }

        flag_tmp = vprev + obj_0->pMidHeap;
        flag = (obj_0->pBuf[(int32_T)obj_0->pHeap[(int32_T)(p + obj_0->pMidHeap)
                - 1] - 1] < obj_0->pBuf[(int32_T)obj_0->pHeap[(int32_T)flag_tmp
                - 1] - 1]);
        if (!flag) {
          exitg1 = true;
        } else {
          p = vprev / 2.0F;
          if (p < 0.0F) {
            p = (real32_T)ceil(p);
          } else {
            p = -0.0F;
          }

          p += obj_0->pMidHeap;
          flag_tmp = vprev + obj_0->pMidHeap;
          vprev_tmp = (int32_T)p - 1;
          temp = obj_0->pHeap[vprev_tmp];
          obj_0->pHeap[vprev_tmp] = obj_0->pHeap[(int32_T)flag_tmp - 1];
          obj_0->pHeap[(int32_T)flag_tmp - 1] = temp;
          obj_0->pPos[(int32_T)obj_0->pHeap[(int32_T)p - 1] - 1] = p;
          obj_0->pPos[(int32_T)obj_0->pHeap[(int32_T)flag_tmp - 1] - 1] =
            flag_tmp;
          p = vprev / 2.0F;
          if (p < 0.0F) {
            vprev = (real32_T)ceil(p);
          } else {
            vprev = -0.0F;
          }
        }
      }

      if (vprev == 0.0F) {
        u_MedianFilterCG_trickleDownMin(&obj->pMID, 1.0F);
      }
    }
  } else {
    if (obj->pMID.pMaxHeapLength != 0.0F) {
      u_MedianFilterCG_trickleDownMax(&obj->pMID, -1.0F);
    }

    if (obj->pMID.pMinHeapLength > 0.0F) {
      u_MedianFilterCG_trickleDownMin(&obj->pMID, 1.0F);
    }
  }

  localB->MedianFilter1 = obj->pMID.pBuf[(int32_T)obj->pMID.pHeap[(int32_T)
    obj->pMID.pMidHeap - 1] - 1];

  /* End of MATLABSystem: '<Root>/Median Filter1' */
}

/*
 * Termination for atomic system:
 *    synthesized block
 *    synthesized block
 */
void uart_xy_wigg_MedianFilter1_Term(rtDW_MedianFilter1_uart_xy_wigg *localDW)
{
  /* Terminate for MATLABSystem: '<Root>/Median Filter1' */
  matlabCodegenHandle_matlabCodeg(&localDW->obj);
}

real_T rt_modd_snf(real_T u0, real_T u1)
{
  real_T y;
  boolean_T yEq;
  real_T q;
  y = u0;
  if (!((!rtIsNaN(u0)) && (!rtIsInf(u0)) && ((!rtIsNaN(u1)) && (!rtIsInf(u1)))))
  {
    if (u1 != 0.0) {
      y = (rtNaN);
    }
  } else if (u0 == 0.0) {
    y = u1 * 0.0;
  } else {
    if (u1 != 0.0) {
      y = fmod(u0, u1);
      yEq = (y == 0.0);
      if ((!yEq) && (u1 > floor(u1))) {
        q = fabs(u0 / u1);
        yEq = (fabs(q - floor(q + 0.5)) <= DBL_EPSILON * q);
      }

      if (yEq) {
        y = u1 * 0.0;
      } else {
        if ((u0 < 0.0) != (u1 < 0.0)) {
          y += u1;
        }
      }
    }
  }

  return y;
}

/* Model step function */
void uart_xy_wiggler_step(void)
{
  /* local block i/o variables */
  uint32_T rtb_Queue_o4;
  real32_T rtb_Switch2;
  real32_T rtb_Switch2_p;
  real32_T rtb_TmpSignalConversionAtQueueI[4];
  boolean_T rtb_LogicalOperator;
  boolean_T rtb_LogicalOperator1;
  boolean_T rtb_Queue_o2;
  boolean_T rtb_Queue_o3;
  real32_T rtb_IndexVector;
  real_T rtb_UnitDelay;
  real_T rtb_UnitDelay_o;
  real_T rtb_UnitDelay_a;
  real_T rtb_UnitDelay_f;
  real_T rtb_UnitDelay_n4;
  real_T rtb_UnitDelay_k;
  real_T rtb_UnitDelay_m;
  real_T rtb_MathFunction;
  real_T rtb_MathFunction_d;
  real_T rtb_MathFunction_i;
  real_T rtb_MathFunction_g;
  real_T rtb_MathFunction_gp;
  real_T rtb_MathFunction_a;
  real_T rtb_MathFunction_gm;
  real_T rtb_Add1;
  real_T rtb_Add_a;
  real_T rtb_Add1_0[5];
  real_T tmp[5];
  real_T tmp_0;
  int32_T i;
  real_T rtb_Add1_1[5];
  real_T tmp_1[5];
  real_T rtb_Add1_tmp;
  real_T rtb_Add1_tmp_0;
  real_T rtb_Add1_tmp_1;
  if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
    /* S-Function (waijung_vdata_read): '<Root>/flag_for_recorder_uart' */

    /* flag_for_recorder_uart */
    uart_xy_wiggler_B.flag_for_recorder_uart = (uint8_t)
      VolatileDataStorage3_flag;

    /* RelationalOperator: '<S46>/Compare' incorporates:
     *  Constant: '<S46>/Constant'
     */
    uart_xy_wiggler_B.Compare = (uart_xy_wiggler_B.flag_for_recorder_uart ==
      uart_xy_wiggler_P.CompareToConstant1_const_c);

    /* RelationalOperator: '<S47>/Compare' incorporates:
     *  Constant: '<S47>/Constant'
     */
    uart_xy_wiggler_B.Compare_i = (uart_xy_wiggler_B.flag_for_recorder_uart ==
      uart_xy_wiggler_P.CompareToConstant5_const);

    /* RelationalOperator: '<S48>/Compare' incorporates:
     *  Constant: '<S48>/Constant'
     */
    uart_xy_wiggler_B.Compare_d = (uart_xy_wiggler_B.flag_for_recorder_uart ==
      uart_xy_wiggler_P.CompareToConstant6_const);

    /* S-Function (stm32f4_digital_output): '<S7>/DC_enable' */

    /* record_and_send_via_UARTDC_enable */
    {
      *record_and_send_via_UARTDC_enable_B0 = uart_xy_wiggler_B.Compare;
      *record_and_send_via_UARTDC_enable_B7 = uart_xy_wiggler_B.Compare_i;
      *record_and_send_via_UARTDC_enable_B14 = uart_xy_wiggler_B.Compare_d;
    }

    /* S-Function (stm32f4_pwm_capture): '<Root>/PWM chX' */

    /* PWMchX: '<Root>/PWM chX' */
    PWMchX_GetCaptured( &uart_xy_wiggler_B.PWMchX_o2,
                       &uart_xy_wiggler_B.PWMchX_o3,
                       &uart_xy_wiggler_B.PWMchX_o4,
                       &uart_xy_wiggler_B.PWMchX_o1);

    /* Sum: '<Root>/Sum' incorporates:
     *  Constant: '<Root>/Constant'
     */
    rtb_IndexVector = uart_xy_wiggler_B.PWMchX_o3 -
      uart_xy_wiggler_P.Constant_Value_m;

    /* Switch: '<S5>/Switch2' incorporates:
     *  Constant: '<S42>/Constant'
     *  Constant: '<S43>/Constant'
     *  Delay: '<S5>/Delay2'
     *  Logic: '<S5>/Logical Operator4'
     *  RelationalOperator: '<S42>/Compare'
     *  RelationalOperator: '<S43>/Compare'
     */
    if ((rtb_IndexVector < uart_xy_wiggler_P.CompareToConstant8_const) &&
        (rtb_IndexVector > uart_xy_wiggler_P.CompareToConstant10_const)) {
      rtb_Switch2 = rtb_IndexVector;
    } else {
      rtb_Switch2 = uart_xy_wiggler_DWork.Delay2_DSTATE;
    }

    /* End of Switch: '<S5>/Switch2' */
    uart_xy_wiggler_MedianFilter1(rtb_Switch2, &uart_xy_wiggler_B.MedianFilter,
      &uart_xy_wiggler_DWork.MedianFilter);

    /* S-Function (stm32f4_pwm_capture): '<Root>/PWM chY' */

    /* PWMchY: '<Root>/PWM chY' */
    PWMchY_GetCaptured( &uart_xy_wiggler_B.PWMchY_o2,
                       &uart_xy_wiggler_B.PWMchY_o3,
                       &uart_xy_wiggler_B.PWMchY_o4,
                       &uart_xy_wiggler_B.PWMchY_o1);

    /* Sum: '<Root>/Sum1' incorporates:
     *  Constant: '<Root>/Constant1'
     */
    rtb_IndexVector = uart_xy_wiggler_B.PWMchY_o3 -
      uart_xy_wiggler_P.Constant1_Value_e;

    /* Switch: '<S6>/Switch2' incorporates:
     *  Constant: '<S44>/Constant'
     *  Constant: '<S45>/Constant'
     *  Delay: '<S6>/Delay2'
     *  Logic: '<S6>/Logical Operator4'
     *  RelationalOperator: '<S44>/Compare'
     *  RelationalOperator: '<S45>/Compare'
     */
    if ((rtb_IndexVector < uart_xy_wiggler_P.CompareToConstant8_const_l) &&
        (rtb_IndexVector > uart_xy_wiggler_P.CompareToConstant10_const_o)) {
      rtb_Switch2_p = rtb_IndexVector;
    } else {
      rtb_Switch2_p = uart_xy_wiggler_DWork.Delay2_DSTATE_c;
    }

    /* End of Switch: '<S6>/Switch2' */

    /* MATLABSystem: '<Root>/Median Filter1' */
    uart_xy_wiggler_MedianFilter1(rtb_Switch2_p,
      &uart_xy_wiggler_B.MedianFilter1, &uart_xy_wiggler_DWork.MedianFilter1);

    /* S-Function (waijung_vdata_read): '<Root>/Volatile Data Storage Read2' */

    /* VolatileDataStorageRead2 */
    uart_xy_wiggler_B.VolatileDataStorageRead2 = (double)
      VolatileDataStorage4_CircleFlag;

    /* S-Function (waijung_vdata_read): '<Root>/Calibration Vcx' */

    /* CalibrationVcx */
    uart_xy_wiggler_B.CalibrationVcx = (double)VolatileDataStorage2_vcx;

    /* S-Function (waijung_vdata_read): '<Root>/Calibration Vcy' */

    /* CalibrationVcy */
    uart_xy_wiggler_B.CalibrationVcy = (double)VolatileDataStorage6_vcy;

    /* S-Function (waijung_vdata_read): '<S2>/Volatile Data Storage Read5' */

    /* CircleVolatileDataStorageRead5 */
    uart_xy_wiggler_B.VolatileDataStorageRead5 = (double)
      VolatileDataStorage7_CircleR;

    /* UnitDelay: '<S13>/Unit Delay' */
    rtb_UnitDelay = uart_xy_wiggler_DWork.UnitDelay_DSTATE;

    /* UnitDelay: '<S12>/Unit Delay' */
    rtb_UnitDelay_o = uart_xy_wiggler_DWork.UnitDelay_DSTATE_d;

    /* S-Function (waijung_vdata_read): '<S15>/Volatile Data Storage Read4' */

    /* CircleCalibrtaionXSubsystemVolatileDataStorageRead4 */
    uart_xy_wiggler_B.VolatileDataStorageRead4 = (double)
      CalibrationDataVolatileDataStorage11_ab1;

    /* S-Function (waijung_vdata_read): '<S15>/Volatile Data Storage Read1' */

    /* CircleCalibrtaionXSubsystemVolatileDataStorageRead1 */
    uart_xy_wiggler_B.VolatileDataStorageRead1 = (double)
      CalibrationDataVolatileDataStorage12_ab2;

    /* S-Function (waijung_vdata_read): '<S15>/Volatile Data Storage Read2' */

    /* CircleCalibrtaionXSubsystemVolatileDataStorageRead2 */
    uart_xy_wiggler_B.VolatileDataStorageRead2_h = (double)
      CalibrationDataVolatileDataStorage1_ab3;

    /* S-Function (waijung_vdata_read): '<S15>/Volatile Data Storage Read3' */

    /* CircleCalibrtaionXSubsystemVolatileDataStorageRead3 */
    uart_xy_wiggler_B.VolatileDataStorageRead3 = (double)
      CalibrationDataVolatileDataStorage2_ab4;

    /* S-Function (waijung_vdata_read): '<S15>/Volatile Data Storage Read5' */

    /* CircleCalibrtaionXSubsystemVolatileDataStorageRead5 */
    uart_xy_wiggler_B.VolatileDataStorageRead5_o = (double)
      CalibrationDataVolatileDataStorage3_ab5;

    /* S-Function (waijung_vdata_read): '<S14>/Volatile Data Storage Read9' */

    /* CircleCalibrationYSubsystem1VolatileDataStorageRead9 */
    uart_xy_wiggler_B.VolatileDataStorageRead9 = (double)
      CalibrationDataVolatileDataStorage4_ab6;

    /* S-Function (waijung_vdata_read): '<S14>/Volatile Data Storage Read6' */

    /* CircleCalibrationYSubsystem1VolatileDataStorageRead6 */
    uart_xy_wiggler_B.VolatileDataStorageRead6 = (double)
      CalibrationDataVolatileDataStorage5_ab7;

    /* S-Function (waijung_vdata_read): '<S14>/Volatile Data Storage Read7' */

    /* CircleCalibrationYSubsystem1VolatileDataStorageRead7 */
    uart_xy_wiggler_B.VolatileDataStorageRead7 = (double)
      CalibrationDataVolatileDataStorage6_ab8;

    /* S-Function (waijung_vdata_read): '<S14>/Volatile Data Storage Read8' */

    /* CircleCalibrationYSubsystem1VolatileDataStorageRead8 */
    uart_xy_wiggler_B.VolatileDataStorageRead8 = (double)
      CalibrationDataVolatileDataStorage7_ab9;

    /* S-Function (waijung_vdata_read): '<S14>/Volatile Data Storage Read10' */

    /* CircleCalibrationYSubsystem1VolatileDataStorageRead10 */
    uart_xy_wiggler_B.VolatileDataStorageRead10 = (double)
      CalibrationDataVolatileDataStorage8_ab10;

    /* S-Function (waijung_vdata_read): '<S3>/Volatile Data Storage Read5' */

    /* LissajousVolatileDataStorageRead5 */
    uart_xy_wiggler_B.VolatileDataStorageRead5_f = (double)
      LissajousDataVolatileDataStorage9_Axc;

    /* UnitDelay: '<S25>/Unit Delay' */
    rtb_UnitDelay_a = uart_xy_wiggler_DWork.UnitDelay_DSTATE_j;

    /* S-Function (waijung_vdata_read): '<S3>/Volatile Data Storage Read2' */

    /* LissajousVolatileDataStorageRead2 */
    uart_xy_wiggler_B.VolatileDataStorageRead2_hi = (double)
      LissajousDataVolatileDataStorage12_Axs;

    /* UnitDelay: '<S27>/Unit Delay' */
    rtb_UnitDelay_f = uart_xy_wiggler_DWork.UnitDelay_DSTATE_g;

    /* S-Function (waijung_vdata_read): '<S3>/Volatile Data Storage Read3' */

    /* LissajousVolatileDataStorageRead3 */
    uart_xy_wiggler_B.VolatileDataStorageRead3_n = (double)
      LissajousDataVolatileDataStorage11_Ayc;

    /* UnitDelay: '<S24>/Unit Delay' */
    rtb_UnitDelay_n4 = uart_xy_wiggler_DWork.UnitDelay_DSTATE_i;

    /* S-Function (waijung_vdata_read): '<S3>/Volatile Data Storage Read1' */

    /* LissajousVolatileDataStorageRead1 */
    uart_xy_wiggler_B.VolatileDataStorageRead1_g = (double)
      LissajousDataVolatileDataStorage10_Ays;

    /* UnitDelay: '<S26>/Unit Delay' */
    rtb_UnitDelay_k = uart_xy_wiggler_DWork.UnitDelay_DSTATE_jm;

    /* S-Function (waijung_vdata_read): '<S29>/Volatile Data Storage Read4' */

    /* LissajousCalibrtaionXSubsystemVolatileDataStorageRead4 */
    uart_xy_wiggler_B.VolatileDataStorageRead4_k = (double)
      CalibrationDataVolatileDataStorage11_ab1;

    /* S-Function (waijung_vdata_read): '<S29>/Volatile Data Storage Read1' */

    /* LissajousCalibrtaionXSubsystemVolatileDataStorageRead1 */
    uart_xy_wiggler_B.VolatileDataStorageRead1_i = (double)
      CalibrationDataVolatileDataStorage12_ab2;

    /* S-Function (waijung_vdata_read): '<S29>/Volatile Data Storage Read2' */

    /* LissajousCalibrtaionXSubsystemVolatileDataStorageRead2 */
    uart_xy_wiggler_B.VolatileDataStorageRead2_m = (double)
      CalibrationDataVolatileDataStorage1_ab3;

    /* S-Function (waijung_vdata_read): '<S29>/Volatile Data Storage Read3' */

    /* LissajousCalibrtaionXSubsystemVolatileDataStorageRead3 */
    uart_xy_wiggler_B.VolatileDataStorageRead3_d = (double)
      CalibrationDataVolatileDataStorage2_ab4;

    /* S-Function (waijung_vdata_read): '<S29>/Volatile Data Storage Read5' */

    /* LissajousCalibrtaionXSubsystemVolatileDataStorageRead5 */
    uart_xy_wiggler_B.VolatileDataStorageRead5_b = (double)
      CalibrationDataVolatileDataStorage3_ab5;

    /* S-Function (waijung_vdata_read): '<S28>/Volatile Data Storage Read9' */

    /* LissajousCalibrationYSubsystem1VolatileDataStorageRead9 */
    uart_xy_wiggler_B.VolatileDataStorageRead9_c = (double)
      CalibrationDataVolatileDataStorage4_ab6;

    /* S-Function (waijung_vdata_read): '<S28>/Volatile Data Storage Read6' */

    /* LissajousCalibrationYSubsystem1VolatileDataStorageRead6 */
    uart_xy_wiggler_B.VolatileDataStorageRead6_p = (double)
      CalibrationDataVolatileDataStorage5_ab7;

    /* S-Function (waijung_vdata_read): '<S28>/Volatile Data Storage Read7' */

    /* LissajousCalibrationYSubsystem1VolatileDataStorageRead7 */
    uart_xy_wiggler_B.VolatileDataStorageRead7_d = (double)
      CalibrationDataVolatileDataStorage6_ab8;

    /* S-Function (waijung_vdata_read): '<S28>/Volatile Data Storage Read8' */

    /* LissajousCalibrationYSubsystem1VolatileDataStorageRead8 */
    uart_xy_wiggler_B.VolatileDataStorageRead8_n = (double)
      CalibrationDataVolatileDataStorage7_ab9;

    /* S-Function (waijung_vdata_read): '<S28>/Volatile Data Storage Read10' */

    /* LissajousCalibrationYSubsystem1VolatileDataStorageRead10 */
    uart_xy_wiggler_B.VolatileDataStorageRead10_a = (double)
      CalibrationDataVolatileDataStorage8_ab10;

    /* MultiPortSwitch: '<Root>/Multiport Switch' incorporates:
     *  DotProduct: '<S10>/Dot Product'
     *  DotProduct: '<S11>/Dot Product'
     *  DotProduct: '<S22>/Dot Product'
     *  DotProduct: '<S23>/Dot Product'
     */
    switch ((int32_T)uart_xy_wiggler_B.VolatileDataStorageRead2) {
     case 0:
      uart_xy_wiggler_B.MultiportSwitch[0] = uart_xy_wiggler_B.CalibrationVcx;
      uart_xy_wiggler_B.MultiportSwitch[1] = uart_xy_wiggler_B.CalibrationVcy;
      break;

     case 1:
      /* Product: '<S2>/Product1' incorporates:
       *  Gain: '<S12>/Sensitivity3'
       *  Trigonometry: '<S12>/Trigonometric Function'
       *  UnitDelay: '<S12>/Unit Delay'
       */
      rtb_Add_a = uart_xy_wiggler_P.DiscreteTimeVCO_Ac * cos
        (uart_xy_wiggler_DWork.UnitDelay_DSTATE_d) *
        uart_xy_wiggler_B.VolatileDataStorageRead5;

      /* Product: '<S2>/Product' incorporates:
       *  Gain: '<S13>/Sensitivity3'
       *  Trigonometry: '<S13>/Trigonometric Function'
       *  UnitDelay: '<S13>/Unit Delay'
       */
      rtb_Add1 = uart_xy_wiggler_P.DiscreteTimeVCO1_Ac * cos
        (uart_xy_wiggler_DWork.UnitDelay_DSTATE) *
        uart_xy_wiggler_B.VolatileDataStorageRead5;

      /* SignalConversion: '<S11>/TmpSignal ConversionAtDot ProductInport1' */
      rtb_Add1_0[0] = rtb_Add1;
      rtb_Add1_0[1] = rtb_Add_a;

      /* Math: '<S11>/Square' incorporates:
       *  Math: '<S10>/Square'
       */
      rtb_Add1_tmp = rtb_Add1 * rtb_Add1;

      /* SignalConversion: '<S11>/TmpSignal ConversionAtDot ProductInport1' incorporates:
       *  Math: '<S11>/Square'
       */
      rtb_Add1_0[2] = rtb_Add1_tmp;

      /* Math: '<S11>/Square1' incorporates:
       *  Math: '<S10>/Square1'
       */
      rtb_Add1_tmp_0 = rtb_Add_a * rtb_Add_a;

      /* SignalConversion: '<S11>/TmpSignal ConversionAtDot ProductInport1' incorporates:
       *  Math: '<S11>/Square1'
       */
      rtb_Add1_0[3] = rtb_Add1_tmp_0;

      /* Product: '<S11>/Product' incorporates:
       *  Product: '<S10>/Product'
       */
      rtb_Add1_tmp_1 = rtb_Add1 * rtb_Add_a;

      /* SignalConversion: '<S11>/TmpSignal ConversionAtDot ProductInport1' incorporates:
       *  Product: '<S11>/Product'
       */
      rtb_Add1_0[4] = rtb_Add1_tmp_1;

      /* SignalConversion: '<S11>/TmpSignal ConversionAtDot ProductInport2' */
      tmp[0] = uart_xy_wiggler_B.VolatileDataStorageRead4;
      tmp[1] = uart_xy_wiggler_B.VolatileDataStorageRead1;
      tmp[2] = uart_xy_wiggler_B.VolatileDataStorageRead2_h;
      tmp[3] = uart_xy_wiggler_B.VolatileDataStorageRead3;
      tmp[4] = uart_xy_wiggler_B.VolatileDataStorageRead5_o;

      /* DotProduct: '<S11>/Dot Product' */
      tmp_0 = 0.0;

      /* SignalConversion: '<S10>/TmpSignal ConversionAtDot ProductInport1' */
      rtb_Add1_1[0] = rtb_Add1;
      rtb_Add1_1[1] = rtb_Add_a;
      rtb_Add1_1[2] = rtb_Add1_tmp;
      rtb_Add1_1[3] = rtb_Add1_tmp_0;
      rtb_Add1_1[4] = rtb_Add1_tmp_1;

      /* SignalConversion: '<S10>/TmpSignal ConversionAtDot ProductInport2' */
      tmp_1[0] = uart_xy_wiggler_B.VolatileDataStorageRead9;
      tmp_1[1] = uart_xy_wiggler_B.VolatileDataStorageRead6;
      tmp_1[2] = uart_xy_wiggler_B.VolatileDataStorageRead7;
      tmp_1[3] = uart_xy_wiggler_B.VolatileDataStorageRead8;
      tmp_1[4] = uart_xy_wiggler_B.VolatileDataStorageRead10;

      /* DotProduct: '<S10>/Dot Product' */
      rtb_Add_a = 0.0;
      for (i = 0; i < 5; i++) {
        /* DotProduct: '<S11>/Dot Product' */
        tmp_0 += rtb_Add1_0[i] * tmp[i];

        /* DotProduct: '<S10>/Dot Product' */
        rtb_Add_a += rtb_Add1_1[i] * tmp_1[i];
      }

      uart_xy_wiggler_B.MultiportSwitch[0] = tmp_0;
      uart_xy_wiggler_B.MultiportSwitch[1] = rtb_Add_a;
      break;

     default:
      /* Sum: '<S3>/Add' incorporates:
       *  Gain: '<S24>/Sensitivity3'
       *  Gain: '<S26>/Sensitivity3'
       *  Product: '<S3>/Product1'
       *  Product: '<S3>/Product3'
       *  Trigonometry: '<S24>/Trigonometric Function'
       *  Trigonometry: '<S26>/Trigonometric Function'
       *  UnitDelay: '<S24>/Unit Delay'
       *  UnitDelay: '<S26>/Unit Delay'
       */
      rtb_Add_a = uart_xy_wiggler_P.Cos5wt_Ac * cos
        (uart_xy_wiggler_DWork.UnitDelay_DSTATE_i) *
        uart_xy_wiggler_B.VolatileDataStorageRead3_n +
        uart_xy_wiggler_P.Sin5wt_Ac * cos
        (uart_xy_wiggler_DWork.UnitDelay_DSTATE_jm) *
        uart_xy_wiggler_B.VolatileDataStorageRead1_g;

      /* Sum: '<S3>/Add1' incorporates:
       *  Gain: '<S25>/Sensitivity3'
       *  Gain: '<S27>/Sensitivity3'
       *  Product: '<S3>/Product'
       *  Product: '<S3>/Product2'
       *  Trigonometry: '<S25>/Trigonometric Function'
       *  Trigonometry: '<S27>/Trigonometric Function'
       *  UnitDelay: '<S25>/Unit Delay'
       *  UnitDelay: '<S27>/Unit Delay'
       */
      rtb_Add1 = uart_xy_wiggler_P.Coswt_Ac * cos
        (uart_xy_wiggler_DWork.UnitDelay_DSTATE_j) *
        uart_xy_wiggler_B.VolatileDataStorageRead5_f +
        uart_xy_wiggler_P.Sinwt_Ac * cos
        (uart_xy_wiggler_DWork.UnitDelay_DSTATE_g) *
        uart_xy_wiggler_B.VolatileDataStorageRead2_hi;

      /* SignalConversion: '<S23>/TmpSignal ConversionAtDot ProductInport1' */
      rtb_Add1_0[0] = rtb_Add1;
      rtb_Add1_0[1] = rtb_Add_a;

      /* Math: '<S23>/Square' incorporates:
       *  Math: '<S22>/Square'
       */
      rtb_Add1_tmp = rtb_Add1 * rtb_Add1;

      /* SignalConversion: '<S23>/TmpSignal ConversionAtDot ProductInport1' incorporates:
       *  Math: '<S23>/Square'
       */
      rtb_Add1_0[2] = rtb_Add1_tmp;

      /* Math: '<S23>/Square1' incorporates:
       *  Math: '<S22>/Square1'
       */
      rtb_Add1_tmp_0 = rtb_Add_a * rtb_Add_a;

      /* SignalConversion: '<S23>/TmpSignal ConversionAtDot ProductInport1' incorporates:
       *  Math: '<S23>/Square1'
       */
      rtb_Add1_0[3] = rtb_Add1_tmp_0;

      /* Product: '<S23>/Product' incorporates:
       *  Product: '<S22>/Product'
       */
      rtb_Add1_tmp_1 = rtb_Add1 * rtb_Add_a;

      /* SignalConversion: '<S23>/TmpSignal ConversionAtDot ProductInport1' incorporates:
       *  Product: '<S23>/Product'
       */
      rtb_Add1_0[4] = rtb_Add1_tmp_1;

      /* SignalConversion: '<S23>/TmpSignal ConversionAtDot ProductInport2' */
      tmp[0] = uart_xy_wiggler_B.VolatileDataStorageRead4_k;
      tmp[1] = uart_xy_wiggler_B.VolatileDataStorageRead1_i;
      tmp[2] = uart_xy_wiggler_B.VolatileDataStorageRead2_m;
      tmp[3] = uart_xy_wiggler_B.VolatileDataStorageRead3_d;
      tmp[4] = uart_xy_wiggler_B.VolatileDataStorageRead5_b;

      /* DotProduct: '<S23>/Dot Product' */
      tmp_0 = 0.0;

      /* SignalConversion: '<S22>/TmpSignal ConversionAtDot ProductInport1' */
      rtb_Add1_1[0] = rtb_Add1;
      rtb_Add1_1[1] = rtb_Add_a;
      rtb_Add1_1[2] = rtb_Add1_tmp;
      rtb_Add1_1[3] = rtb_Add1_tmp_0;
      rtb_Add1_1[4] = rtb_Add1_tmp_1;

      /* SignalConversion: '<S22>/TmpSignal ConversionAtDot ProductInport2' */
      tmp_1[0] = uart_xy_wiggler_B.VolatileDataStorageRead9_c;
      tmp_1[1] = uart_xy_wiggler_B.VolatileDataStorageRead6_p;
      tmp_1[2] = uart_xy_wiggler_B.VolatileDataStorageRead7_d;
      tmp_1[3] = uart_xy_wiggler_B.VolatileDataStorageRead8_n;
      tmp_1[4] = uart_xy_wiggler_B.VolatileDataStorageRead10_a;

      /* DotProduct: '<S22>/Dot Product' */
      rtb_Add_a = 0.0;
      for (i = 0; i < 5; i++) {
        /* DotProduct: '<S23>/Dot Product' */
        tmp_0 += rtb_Add1_0[i] * tmp[i];

        /* DotProduct: '<S22>/Dot Product' */
        rtb_Add_a += rtb_Add1_1[i] * tmp_1[i];
      }

      uart_xy_wiggler_B.MultiportSwitch[0] = tmp_0;
      uart_xy_wiggler_B.MultiportSwitch[1] = rtb_Add_a;
      break;
    }

    /* End of MultiPortSwitch: '<Root>/Multiport Switch' */

    /* SignalConversion: '<S7>/TmpSignal ConversionAtQueueInport1' incorporates:
     *  DataTypeConversion: '<Root>/Data Type Conversion'
     *  DataTypeConversion: '<Root>/Data Type Conversion1'
     *  MultiPortSwitch: '<Root>/Index Vector'
     *  MultiPortSwitch: '<Root>/Index Vector1'
     */
    rtb_TmpSignalConversionAtQueueI[0] =
      uart_xy_wiggler_B.MedianFilter.MedianFilter1;
    rtb_TmpSignalConversionAtQueueI[1] =
      uart_xy_wiggler_B.MedianFilter1.MedianFilter1;
    rtb_TmpSignalConversionAtQueueI[2] = (real32_T)
      uart_xy_wiggler_B.MultiportSwitch[0];
    rtb_TmpSignalConversionAtQueueI[3] = (real32_T)
      uart_xy_wiggler_B.MultiportSwitch[1];

    /* DiscretePulseGenerator: '<Root>/recording_clock' */
    rtb_Add_a = (uart_xy_wiggler_DWork.clockTickCounter <
                 uart_xy_wiggler_P.recording_clock_Duty) &&
      (uart_xy_wiggler_DWork.clockTickCounter >= 0) ?
      uart_xy_wiggler_P.recording_clock_Amp : 0.0;
    if (uart_xy_wiggler_DWork.clockTickCounter >=
        uart_xy_wiggler_P.recording_clock_Period - 1.0) {
      uart_xy_wiggler_DWork.clockTickCounter = 0;
    } else {
      uart_xy_wiggler_DWork.clockTickCounter++;
    }

    /* End of DiscretePulseGenerator: '<Root>/recording_clock' */

    /* Logic: '<S7>/Logical Operator' */
    rtb_LogicalOperator = (uart_xy_wiggler_B.Compare && (rtb_Add_a != 0.0));

    /* DiscretePulseGenerator: '<Root>/send_2_uart_clock' */
    rtb_Add_a = (uart_xy_wiggler_DWork.clockTickCounter_b <
                 uart_xy_wiggler_P.send_2_uart_clock_Duty) &&
      (uart_xy_wiggler_DWork.clockTickCounter_b >= 0) ?
      uart_xy_wiggler_P.send_2_uart_clock_Amp : 0.0;
    if (uart_xy_wiggler_DWork.clockTickCounter_b >=
        uart_xy_wiggler_P.send_2_uart_clock_Period - 1.0) {
      uart_xy_wiggler_DWork.clockTickCounter_b = 0;
    } else {
      uart_xy_wiggler_DWork.clockTickCounter_b++;
    }

    /* End of DiscretePulseGenerator: '<Root>/send_2_uart_clock' */

    /* Logic: '<S7>/Logical Operator1' */
    rtb_LogicalOperator1 = (uart_xy_wiggler_B.Compare_i && (rtb_Add_a != 0.0));

    /* S-Function (sdspstacknqueue): '<S7>/Queue' */
    /* DSP System Toolbox Queue (sdspstacknqueue) - '<S7>/Queue' */
    {
      if (MWDSP_EPHZCFcn(EVENT_PORT_MODE_EITHER,
                         (EventPortSigState *)
                         &uart_xy_wiggler_DWork.Queue_EPH2PrevState,
                         EventPortSigStateFcn_B(uart_xy_wiggler_B.Compare_d)
                         ) != EVENT_PORT_EVENT_NONE)/* CLEAR */
      {
        uart_xy_wiggler_DWork.Queue_QueueFrontIdx =
          uart_xy_wiggler_DWork.Queue_QueueBackIdx =
          uart_xy_wiggler_DWork.Queue_NumElements = 0;
        memset(&uart_xy_wiggler_B.Queue_o1[0], 0, sizeof(real32_T)*4);/* Set output values to zero */
      }

      if (MWDSP_EPHZCFcn(EVENT_PORT_MODE_EITHER,
                         (EventPortSigState *)
                         &uart_xy_wiggler_DWork.Queue_EPH0PrevState,
                         EventPortSigStateFcn_B(rtb_LogicalOperator)
                         ) != EVENT_PORT_EVENT_NONE)/* PUSH */
      {
        if (uart_xy_wiggler_DWork.Queue_NumElements != 20) {
          {
            const size_t numbytes = sizeof(real32_T)*4;
            memcpy(&uart_xy_wiggler_DWork.Queue_BufferPtr[0]+
                   (uart_xy_wiggler_DWork.Queue_QueueBackIdx % 20)*4,
                   &rtb_TmpSignalConversionAtQueueI[0], numbytes);
            uart_xy_wiggler_DWork.Queue_QueueBackIdx++;
            uart_xy_wiggler_DWork.Queue_NumElements++;
          }
        }
      }

      if (MWDSP_EPHZCFcn(EVENT_PORT_MODE_EITHER,
                         (EventPortSigState *)
                         &uart_xy_wiggler_DWork.Queue_EPH1PrevState,
                         EventPortSigStateFcn_B(rtb_LogicalOperator1)
                         ) != EVENT_PORT_EVENT_NONE)/* POP */
      {
        {
          const size_t numbytes = sizeof(real32_T)*4;
          if (uart_xy_wiggler_DWork.Queue_NumElements) {
            memcpy(&uart_xy_wiggler_B.Queue_o1[0],
                   &uart_xy_wiggler_DWork.Queue_BufferPtr[0]+
                   uart_xy_wiggler_DWork.Queue_QueueFrontIdx*4, numbytes);
            uart_xy_wiggler_DWork.Queue_NumElements --;
            if ((uart_xy_wiggler_DWork.Queue_QueueFrontIdx + 1) == 20) {
              uart_xy_wiggler_DWork.Queue_QueueFrontIdx = 0;
              uart_xy_wiggler_DWork.Queue_QueueBackIdx %= 20;
            } else
              uart_xy_wiggler_DWork.Queue_QueueFrontIdx ++;
          }
        }
      }

      rtb_Queue_o2 = (boolean_T) (uart_xy_wiggler_DWork.Queue_NumElements == 0);
      rtb_Queue_o3 = (boolean_T) (uart_xy_wiggler_DWork.Queue_NumElements == 20);
      rtb_Queue_o4 = (uint32_T) uart_xy_wiggler_DWork.Queue_NumElements;
    }

    /* Outputs for Enabled SubSystem: '<S7>/Subsystem3' incorporates:
     *  EnablePort: '<S50>/Enable'
     */
    /* Logic: '<S7>/Logical Operator5' incorporates:
     *  Constant: '<S49>/Constant'
     *  Logic: '<S7>/Logical Operator4'
     *  RelationalOperator: '<S49>/Compare'
     */
    if ((!rtb_Queue_o2) && (uart_xy_wiggler_B.flag_for_recorder_uart ==
                            uart_xy_wiggler_P.CompareToConstant7_const)) {
      if (!uart_xy_wiggler_DWork.Subsystem3_MODE) {
        /* Enable for S-Function (stm32f4_usart): '<S50>/UART Tx3' */
        /* Level2 S-Function Block: '<S50>/UART Tx3' (stm32f4_usart) */
        enable_record_and_send_via_UARTSubsystem3UARTTx3();
        uart_xy_wiggler_DWork.Subsystem3_MODE = true;
      }
    } else {
      if (uart_xy_wiggler_DWork.Subsystem3_MODE) {
        uart_xy_wiggler_DWork.Subsystem3_MODE = false;
      }
    }

    /* End of Logic: '<S7>/Logical Operator5' */
    /* End of Outputs for SubSystem: '<S7>/Subsystem3' */
  }

  /* Outputs for Enabled SubSystem: '<S7>/Subsystem3' incorporates:
   *  EnablePort: '<S50>/Enable'
   */
  if (uart_xy_wiggler_DWork.Subsystem3_MODE) {
    /* S-Function (stm32f4_usart): '<S50>/UART Tx3' */

    /* record_and_send_via_UARTSubsystem3UARTTx3: '<S50>/UART Tx3' */
    {
      /* Flush tx, so we can put data directly to DMA buffer */
      UART3_FlushTxBuffer();

      /* Put data into buffer */
      UART3_Tx_Buffer[0] = 126;        /* Header 0 */
      UART3_Tx_Buffer[1] = 126;        /* Header 1 */
      memcpy(&UART3_Tx_Buffer[2], &uart_xy_wiggler_B.Queue_o1[0], sizeof
             (real32_T));              /* Data 0 */
      memcpy(&UART3_Tx_Buffer[6], &uart_xy_wiggler_B.Queue_o1[1], sizeof
             (real32_T));              /* Data 1 */
      memcpy(&UART3_Tx_Buffer[10], &uart_xy_wiggler_B.Queue_o1[2], sizeof
             (real32_T));              /* Data 2 */
      memcpy(&UART3_Tx_Buffer[14], &uart_xy_wiggler_B.Queue_o1[3], sizeof
             (real32_T));              /* Data 3 */
      UART3_Tx_Buffer[18] = 3;         /* Terminator 0 */
      UART3_Tx_Buffer[19] = 3;         /* Terminator 1 */

      /* Write to DMA, 20 bytes */
      UART3_TxUpdate(20);              /* Only update since data is ready on Tx buffer */
    }
  }

  /* End of Outputs for SubSystem: '<S7>/Subsystem3' */
  if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
    /* Outputs for Enabled SubSystem: '<S7>/set flag=0' incorporates:
     *  EnablePort: '<S51>/Enable'
     */
    /* Logic: '<S7>/Logical Operator6' incorporates:
     *  Logic: '<S7>/Logical Operator2'
     *  Logic: '<S7>/Logical Operator3'
     */
    if ((uart_xy_wiggler_B.Compare_i && rtb_Queue_o2) ||
        (uart_xy_wiggler_B.Compare && rtb_Queue_o3)) {
      if (!uart_xy_wiggler_DWork.setflag0_MODE) {
        uart_xy_wiggler_DWork.setflag0_MODE = true;
      }

      if (uart_xy_wiggler_M->Timing.TaskCounters.TID[2] == 0) {
        /* S-Function (waijung_vdata_write): '<S51>/Volatile Data Storage Write' incorporates:
         *  Constant: '<S51>/Constant'
         */

        /* record_and_send_via_UARTsetflag0VolatileDataStorageWrite */
        VolatileDataStorage3_flag = (uint8_t)uart_xy_wiggler_P.Constant_Value_e;
      }
    } else {
      if (uart_xy_wiggler_DWork.setflag0_MODE) {
        uart_xy_wiggler_DWork.setflag0_MODE = false;
      }
    }

    /* End of Logic: '<S7>/Logical Operator6' */
    /* End of Outputs for SubSystem: '<S7>/set flag=0' */

    /* Gain: '<S9>/Gain' incorporates:
     *  Abs: '<S9>/Abs'
     */
    uart_xy_wiggler_B.PWM_VC2 = uart_xy_wiggler_P.Gain_Gain * fabs
      (uart_xy_wiggler_B.MultiportSwitch[0]);

    /* Gain: '<S9>/Gain1' incorporates:
     *  Abs: '<S9>/Abs1'
     */
    uart_xy_wiggler_B.PWM_VC1 = uart_xy_wiggler_P.Gain1_Gain * fabs
      (uart_xy_wiggler_B.MultiportSwitch[1]);

    /* S-Function (waijung_vdata_read): '<S9>/Volatile Data Storage Read2' */

    /* wigglerVolatileDataStorageRead2 */
    uart_xy_wiggler_B.VolatileDataStorageRead2_l = (double)
      VolatileDataStorage4_CircleFlag;

    /* S-Function (waijung_vdata_read): '<S9>/Volatile Data Storage Read3' */

    /* wigglerVolatileDataStorageRead3 */
    uart_xy_wiggler_B.Laser = (double)LissajousDataVolatileDataStorage7_A_Laser;

    /* UnitDelay: '<S79>/Unit Delay' */
    rtb_UnitDelay_m = uart_xy_wiggler_DWork.UnitDelay_DSTATE_do;

    /* MultiPortSwitch: '<S9>/Multiport Switch' incorporates:
     *  Constant: '<S9>/Constant'
     *  Constant: '<S9>/Constant1'
     *  Gain: '<S79>/Sensitivity3'
     *  Product: '<S9>/Product'
     *  Sum: '<S9>/Add'
     *  Trigonometry: '<S79>/Trigonometric Function'
     *  UnitDelay: '<S79>/Unit Delay'
     */
    switch ((int32_T)uart_xy_wiggler_B.VolatileDataStorageRead2_l) {
     case 0:
      uart_xy_wiggler_B.MultiportSwitch_b = uart_xy_wiggler_P.Constant1_Value;
      break;

     case 1:
      uart_xy_wiggler_B.MultiportSwitch_b = uart_xy_wiggler_P.Constant1_Value;
      break;

     default:
      uart_xy_wiggler_B.MultiportSwitch_b = (uart_xy_wiggler_B.Laser +
        uart_xy_wiggler_P.Constant_Value) *
        (uart_xy_wiggler_P.DiscreteTimeVCO_Ac_m * cos
         (uart_xy_wiggler_DWork.UnitDelay_DSTATE_do));
      break;
    }

    /* End of MultiPortSwitch: '<S9>/Multiport Switch' */
  }

  /* S-Function (stm32f4_basicpwm): '<S9>/Basic PWM' */

  /* S-Function Block: <S9>/Basic PWM (stm32f4_basicpwm) */
  TIM3->CCR2 = (uint32_t) (uart_xy_wiggler_B.PWM_VC2 * wigglerBasicPWM_SF);
  TIM3->CCR3 = (uint32_t) (uart_xy_wiggler_B.PWM_VC1 * wigglerBasicPWM_SF);
  TIM3->CCR4 = (uint32_t) (uart_xy_wiggler_B.MultiportSwitch_b *
    wigglerBasicPWM_SF);
  if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
    /* RelationalOperator: '<S78>/Compare' incorporates:
     *  Constant: '<S78>/Constant'
     */
    uart_xy_wiggler_B.Compare_i4 = (uart_xy_wiggler_B.MultiportSwitch[0] <
      uart_xy_wiggler_P.CompareToConstant2_const);

    /* RelationalOperator: '<S77>/Compare' incorporates:
     *  Constant: '<S77>/Constant'
     */
    uart_xy_wiggler_B.Compare_a = (uart_xy_wiggler_B.MultiportSwitch[1] >
      uart_xy_wiggler_P.CompareToConstant1_const);

    /* S-Function (stm32f4_digital_output): '<S9>/Digital Output1' */

    /* wigglerDigitalOutput1 */
    {
      *wigglerDigitalOutput1_F13 = uart_xy_wiggler_B.Compare_i4;
      *wigglerDigitalOutput1_F14 = uart_xy_wiggler_B.Compare_a;
    }

    /* S-Function (stm32f4_digital_output): '<S9>/Digital Output2' */

    /* wigglerDigitalOutput2 */
    {
      *wigglerDigitalOutput2_D0 = (boolean_T) uart_xy_wiggler_B.MultiportSwitch
        [1];
      *wigglerDigitalOutput2_D7 = uart_xy_wiggler_B.Compare_a;
    }

    /* S-Function (waijung_vdata_read): '<S9>/Volatile Data Storage Read1' */

    /* wigglerVolatileDataStorageRead1 */
    uart_xy_wiggler_B.VolatileDataStorageRead1_j = (double)
      LissajousDataVolatileDataStorage8_LissaFreq;

    /* Math: '<S79>/Math Function' incorporates:
     *  Constant: '<S79>/Modulo 2*pi'
     *  Gain: '<S79>/Center Frequency'
     *  Gain: '<S82>/Gain'
     *  Product: '<S82>/Product'
     *  SampleTimeMath: '<S79>/Weighted Sample Time'
     *  Sum: '<S79>/Sum1'
     *
     * About '<S79>/Weighted Sample Time':
     *  y = K where K = ( w * Ts )
     */
    rtb_MathFunction = rt_modd_snf((uart_xy_wiggler_P.Gain_Gain_a *
      uart_xy_wiggler_B.VolatileDataStorageRead1_j *
      uart_xy_wiggler_P.WeightedSampleTime_WtEt +
      uart_xy_wiggler_P.CenterFrequency_Gain *
      uart_xy_wiggler_P.WeightedSampleTime_WtEt) + rtb_UnitDelay_m,
      uart_xy_wiggler_P.Modulo2pi_Value);

    /* S-Function (waijung_vdata_read): '<S2>/Volatile Data Storage Read4' */

    /* CircleVolatileDataStorageRead4 */
    uart_xy_wiggler_B.VolatileDataStorageRead4_l = (double)
      VolatileDataStorage5_CircleFrequency;

    /* Math: '<S12>/Math Function' incorporates:
     *  Constant: '<S12>/Modulo 2*pi'
     *  Gain: '<S12>/Center Frequency'
     *  Gain: '<S18>/Gain'
     *  Product: '<S18>/Product'
     *  SampleTimeMath: '<S12>/Weighted Sample Time'
     *  Sum: '<S12>/Sum1'
     *
     * About '<S12>/Weighted Sample Time':
     *  y = K where K = ( w * Ts )
     */
    rtb_MathFunction_d = rt_modd_snf((uart_xy_wiggler_P.Gain_Gain_e *
      uart_xy_wiggler_B.VolatileDataStorageRead4_l *
      uart_xy_wiggler_P.WeightedSampleTime_WtEt_a +
      uart_xy_wiggler_P.CenterFrequency_Gain_a *
      uart_xy_wiggler_P.WeightedSampleTime_WtEt_a) + rtb_UnitDelay_o,
      uart_xy_wiggler_P.Modulo2pi_Value_d);

    /* Math: '<S13>/Math Function' incorporates:
     *  Constant: '<S13>/Modulo 2*pi'
     *  Gain: '<S13>/Center Frequency'
     *  Gain: '<S21>/Gain'
     *  Product: '<S21>/Product'
     *  SampleTimeMath: '<S13>/Weighted Sample Time'
     *  Sum: '<S13>/Sum1'
     *
     * About '<S13>/Weighted Sample Time':
     *  y = K where K = ( w * Ts )
     */
    rtb_MathFunction_i = rt_modd_snf((uart_xy_wiggler_P.Gain_Gain_o *
      uart_xy_wiggler_B.VolatileDataStorageRead4_l *
      uart_xy_wiggler_P.WeightedSampleTime_WtEt_o +
      uart_xy_wiggler_P.CenterFrequency_Gain_i *
      uart_xy_wiggler_P.WeightedSampleTime_WtEt_o) + rtb_UnitDelay,
      uart_xy_wiggler_P.Modulo2pi_Value_dg);

    /* S-Function (waijung_vdata_read): '<S3>/Volatile Data Storage Read4' */

    /* LissajousVolatileDataStorageRead4 */
    uart_xy_wiggler_B.VolatileDataStorageRead4_h = (double)
      LissajousDataVolatileDataStorage8_LissaFreq;

    /* Math: '<S24>/Math Function' incorporates:
     *  Constant: '<S24>/Modulo 2*pi'
     *  Gain: '<S24>/Center Frequency'
     *  Gain: '<S32>/Gain'
     *  Gain: '<S3>/Gain1'
     *  Product: '<S32>/Product'
     *  SampleTimeMath: '<S24>/Weighted Sample Time'
     *  Sum: '<S24>/Sum1'
     *
     * About '<S24>/Weighted Sample Time':
     *  y = K where K = ( w * Ts )
     */
    rtb_MathFunction_g = rt_modd_snf((uart_xy_wiggler_P.Gain1_Gain_m *
      uart_xy_wiggler_B.VolatileDataStorageRead4_h *
      uart_xy_wiggler_P.Gain_Gain_g *
      uart_xy_wiggler_P.WeightedSampleTime_WtEt_os +
      uart_xy_wiggler_P.CenterFrequency_Gain_k *
      uart_xy_wiggler_P.WeightedSampleTime_WtEt_os) + rtb_UnitDelay_n4,
      uart_xy_wiggler_P.Modulo2pi_Value_j);

    /* Math: '<S25>/Math Function' incorporates:
     *  Constant: '<S25>/Modulo 2*pi'
     *  Gain: '<S25>/Center Frequency'
     *  Gain: '<S35>/Gain'
     *  Product: '<S35>/Product'
     *  SampleTimeMath: '<S25>/Weighted Sample Time'
     *  Sum: '<S25>/Sum1'
     *
     * About '<S25>/Weighted Sample Time':
     *  y = K where K = ( w * Ts )
     */
    rtb_MathFunction_gp = rt_modd_snf((uart_xy_wiggler_P.Gain_Gain_h *
      uart_xy_wiggler_B.VolatileDataStorageRead4_h *
      uart_xy_wiggler_P.WeightedSampleTime_WtEt_i +
      uart_xy_wiggler_P.CenterFrequency_Gain_p *
      uart_xy_wiggler_P.WeightedSampleTime_WtEt_i) + rtb_UnitDelay_a,
      uart_xy_wiggler_P.Modulo2pi_Value_o);

    /* Math: '<S26>/Math Function' incorporates:
     *  Constant: '<S26>/Modulo 2*pi'
     *  Gain: '<S26>/Center Frequency'
     *  Gain: '<S38>/Gain'
     *  Gain: '<S3>/Gain'
     *  Product: '<S38>/Product'
     *  SampleTimeMath: '<S26>/Weighted Sample Time'
     *  Sum: '<S26>/Sum1'
     *
     * About '<S26>/Weighted Sample Time':
     *  y = K where K = ( w * Ts )
     */
    rtb_MathFunction_a = rt_modd_snf((uart_xy_wiggler_P.Gain_Gain_k *
      uart_xy_wiggler_B.VolatileDataStorageRead4_h *
      uart_xy_wiggler_P.Gain_Gain_i *
      uart_xy_wiggler_P.WeightedSampleTime_WtEt_h +
      uart_xy_wiggler_P.CenterFrequency_Gain_h *
      uart_xy_wiggler_P.WeightedSampleTime_WtEt_h) + rtb_UnitDelay_k,
      uart_xy_wiggler_P.Modulo2pi_Value_h);

    /* Math: '<S27>/Math Function' incorporates:
     *  Constant: '<S27>/Modulo 2*pi'
     *  Gain: '<S27>/Center Frequency'
     *  Gain: '<S41>/Gain'
     *  Product: '<S41>/Product'
     *  SampleTimeMath: '<S27>/Weighted Sample Time'
     *  Sum: '<S27>/Sum1'
     *
     * About '<S27>/Weighted Sample Time':
     *  y = K where K = ( w * Ts )
     */
    rtb_MathFunction_gm = rt_modd_snf((uart_xy_wiggler_P.Gain_Gain_m *
      uart_xy_wiggler_B.VolatileDataStorageRead4_h *
      uart_xy_wiggler_P.WeightedSampleTime_WtEt_a3 +
      uart_xy_wiggler_P.CenterFrequency_Gain_pl *
      uart_xy_wiggler_P.WeightedSampleTime_WtEt_a3) + rtb_UnitDelay_f,
      uart_xy_wiggler_P.Modulo2pi_Value_l);
  }

  /* DataTypeConversion: '<S8>/Data Type Conversion1' incorporates:
   *  Delay: '<S8>/Wait for Buffer to clear1'
   */
  uart_xy_wiggler_B.DataTypeConversion1 =
    uart_xy_wiggler_DWork.WaitforBuffertoclear1_DSTATE[0];

  /* Outputs for Enabled SubSystem: '<S8>/Set UART vc Flag=1' incorporates:
   *  EnablePort: '<S54>/Enable'
   */
  /* Delay: '<S8>/Wait for Buffer to clear ' */
  if (uart_xy_wiggler_DWork.WaitforBuffertoclear_DSTATE[0U] > 0) {
    if (!uart_xy_wiggler_DWork.SetUARTvcFlag1_MODE) {
      uart_xy_wiggler_DWork.SetUARTvcFlag1_MODE = true;
    }

    if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
      /* S-Function (waijung_vdata_write): '<S54>/Volatile Data Storage Write' */

      /* set_UART_VCflagSetUARTvcFlag1VolatileDataStorageWrite */
      VolatileDataStorage2_vcx = (double)uart_xy_wiggler_B.DataTypeConversion1;
    }
  } else {
    if (uart_xy_wiggler_DWork.SetUARTvcFlag1_MODE) {
      uart_xy_wiggler_DWork.SetUARTvcFlag1_MODE = false;
    }
  }

  /* End of Delay: '<S8>/Wait for Buffer to clear ' */
  /* End of Outputs for SubSystem: '<S8>/Set UART vc Flag=1' */

  /* RateTransition: '<S8>/Rate Transition2' */
  if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
    uart_xy_wiggler_B.RateTransition2 =
      uart_xy_wiggler_DWork.RateTransition2_Buffer0;

    /* RateTransition: '<S8>/Rate Transition4' */
    uart_xy_wiggler_B.RateTransition4 =
      uart_xy_wiggler_DWork.RateTransition4_Buffer0;

    /* S-Function (stm32f4_usart): '<S8>/UART Rx' */

    /* set_UART_VCflagUARTRx: '<S8>/UART Rx' */
    if (set_UART_VCflagUARTRx_Receive(&UART3_Temp_Buffer[0], URX3_BUFFER_SIZE))
    {                                  /* Non-Blocking */
      uart_xy_wiggler_B.UARTRx_o2 = set_UART_VCflagUARTRx_data0;/* D0 */
      uart_xy_wiggler_B.UARTRx_o1 = 1; /* READY */
    } else {
      uart_xy_wiggler_B.UARTRx_o1 = 0; /* Not READY */
    }
  }

  /* End of RateTransition: '<S8>/Rate Transition2' */

  /* DataTypeConversion: '<S8>/Data Type Conversion2' incorporates:
   *  Delay: '<S8>/Wait for Buffer to clear3'
   */
  uart_xy_wiggler_B.DataTypeConversion2 =
    uart_xy_wiggler_DWork.WaitforBuffertoclear3_DSTATE[0];

  /* Outputs for Enabled SubSystem: '<S8>/Set UART vc Flag=2' incorporates:
   *  EnablePort: '<S55>/Enable'
   */
  /* Delay: '<S8>/Wait for Buffer to clear 1' */
  if (uart_xy_wiggler_DWork.WaitforBuffertoclear1_DSTATE_l[0U] > 0) {
    if (!uart_xy_wiggler_DWork.SetUARTvcFlag2_MODE) {
      uart_xy_wiggler_DWork.SetUARTvcFlag2_MODE = true;
    }

    if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
      /* S-Function (waijung_vdata_write): '<S55>/Volatile Data Storage Write' */

      /* set_UART_VCflagSetUARTvcFlag2VolatileDataStorageWrite */
      VolatileDataStorage6_vcy = (double)uart_xy_wiggler_B.DataTypeConversion2;
    }
  } else {
    if (uart_xy_wiggler_DWork.SetUARTvcFlag2_MODE) {
      uart_xy_wiggler_DWork.SetUARTvcFlag2_MODE = false;
    }
  }

  /* End of Delay: '<S8>/Wait for Buffer to clear 1' */
  /* End of Outputs for SubSystem: '<S8>/Set UART vc Flag=2' */

  /* RateTransition: '<S8>/Rate Transition1' */
  if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
    uart_xy_wiggler_B.RateTransition1_b =
      uart_xy_wiggler_DWork.RateTransition1_Buffer0_o;

    /* RateTransition: '<S8>/Rate Transition3' */
    uart_xy_wiggler_B.RateTransition3 =
      uart_xy_wiggler_DWork.RateTransition3_Buffer0;

    /* S-Function (stm32f4_usart): '<S8>/UART Rx1' */

    /* set_UART_VCflagUARTRx1: '<S8>/UART Rx1' */
    if (set_UART_VCflagUARTRx1_Receive(&UART3_Temp_Buffer[0], URX3_BUFFER_SIZE))
    {                                  /* Non-Blocking */
      uart_xy_wiggler_B.UARTRx1_o2 = set_UART_VCflagUARTRx1_data0;/* D0 */
      uart_xy_wiggler_B.UARTRx1_o1 = 1;/* READY */
    } else {
      uart_xy_wiggler_B.UARTRx1_o1 = 0;/* Not READY */
    }
  }

  /* End of RateTransition: '<S8>/Rate Transition1' */

  /* DataTypeConversion: '<S8>/Data Type Conversion3' incorporates:
   *  Delay: '<S8>/Wait for Buffer to clear4'
   */
  uart_xy_wiggler_B.DataTypeConversion3 =
    uart_xy_wiggler_DWork.WaitforBuffertoclear4_DSTATE[0];

  /* Outputs for Enabled SubSystem: '<S8>/Set UART vc Flag=4' incorporates:
   *  EnablePort: '<S57>/Enable'
   */
  /* Delay: '<S8>/Wait for Buffer to clear 3' */
  if (uart_xy_wiggler_DWork.WaitforBuffertoclear3_DSTATE_j[0U] > 0) {
    if (!uart_xy_wiggler_DWork.SetUARTvcFlag4_MODE) {
      uart_xy_wiggler_DWork.SetUARTvcFlag4_MODE = true;
    }

    if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
      /* S-Function (waijung_vdata_write): '<S57>/Volatile Data Storage Write' */

      /* set_UART_VCflagSetUARTvcFlag4VolatileDataStorageWrite */
      VolatileDataStorage4_CircleFlag = (double)
        uart_xy_wiggler_B.DataTypeConversion3;
    }
  } else {
    if (uart_xy_wiggler_DWork.SetUARTvcFlag4_MODE) {
      uart_xy_wiggler_DWork.SetUARTvcFlag4_MODE = false;
    }
  }

  /* End of Delay: '<S8>/Wait for Buffer to clear 3' */
  /* End of Outputs for SubSystem: '<S8>/Set UART vc Flag=4' */

  /* RateTransition: '<S8>/Rate Transition7' */
  if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
    uart_xy_wiggler_B.RateTransition7_f =
      uart_xy_wiggler_DWork.RateTransition7_Buffer0_l;

    /* RateTransition: '<S8>/Rate Transition8' */
    uart_xy_wiggler_B.RateTransition8 =
      uart_xy_wiggler_DWork.RateTransition8_Buffer0;

    /* S-Function (stm32f4_usart): '<S8>/UART Rx4' */

    /* set_UART_VCflagUARTRx4: '<S8>/UART Rx4' */
    if (set_UART_VCflagUARTRx4_Receive(&UART3_Temp_Buffer[0], URX3_BUFFER_SIZE))
    {                                  /* Non-Blocking */
      uart_xy_wiggler_B.UARTRx4_o2 = set_UART_VCflagUARTRx4_data0;/* D0 */
      uart_xy_wiggler_B.UARTRx4_o1 = 1;/* READY */
    } else {
      uart_xy_wiggler_B.UARTRx4_o1 = 0;/* Not READY */
    }
  }

  /* End of RateTransition: '<S8>/Rate Transition7' */

  /* DataTypeConversion: '<S8>/Data Type Conversion4' incorporates:
   *  Delay: '<S8>/Wait for Buffer to clear5'
   */
  uart_xy_wiggler_B.DataTypeConversion4 =
    uart_xy_wiggler_DWork.WaitforBuffertoclear5_DSTATE[0];

  /* Outputs for Enabled SubSystem: '<S8>/Set UART vc Flag=5' incorporates:
   *  EnablePort: '<S58>/Enable'
   */
  /* Delay: '<S8>/Wait for Buffer to clear 4' */
  if (uart_xy_wiggler_DWork.WaitforBuffertoclear4_DSTATE_b[0U] > 0) {
    if (!uart_xy_wiggler_DWork.SetUARTvcFlag5_MODE) {
      uart_xy_wiggler_DWork.SetUARTvcFlag5_MODE = true;
    }

    if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
      /* S-Function (waijung_vdata_write): '<S58>/Volatile Data Storage Write' */

      /* set_UART_VCflagSetUARTvcFlag5VolatileDataStorageWrite */
      VolatileDataStorage5_CircleFrequency = (double)
        uart_xy_wiggler_B.DataTypeConversion4;
    }
  } else {
    if (uart_xy_wiggler_DWork.SetUARTvcFlag5_MODE) {
      uart_xy_wiggler_DWork.SetUARTvcFlag5_MODE = false;
    }
  }

  /* End of Delay: '<S8>/Wait for Buffer to clear 4' */
  /* End of Outputs for SubSystem: '<S8>/Set UART vc Flag=5' */

  /* RateTransition: '<S8>/Rate Transition10' */
  if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
    uart_xy_wiggler_B.RateTransition10 =
      uart_xy_wiggler_DWork.RateTransition10_Buffer0;

    /* RateTransition: '<S8>/Rate Transition9' */
    uart_xy_wiggler_B.RateTransition9 =
      uart_xy_wiggler_DWork.RateTransition9_Buffer0;

    /* S-Function (stm32f4_usart): '<S8>/UART Rx5' */

    /* set_UART_VCflagUARTRx5: '<S8>/UART Rx5' */
    if (set_UART_VCflagUARTRx5_Receive(&UART3_Temp_Buffer[0], URX3_BUFFER_SIZE))
    {                                  /* Non-Blocking */
      uart_xy_wiggler_B.UARTRx5_o2 = set_UART_VCflagUARTRx5_data0;/* D0 */
      uart_xy_wiggler_B.UARTRx5_o1 = 1;/* READY */
    } else {
      uart_xy_wiggler_B.UARTRx5_o1 = 0;/* Not READY */
    }
  }

  /* End of RateTransition: '<S8>/Rate Transition10' */

  /* DataTypeConversion: '<S8>/Data Type Conversion5' incorporates:
   *  Delay: '<S8>/Wait for Buffer to clear6'
   */
  uart_xy_wiggler_B.DataTypeConversion5 =
    uart_xy_wiggler_DWork.WaitforBuffertoclear6_DSTATE[0];

  /* Outputs for Enabled SubSystem: '<S8>/Set UART vc Flag=6' incorporates:
   *  EnablePort: '<S59>/Enable'
   */
  /* Delay: '<S8>/Wait for Buffer to clear 5' */
  if (uart_xy_wiggler_DWork.WaitforBuffertoclear5_DSTATE_p[0U] > 0) {
    if (!uart_xy_wiggler_DWork.SetUARTvcFlag6_MODE) {
      uart_xy_wiggler_DWork.SetUARTvcFlag6_MODE = true;
    }

    if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
      /* S-Function (waijung_vdata_write): '<S59>/Volatile Data Storage Write' */

      /* set_UART_VCflagSetUARTvcFlag6VolatileDataStorageWrite */
      VolatileDataStorage7_CircleR = (double)
        uart_xy_wiggler_B.DataTypeConversion5;
    }
  } else {
    if (uart_xy_wiggler_DWork.SetUARTvcFlag6_MODE) {
      uart_xy_wiggler_DWork.SetUARTvcFlag6_MODE = false;
    }
  }

  /* End of Delay: '<S8>/Wait for Buffer to clear 5' */
  /* End of Outputs for SubSystem: '<S8>/Set UART vc Flag=6' */

  /* RateTransition: '<S8>/Rate Transition11' */
  if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
    uart_xy_wiggler_B.RateTransition11 =
      uart_xy_wiggler_DWork.RateTransition11_Buffer0;

    /* RateTransition: '<S8>/Rate Transition12' */
    uart_xy_wiggler_B.RateTransition12 =
      uart_xy_wiggler_DWork.RateTransition12_Buffer0;

    /* S-Function (stm32f4_usart): '<S8>/UART Rx6' */

    /* set_UART_VCflagUARTRx6: '<S8>/UART Rx6' */
    if (set_UART_VCflagUARTRx6_Receive(&UART3_Temp_Buffer[0], URX3_BUFFER_SIZE))
    {                                  /* Non-Blocking */
      uart_xy_wiggler_B.UARTRx6_o2 = set_UART_VCflagUARTRx6_data0;/* D0 */
      uart_xy_wiggler_B.UARTRx6_o1 = 1;/* READY */
    } else {
      uart_xy_wiggler_B.UARTRx6_o1 = 0;/* Not READY */
    }
  }

  /* End of RateTransition: '<S8>/Rate Transition11' */

  /* Delay: '<S8>/Wait for Buffer to clear2' */
  uart_xy_wiggler_B.WaitforBuffertoclear2 =
    uart_xy_wiggler_DWork.WaitforBuffertoclear2_DSTATE[0];

  /* Outputs for Enabled SubSystem: '<S8>/Set UART vc Flag=3' incorporates:
   *  EnablePort: '<S56>/Enable'
   */
  /* Delay: '<S8>/Wait for Buffer to clear 2' */
  if (uart_xy_wiggler_DWork.WaitforBuffertoclear2_DSTATE_l[0U] > 0) {
    if (!uart_xy_wiggler_DWork.SetUARTvcFlag3_MODE) {
      uart_xy_wiggler_DWork.SetUARTvcFlag3_MODE = true;
    }

    /* S-Function (waijung_vdata_write): '<S56>/Volatile Data Storage Write' */

    /* set_UART_VCflagSetUARTvcFlag3VolatileDataStorageWrite */
    VolatileDataStorage1_Laser = (float)uart_xy_wiggler_B.WaitforBuffertoclear2;
  } else {
    if (uart_xy_wiggler_DWork.SetUARTvcFlag3_MODE) {
      uart_xy_wiggler_DWork.SetUARTvcFlag3_MODE = false;
    }
  }

  /* End of Delay: '<S8>/Wait for Buffer to clear 2' */
  /* End of Outputs for SubSystem: '<S8>/Set UART vc Flag=3' */

  /* RateTransition: '<S8>/Rate Transition5' */
  if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
    uart_xy_wiggler_B.RateTransition5_n =
      uart_xy_wiggler_DWork.RateTransition5_Buffer0_m;

    /* RateTransition: '<S8>/Rate Transition6' */
    uart_xy_wiggler_B.RateTransition6 =
      uart_xy_wiggler_DWork.RateTransition6_Buffer0;

    /* S-Function (stm32f4_usart): '<S8>/UART Rx2' */

    /* set_UART_VCflagUARTRx2: '<S8>/UART Rx2' */
    if (set_UART_VCflagUARTRx2_Receive(&UART3_Temp_Buffer[0], URX3_BUFFER_SIZE))
    {                                  /* Non-Blocking */
      uart_xy_wiggler_B.UARTRx2_o2 = set_UART_VCflagUARTRx2_data0;/* D0 */
      uart_xy_wiggler_B.UARTRx2_o1 = 1;/* READY */
    } else {
      uart_xy_wiggler_B.UARTRx2_o1 = 0;/* Not READY */
    }

    /* S-Function (stm32f4_usart): '<S8>/UART Rx3' */

    /* set_UART_VCflagUARTRx3: '<S8>/UART Rx3' */
    if (set_UART_VCflagUARTRx3_Receive(&UART3_Temp_Buffer[0], URX3_BUFFER_SIZE))
    {                                  /* Non-Blocking */
      uart_xy_wiggler_B.UARTRx3_o2 = set_UART_VCflagUARTRx3_data0;/* D0 */
      uart_xy_wiggler_B.UARTRx3_o1 = 1;/* READY */
    } else {
      uart_xy_wiggler_B.UARTRx3_o1 = 0;/* Not READY */
    }

    /* Outputs for Enabled SubSystem: '<S8>/flag_setting' incorporates:
     *  EnablePort: '<S60>/Enable'
     */
    if (uart_xy_wiggler_B.UARTRx3_o1 > 0) {
      if (!uart_xy_wiggler_DWork.flag_setting_MODE) {
        uart_xy_wiggler_DWork.flag_setting_MODE = true;
      }

      /* DataTypeConversion: '<S60>/Data Type Conversion' */
      uart_xy_wiggler_B.DataTypeConversion = (uint8_T)
        uart_xy_wiggler_B.UARTRx3_o2;

      /* S-Function (waijung_vdata_write): '<S60>/Volatile Data Storage Write' */

      /* set_UART_VCflagflag_settingVolatileDataStorageWrite */
      VolatileDataStorage3_flag = (uint8_t)uart_xy_wiggler_B.DataTypeConversion;
    } else {
      if (uart_xy_wiggler_DWork.flag_setting_MODE) {
        uart_xy_wiggler_DWork.flag_setting_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S8>/flag_setting' */
  }

  /* End of RateTransition: '<S8>/Rate Transition5' */

  /* DataTypeConversion: '<S52>/Data Type Conversion1' incorporates:
   *  Delay: '<S52>/Wait for Buffer to clear1'
   */
  uart_xy_wiggler_B.DataTypeConversion1_k =
    uart_xy_wiggler_DWork.WaitforBuffertoclear1_DSTATE_p[0];

  /* Outputs for Enabled SubSystem: '<S52>/Set UART vc Flag=1' incorporates:
   *  EnablePort: '<S61>/Enable'
   */
  /* Delay: '<S52>/Wait for Buffer to clear 1' */
  if (uart_xy_wiggler_DWork.WaitforBuffertoclear1_DSTATE_d[0U] > 0) {
    if (!uart_xy_wiggler_DWork.SetUARTvcFlag1_MODE_l) {
      uart_xy_wiggler_DWork.SetUARTvcFlag1_MODE_l = true;
    }

    if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
      /* S-Function (waijung_vdata_write): '<S61>/Volatile Data Storage Write' */

      /* set_UART_VCflagCalibrationDataUartSetUARTvcFlag1VolatileDataStorageWrite */
      CalibrationDataVolatileDataStorage1_ab3 = (double)
        uart_xy_wiggler_B.DataTypeConversion1_k;
    }
  } else {
    if (uart_xy_wiggler_DWork.SetUARTvcFlag1_MODE_l) {
      uart_xy_wiggler_DWork.SetUARTvcFlag1_MODE_l = false;
    }
  }

  /* End of Delay: '<S52>/Wait for Buffer to clear 1' */
  /* End of Outputs for SubSystem: '<S52>/Set UART vc Flag=1' */

  /* RateTransition: '<S52>/Rate Transition1' */
  if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
    uart_xy_wiggler_B.RateTransition1 =
      uart_xy_wiggler_DWork.RateTransition1_Buffer0;

    /* RateTransition: '<S52>/Rate Transition2' */
    uart_xy_wiggler_B.RateTransition2_g =
      uart_xy_wiggler_DWork.RateTransition2_Buffer0_h;

    /* S-Function (stm32f4_usart): '<S52>/UART Rx1' */

    /* set_UART_VCflagCalibrationDataUartUARTRx1: '<S52>/UART Rx1' */
    if (set_UART_VCflagCalibrationDataUartUARTRx1_Receive(&UART3_Temp_Buffer[0],
         URX3_BUFFER_SIZE)) {          /* Non-Blocking */
      uart_xy_wiggler_B.UARTRx1_o2_p =
        set_UART_VCflagCalibrationDataUartUARTRx1_data0;/* D0 */
      uart_xy_wiggler_B.UARTRx1_o1_p = 1;/* READY */
    } else {
      uart_xy_wiggler_B.UARTRx1_o1_p = 0;/* Not READY */
    }
  }

  /* End of RateTransition: '<S52>/Rate Transition1' */

  /* DataTypeConversion: '<S52>/Data Type Conversion10' incorporates:
   *  Delay: '<S52>/Wait for Buffer to clear11'
   */
  uart_xy_wiggler_B.DataTypeConversion10 =
    uart_xy_wiggler_DWork.WaitforBuffertoclear11_DSTATE[0];

  /* Outputs for Enabled SubSystem: '<S52>/Set UART vc Flag=11' incorporates:
   *  EnablePort: '<S63>/Enable'
   */
  /* Delay: '<S52>/Wait for Buffer to clear 10' */
  if (uart_xy_wiggler_DWork.WaitforBuffertoclear10_DSTATE_n[0U] > 0) {
    if (!uart_xy_wiggler_DWork.SetUARTvcFlag11_MODE_f) {
      uart_xy_wiggler_DWork.SetUARTvcFlag11_MODE_f = true;
    }

    if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
      /* S-Function (waijung_vdata_write): '<S63>/Volatile Data Storage Write' */

      /* set_UART_VCflagCalibrationDataUartSetUARTvcFlag11VolatileDataStorageWrite */
      CalibrationDataVolatileDataStorage12_ab2 = (double)
        uart_xy_wiggler_B.DataTypeConversion10;
    }
  } else {
    if (uart_xy_wiggler_DWork.SetUARTvcFlag11_MODE_f) {
      uart_xy_wiggler_DWork.SetUARTvcFlag11_MODE_f = false;
    }
  }

  /* End of Delay: '<S52>/Wait for Buffer to clear 10' */
  /* End of Outputs for SubSystem: '<S52>/Set UART vc Flag=11' */

  /* RateTransition: '<S52>/Rate Transition21' */
  if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
    uart_xy_wiggler_B.RateTransition21 =
      uart_xy_wiggler_DWork.RateTransition21_Buffer0;

    /* RateTransition: '<S52>/Rate Transition22' */
    uart_xy_wiggler_B.RateTransition22 =
      uart_xy_wiggler_DWork.RateTransition22_Buffer0;

    /* S-Function (stm32f4_usart): '<S52>/UART Rx11' */

    /* set_UART_VCflagCalibrationDataUartUARTRx11: '<S52>/UART Rx11' */
    if (set_UART_VCflagCalibrationDataUartUARTRx11_Receive(&UART3_Temp_Buffer[0],
         URX3_BUFFER_SIZE)) {          /* Non-Blocking */
      uart_xy_wiggler_B.UARTRx11_o2 =
        set_UART_VCflagCalibrationDataUartUARTRx11_data0;/* D0 */
      uart_xy_wiggler_B.UARTRx11_o1 = 1;/* READY */
    } else {
      uart_xy_wiggler_B.UARTRx11_o1 = 0;/* Not READY */
    }
  }

  /* End of RateTransition: '<S52>/Rate Transition21' */

  /* DataTypeConversion: '<S52>/Data Type Conversion2' incorporates:
   *  Delay: '<S52>/Wait for Buffer to clear2'
   */
  uart_xy_wiggler_B.DataTypeConversion2_c =
    uart_xy_wiggler_DWork.WaitforBuffertoclear2_DSTATE_b[0];

  /* Outputs for Enabled SubSystem: '<S52>/Set UART vc Flag=2' incorporates:
   *  EnablePort: '<S64>/Enable'
   */
  /* Delay: '<S52>/Wait for Buffer to clear 2' */
  if (uart_xy_wiggler_DWork.WaitforBuffertoclear2_DSTATE_d[0U] > 0) {
    if (!uart_xy_wiggler_DWork.SetUARTvcFlag2_MODE_k) {
      uart_xy_wiggler_DWork.SetUARTvcFlag2_MODE_k = true;
    }

    if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
      /* S-Function (waijung_vdata_write): '<S64>/Volatile Data Storage Write' */

      /* set_UART_VCflagCalibrationDataUartSetUARTvcFlag2VolatileDataStorageWrite */
      CalibrationDataVolatileDataStorage2_ab4 = (double)
        uart_xy_wiggler_B.DataTypeConversion2_c;
    }
  } else {
    if (uart_xy_wiggler_DWork.SetUARTvcFlag2_MODE_k) {
      uart_xy_wiggler_DWork.SetUARTvcFlag2_MODE_k = false;
    }
  }

  /* End of Delay: '<S52>/Wait for Buffer to clear 2' */
  /* End of Outputs for SubSystem: '<S52>/Set UART vc Flag=2' */

  /* RateTransition: '<S52>/Rate Transition3' */
  if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
    uart_xy_wiggler_B.RateTransition3_p =
      uart_xy_wiggler_DWork.RateTransition3_Buffer0_o;

    /* RateTransition: '<S52>/Rate Transition4' */
    uart_xy_wiggler_B.RateTransition4_e =
      uart_xy_wiggler_DWork.RateTransition4_Buffer0_k;

    /* S-Function (stm32f4_usart): '<S52>/UART Rx2' */

    /* set_UART_VCflagCalibrationDataUartUARTRx2: '<S52>/UART Rx2' */
    if (set_UART_VCflagCalibrationDataUartUARTRx2_Receive(&UART3_Temp_Buffer[0],
         URX3_BUFFER_SIZE)) {          /* Non-Blocking */
      uart_xy_wiggler_B.UARTRx2_o2_i =
        set_UART_VCflagCalibrationDataUartUARTRx2_data0;/* D0 */
      uart_xy_wiggler_B.UARTRx2_o1_p = 1;/* READY */
    } else {
      uart_xy_wiggler_B.UARTRx2_o1_p = 0;/* Not READY */
    }
  }

  /* End of RateTransition: '<S52>/Rate Transition3' */

  /* DataTypeConversion: '<S52>/Data Type Conversion3' incorporates:
   *  Delay: '<S52>/Wait for Buffer to clear3'
   */
  uart_xy_wiggler_B.DataTypeConversion3_f =
    uart_xy_wiggler_DWork.WaitforBuffertoclear3_DSTATE_n[0];

  /* Outputs for Enabled SubSystem: '<S52>/Set UART vc Flag=3' incorporates:
   *  EnablePort: '<S65>/Enable'
   */
  /* Delay: '<S52>/Wait for Buffer to clear 3' */
  if (uart_xy_wiggler_DWork.WaitforBuffertoclear3_DSTATE_c[0U] > 0) {
    if (!uart_xy_wiggler_DWork.SetUARTvcFlag3_MODE_f) {
      uart_xy_wiggler_DWork.SetUARTvcFlag3_MODE_f = true;
    }

    if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
      /* S-Function (waijung_vdata_write): '<S65>/Volatile Data Storage Write' */

      /* set_UART_VCflagCalibrationDataUartSetUARTvcFlag3VolatileDataStorageWrite */
      CalibrationDataVolatileDataStorage3_ab5 = (double)
        uart_xy_wiggler_B.DataTypeConversion3_f;
    }
  } else {
    if (uart_xy_wiggler_DWork.SetUARTvcFlag3_MODE_f) {
      uart_xy_wiggler_DWork.SetUARTvcFlag3_MODE_f = false;
    }
  }

  /* End of Delay: '<S52>/Wait for Buffer to clear 3' */
  /* End of Outputs for SubSystem: '<S52>/Set UART vc Flag=3' */

  /* RateTransition: '<S52>/Rate Transition5' */
  if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
    uart_xy_wiggler_B.RateTransition5 =
      uart_xy_wiggler_DWork.RateTransition5_Buffer0;

    /* RateTransition: '<S52>/Rate Transition6' */
    uart_xy_wiggler_B.RateTransition6_d =
      uart_xy_wiggler_DWork.RateTransition6_Buffer0_c;

    /* S-Function (stm32f4_usart): '<S52>/UART Rx3' */

    /* set_UART_VCflagCalibrationDataUartUARTRx3: '<S52>/UART Rx3' */
    if (set_UART_VCflagCalibrationDataUartUARTRx3_Receive(&UART3_Temp_Buffer[0],
         URX3_BUFFER_SIZE)) {          /* Non-Blocking */
      uart_xy_wiggler_B.UARTRx3_o2_g =
        set_UART_VCflagCalibrationDataUartUARTRx3_data0;/* D0 */
      uart_xy_wiggler_B.UARTRx3_o1_d = 1;/* READY */
    } else {
      uart_xy_wiggler_B.UARTRx3_o1_d = 0;/* Not READY */
    }
  }

  /* End of RateTransition: '<S52>/Rate Transition5' */

  /* DataTypeConversion: '<S52>/Data Type Conversion4' incorporates:
   *  Delay: '<S52>/Wait for Buffer to clear4'
   */
  uart_xy_wiggler_B.DataTypeConversion4_e =
    uart_xy_wiggler_DWork.WaitforBuffertoclear4_DSTATE_p[0];

  /* Outputs for Enabled SubSystem: '<S52>/Set UART vc Flag=4' incorporates:
   *  EnablePort: '<S66>/Enable'
   */
  /* Delay: '<S52>/Wait for Buffer to clear 4' */
  if (uart_xy_wiggler_DWork.WaitforBuffertoclear4_DSTATE_c[0U] > 0) {
    if (!uart_xy_wiggler_DWork.SetUARTvcFlag4_MODE_c) {
      uart_xy_wiggler_DWork.SetUARTvcFlag4_MODE_c = true;
    }

    if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
      /* S-Function (waijung_vdata_write): '<S66>/Volatile Data Storage Write' */

      /* set_UART_VCflagCalibrationDataUartSetUARTvcFlag4VolatileDataStorageWrite */
      CalibrationDataVolatileDataStorage6_ab8 = (double)
        uart_xy_wiggler_B.DataTypeConversion4_e;
    }
  } else {
    if (uart_xy_wiggler_DWork.SetUARTvcFlag4_MODE_c) {
      uart_xy_wiggler_DWork.SetUARTvcFlag4_MODE_c = false;
    }
  }

  /* End of Delay: '<S52>/Wait for Buffer to clear 4' */
  /* End of Outputs for SubSystem: '<S52>/Set UART vc Flag=4' */

  /* RateTransition: '<S52>/Rate Transition7' */
  if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
    uart_xy_wiggler_B.RateTransition7 =
      uart_xy_wiggler_DWork.RateTransition7_Buffer0;

    /* RateTransition: '<S52>/Rate Transition9' */
    uart_xy_wiggler_B.RateTransition9_c =
      uart_xy_wiggler_DWork.RateTransition9_Buffer0_c;

    /* S-Function (stm32f4_usart): '<S52>/UART Rx4' */

    /* set_UART_VCflagCalibrationDataUartUARTRx4: '<S52>/UART Rx4' */
    if (set_UART_VCflagCalibrationDataUartUARTRx4_Receive(&UART3_Temp_Buffer[0],
         URX3_BUFFER_SIZE)) {          /* Non-Blocking */
      uart_xy_wiggler_B.UARTRx4_o2_o =
        set_UART_VCflagCalibrationDataUartUARTRx4_data0;/* D0 */
      uart_xy_wiggler_B.UARTRx4_o1_f = 1;/* READY */
    } else {
      uart_xy_wiggler_B.UARTRx4_o1_f = 0;/* Not READY */
    }
  }

  /* End of RateTransition: '<S52>/Rate Transition7' */

  /* DataTypeConversion: '<S52>/Data Type Conversion5' incorporates:
   *  Delay: '<S52>/Wait for Buffer to clear6'
   */
  uart_xy_wiggler_B.DataTypeConversion5_n =
    uart_xy_wiggler_DWork.WaitforBuffertoclear6_DSTATE_b[0];

  /* Outputs for Enabled SubSystem: '<S52>/Set UART vc Flag=6' incorporates:
   *  EnablePort: '<S68>/Enable'
   */
  /* Delay: '<S52>/Wait for Buffer to clear 5' */
  if (uart_xy_wiggler_DWork.WaitforBuffertoclear5_DSTATE_c[0U] > 0) {
    if (!uart_xy_wiggler_DWork.SetUARTvcFlag6_MODE_g) {
      uart_xy_wiggler_DWork.SetUARTvcFlag6_MODE_g = true;
    }

    if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
      /* S-Function (waijung_vdata_write): '<S68>/Volatile Data Storage Write' */

      /* set_UART_VCflagCalibrationDataUartSetUARTvcFlag6VolatileDataStorageWrite */
      CalibrationDataVolatileDataStorage5_ab7 = (double)
        uart_xy_wiggler_B.DataTypeConversion5_n;
    }
  } else {
    if (uart_xy_wiggler_DWork.SetUARTvcFlag6_MODE_g) {
      uart_xy_wiggler_DWork.SetUARTvcFlag6_MODE_g = false;
    }
  }

  /* End of Delay: '<S52>/Wait for Buffer to clear 5' */
  /* End of Outputs for SubSystem: '<S52>/Set UART vc Flag=6' */

  /* RateTransition: '<S52>/Rate Transition11' */
  if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
    uart_xy_wiggler_B.RateTransition11_n =
      uart_xy_wiggler_DWork.RateTransition11_Buffer0_d;

    /* RateTransition: '<S52>/Rate Transition12' */
    uart_xy_wiggler_B.RateTransition12_h =
      uart_xy_wiggler_DWork.RateTransition12_Buffer0_i;

    /* S-Function (stm32f4_usart): '<S52>/UART Rx6' */

    /* set_UART_VCflagCalibrationDataUartUARTRx6: '<S52>/UART Rx6' */
    if (set_UART_VCflagCalibrationDataUartUARTRx6_Receive(&UART3_Temp_Buffer[0],
         URX3_BUFFER_SIZE)) {          /* Non-Blocking */
      uart_xy_wiggler_B.UARTRx6_o2_h =
        set_UART_VCflagCalibrationDataUartUARTRx6_data0;/* D0 */
      uart_xy_wiggler_B.UARTRx6_o1_i = 1;/* READY */
    } else {
      uart_xy_wiggler_B.UARTRx6_o1_i = 0;/* Not READY */
    }
  }

  /* End of RateTransition: '<S52>/Rate Transition11' */

  /* DataTypeConversion: '<S52>/Data Type Conversion6' incorporates:
   *  Delay: '<S52>/Wait for Buffer to clear7'
   */
  uart_xy_wiggler_B.DataTypeConversion6 =
    uart_xy_wiggler_DWork.WaitforBuffertoclear7_DSTATE[0];

  /* Outputs for Enabled SubSystem: '<S52>/Set UART vc Flag=7' incorporates:
   *  EnablePort: '<S69>/Enable'
   */
  /* Delay: '<S52>/Wait for Buffer to clear 6' */
  if (uart_xy_wiggler_DWork.WaitforBuffertoclear6_DSTATE_br[0U] > 0) {
    if (!uart_xy_wiggler_DWork.SetUARTvcFlag7_MODE_h) {
      uart_xy_wiggler_DWork.SetUARTvcFlag7_MODE_h = true;
    }

    if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
      /* S-Function (waijung_vdata_write): '<S69>/Volatile Data Storage Write' */

      /* set_UART_VCflagCalibrationDataUartSetUARTvcFlag7VolatileDataStorageWrite */
      CalibrationDataVolatileDataStorage7_ab9 = (double)
        uart_xy_wiggler_B.DataTypeConversion6;
    }
  } else {
    if (uart_xy_wiggler_DWork.SetUARTvcFlag7_MODE_h) {
      uart_xy_wiggler_DWork.SetUARTvcFlag7_MODE_h = false;
    }
  }

  /* End of Delay: '<S52>/Wait for Buffer to clear 6' */
  /* End of Outputs for SubSystem: '<S52>/Set UART vc Flag=7' */

  /* RateTransition: '<S52>/Rate Transition13' */
  if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
    uart_xy_wiggler_B.RateTransition13 =
      uart_xy_wiggler_DWork.RateTransition13_Buffer0;

    /* RateTransition: '<S52>/Rate Transition14' */
    uart_xy_wiggler_B.RateTransition14 =
      uart_xy_wiggler_DWork.RateTransition14_Buffer0;

    /* S-Function (stm32f4_usart): '<S52>/UART Rx7' */

    /* set_UART_VCflagCalibrationDataUartUARTRx7: '<S52>/UART Rx7' */
    if (set_UART_VCflagCalibrationDataUartUARTRx7_Receive(&UART3_Temp_Buffer[0],
         URX3_BUFFER_SIZE)) {          /* Non-Blocking */
      uart_xy_wiggler_B.UARTRx7_o2 =
        set_UART_VCflagCalibrationDataUartUARTRx7_data0;/* D0 */
      uart_xy_wiggler_B.UARTRx7_o1 = 1;/* READY */
    } else {
      uart_xy_wiggler_B.UARTRx7_o1 = 0;/* Not READY */
    }
  }

  /* End of RateTransition: '<S52>/Rate Transition13' */

  /* DataTypeConversion: '<S52>/Data Type Conversion7' incorporates:
   *  Delay: '<S52>/Wait for Buffer to clear8'
   */
  uart_xy_wiggler_B.DataTypeConversion7 =
    uart_xy_wiggler_DWork.WaitforBuffertoclear8_DSTATE[0];

  /* Outputs for Enabled SubSystem: '<S52>/Set UART vc Flag=8' incorporates:
   *  EnablePort: '<S70>/Enable'
   */
  /* Delay: '<S52>/Wait for Buffer to clear 7' */
  if (uart_xy_wiggler_DWork.WaitforBuffertoclear7_DSTATE_a[0U] > 0) {
    if (!uart_xy_wiggler_DWork.SetUARTvcFlag8_MODE_f) {
      uart_xy_wiggler_DWork.SetUARTvcFlag8_MODE_f = true;
    }

    if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
      /* S-Function (waijung_vdata_write): '<S70>/Volatile Data Storage Write' */

      /* set_UART_VCflagCalibrationDataUartSetUARTvcFlag8VolatileDataStorageWrite */
      CalibrationDataVolatileDataStorage8_ab10 = (double)
        uart_xy_wiggler_B.DataTypeConversion7;
    }
  } else {
    if (uart_xy_wiggler_DWork.SetUARTvcFlag8_MODE_f) {
      uart_xy_wiggler_DWork.SetUARTvcFlag8_MODE_f = false;
    }
  }

  /* End of Delay: '<S52>/Wait for Buffer to clear 7' */
  /* End of Outputs for SubSystem: '<S52>/Set UART vc Flag=8' */

  /* RateTransition: '<S52>/Rate Transition15' */
  if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
    uart_xy_wiggler_B.RateTransition15 =
      uart_xy_wiggler_DWork.RateTransition15_Buffer0;

    /* RateTransition: '<S52>/Rate Transition16' */
    uart_xy_wiggler_B.RateTransition16 =
      uart_xy_wiggler_DWork.RateTransition16_Buffer0;

    /* S-Function (stm32f4_usart): '<S52>/UART Rx8' */

    /* set_UART_VCflagCalibrationDataUartUARTRx8: '<S52>/UART Rx8' */
    if (set_UART_VCflagCalibrationDataUartUARTRx8_Receive(&UART3_Temp_Buffer[0],
         URX3_BUFFER_SIZE)) {          /* Non-Blocking */
      uart_xy_wiggler_B.UARTRx8_o2 =
        set_UART_VCflagCalibrationDataUartUARTRx8_data0;/* D0 */
      uart_xy_wiggler_B.UARTRx8_o1 = 1;/* READY */
    } else {
      uart_xy_wiggler_B.UARTRx8_o1 = 0;/* Not READY */
    }
  }

  /* End of RateTransition: '<S52>/Rate Transition15' */

  /* DataTypeConversion: '<S52>/Data Type Conversion8' incorporates:
   *  Delay: '<S52>/Wait for Buffer to clear5'
   */
  uart_xy_wiggler_B.DataTypeConversion8 =
    uart_xy_wiggler_DWork.WaitforBuffertoclear5_DSTATE_l[0];

  /* Outputs for Enabled SubSystem: '<S52>/Set UART vc Flag=5' incorporates:
   *  EnablePort: '<S67>/Enable'
   */
  /* Delay: '<S52>/Wait for Buffer to clear 8' */
  if (uart_xy_wiggler_DWork.WaitforBuffertoclear8_DSTATE_d[0U] > 0) {
    if (!uart_xy_wiggler_DWork.SetUARTvcFlag5_MODE_j) {
      uart_xy_wiggler_DWork.SetUARTvcFlag5_MODE_j = true;
    }

    if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
      /* S-Function (waijung_vdata_write): '<S67>/Volatile Data Storage Write' */

      /* set_UART_VCflagCalibrationDataUartSetUARTvcFlag5VolatileDataStorageWrite */
      CalibrationDataVolatileDataStorage4_ab6 = (double)
        uart_xy_wiggler_B.DataTypeConversion8;
    }
  } else {
    if (uart_xy_wiggler_DWork.SetUARTvcFlag5_MODE_j) {
      uart_xy_wiggler_DWork.SetUARTvcFlag5_MODE_j = false;
    }
  }

  /* End of Delay: '<S52>/Wait for Buffer to clear 8' */
  /* End of Outputs for SubSystem: '<S52>/Set UART vc Flag=5' */

  /* RateTransition: '<S52>/Rate Transition10' */
  if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
    uart_xy_wiggler_B.RateTransition10_e =
      uart_xy_wiggler_DWork.RateTransition10_Buffer0_g;

    /* RateTransition: '<S52>/Rate Transition8' */
    uart_xy_wiggler_B.RateTransition8_c =
      uart_xy_wiggler_DWork.RateTransition8_Buffer0_o;

    /* S-Function (stm32f4_usart): '<S52>/UART Rx5' */

    /* set_UART_VCflagCalibrationDataUartUARTRx5: '<S52>/UART Rx5' */
    if (set_UART_VCflagCalibrationDataUartUARTRx5_Receive(&UART3_Temp_Buffer[0],
         URX3_BUFFER_SIZE)) {          /* Non-Blocking */
      uart_xy_wiggler_B.UARTRx5_o2_h =
        set_UART_VCflagCalibrationDataUartUARTRx5_data0;/* D0 */
      uart_xy_wiggler_B.UARTRx5_o1_p = 1;/* READY */
    } else {
      uart_xy_wiggler_B.UARTRx5_o1_p = 0;/* Not READY */
    }
  }

  /* End of RateTransition: '<S52>/Rate Transition10' */

  /* DataTypeConversion: '<S52>/Data Type Conversion9' incorporates:
   *  Delay: '<S52>/Wait for Buffer to clear10'
   */
  uart_xy_wiggler_B.DataTypeConversion9 =
    uart_xy_wiggler_DWork.WaitforBuffertoclear10_DSTATE[0];

  /* Outputs for Enabled SubSystem: '<S52>/Set UART vc Flag=10' incorporates:
   *  EnablePort: '<S62>/Enable'
   */
  /* Delay: '<S52>/Wait for Buffer to clear 9' */
  if (uart_xy_wiggler_DWork.WaitforBuffertoclear9_DSTATE_i[0U] > 0) {
    if (!uart_xy_wiggler_DWork.SetUARTvcFlag10_MODE_a) {
      uart_xy_wiggler_DWork.SetUARTvcFlag10_MODE_a = true;
    }

    if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
      /* S-Function (waijung_vdata_write): '<S62>/Volatile Data Storage Write' */

      /* set_UART_VCflagCalibrationDataUartSetUARTvcFlag10VolatileDataStorageWrite */
      CalibrationDataVolatileDataStorage11_ab1 = (double)
        uart_xy_wiggler_B.DataTypeConversion9;
    }
  } else {
    if (uart_xy_wiggler_DWork.SetUARTvcFlag10_MODE_a) {
      uart_xy_wiggler_DWork.SetUARTvcFlag10_MODE_a = false;
    }
  }

  /* End of Delay: '<S52>/Wait for Buffer to clear 9' */
  /* End of Outputs for SubSystem: '<S52>/Set UART vc Flag=10' */

  /* RateTransition: '<S52>/Rate Transition19' */
  if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
    uart_xy_wiggler_B.RateTransition19 =
      uart_xy_wiggler_DWork.RateTransition19_Buffer0;

    /* RateTransition: '<S52>/Rate Transition20' */
    uart_xy_wiggler_B.RateTransition20 =
      uart_xy_wiggler_DWork.RateTransition20_Buffer0;

    /* S-Function (stm32f4_usart): '<S52>/UART Rx10' */

    /* set_UART_VCflagCalibrationDataUartUARTRx10: '<S52>/UART Rx10' */
    if (set_UART_VCflagCalibrationDataUartUARTRx10_Receive(&UART3_Temp_Buffer[0],
         URX3_BUFFER_SIZE)) {          /* Non-Blocking */
      uart_xy_wiggler_B.UARTRx10_o2 =
        set_UART_VCflagCalibrationDataUartUARTRx10_data0;/* D0 */
      uart_xy_wiggler_B.UARTRx10_o1 = 1;/* READY */
    } else {
      uart_xy_wiggler_B.UARTRx10_o1 = 0;/* Not READY */
    }
  }

  /* End of RateTransition: '<S52>/Rate Transition19' */

  /* DataTypeConversion: '<S53>/Data Type Conversion1' incorporates:
   *  Delay: '<S53>/Wait for Buffer to clear1'
   */
  uart_xy_wiggler_B.DataTypeConversion1_a =
    uart_xy_wiggler_DWork.WaitforBuffertoclear1_DSTATE_c[0];

  /* Outputs for Enabled SubSystem: '<S53>/Set UART vc Flag=1' incorporates:
   *  EnablePort: '<S71>/Enable'
   */
  /* Delay: '<S53>/Wait for Buffer to clear 1' */
  if (uart_xy_wiggler_DWork.WaitforBuffertoclear1_DSTATE_n[0U] > 0) {
    if (!uart_xy_wiggler_DWork.SetUARTvcFlag1_MODE_o) {
      uart_xy_wiggler_DWork.SetUARTvcFlag1_MODE_o = true;
    }

    if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
      /* S-Function (waijung_vdata_write): '<S71>/Volatile Data Storage Write' */

      /* set_UART_VCflagLissajousDataUartSetUARTvcFlag1VolatileDataStorageWrite */
      LissajousDataVolatileDataStorage7_A_Laser = (double)
        uart_xy_wiggler_B.DataTypeConversion1_a;
    }
  } else {
    if (uart_xy_wiggler_DWork.SetUARTvcFlag1_MODE_o) {
      uart_xy_wiggler_DWork.SetUARTvcFlag1_MODE_o = false;
    }
  }

  /* End of Delay: '<S53>/Wait for Buffer to clear 1' */
  /* End of Outputs for SubSystem: '<S53>/Set UART vc Flag=1' */

  /* RateTransition: '<S53>/Rate Transition1' */
  if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
    uart_xy_wiggler_B.RateTransition1_l =
      uart_xy_wiggler_DWork.RateTransition1_Buffer0_i;

    /* RateTransition: '<S53>/Rate Transition2' */
    uart_xy_wiggler_B.RateTransition2_o =
      uart_xy_wiggler_DWork.RateTransition2_Buffer0_g;

    /* S-Function (stm32f4_usart): '<S53>/UART Rx1' */

    /* set_UART_VCflagLissajousDataUartUARTRx1: '<S53>/UART Rx1' */
    if (set_UART_VCflagLissajousDataUartUARTRx1_Receive(&UART3_Temp_Buffer[0],
         URX3_BUFFER_SIZE)) {          /* Non-Blocking */
      uart_xy_wiggler_B.UARTRx1_o2_i =
        set_UART_VCflagLissajousDataUartUARTRx1_data0;/* D0 */
      uart_xy_wiggler_B.UARTRx1_o1_f = 1;/* READY */
    } else {
      uart_xy_wiggler_B.UARTRx1_o1_f = 0;/* Not READY */
    }
  }

  /* End of RateTransition: '<S53>/Rate Transition1' */

  /* DataTypeConversion: '<S53>/Data Type Conversion10' incorporates:
   *  Delay: '<S53>/Wait for Buffer to clear11'
   */
  uart_xy_wiggler_B.DataTypeConversion10_o =
    uart_xy_wiggler_DWork.WaitforBuffertoclear11_DSTATE_g[0];

  /* Outputs for Enabled SubSystem: '<S53>/Set UART vc Flag=11' incorporates:
   *  EnablePort: '<S73>/Enable'
   */
  /* Delay: '<S53>/Wait for Buffer to clear 10' */
  if (uart_xy_wiggler_DWork.WaitforBuffertoclear10_DSTAT_nb[0U] > 0) {
    if (!uart_xy_wiggler_DWork.SetUARTvcFlag11_MODE) {
      uart_xy_wiggler_DWork.SetUARTvcFlag11_MODE = true;
    }

    if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
      /* S-Function (waijung_vdata_write): '<S73>/Volatile Data Storage Write' */

      /* set_UART_VCflagLissajousDataUartSetUARTvcFlag11VolatileDataStorageWrite */
      LissajousDataVolatileDataStorage12_Axs = (double)
        uart_xy_wiggler_B.DataTypeConversion10_o;
    }
  } else {
    if (uart_xy_wiggler_DWork.SetUARTvcFlag11_MODE) {
      uart_xy_wiggler_DWork.SetUARTvcFlag11_MODE = false;
    }
  }

  /* End of Delay: '<S53>/Wait for Buffer to clear 10' */
  /* End of Outputs for SubSystem: '<S53>/Set UART vc Flag=11' */

  /* RateTransition: '<S53>/Rate Transition21' */
  if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
    uart_xy_wiggler_B.RateTransition21_c =
      uart_xy_wiggler_DWork.RateTransition21_Buffer0_p;

    /* RateTransition: '<S53>/Rate Transition22' */
    uart_xy_wiggler_B.RateTransition22_n =
      uart_xy_wiggler_DWork.RateTransition22_Buffer0_j;

    /* S-Function (stm32f4_usart): '<S53>/UART Rx11' */

    /* set_UART_VCflagLissajousDataUartUARTRx11: '<S53>/UART Rx11' */
    if (set_UART_VCflagLissajousDataUartUARTRx11_Receive(&UART3_Temp_Buffer[0],
         URX3_BUFFER_SIZE)) {          /* Non-Blocking */
      uart_xy_wiggler_B.UARTRx11_o2_a =
        set_UART_VCflagLissajousDataUartUARTRx11_data0;/* D0 */
      uart_xy_wiggler_B.UARTRx11_o1_c = 1;/* READY */
    } else {
      uart_xy_wiggler_B.UARTRx11_o1_c = 0;/* Not READY */
    }
  }

  /* End of RateTransition: '<S53>/Rate Transition21' */

  /* DataTypeConversion: '<S53>/Data Type Conversion6' incorporates:
   *  Delay: '<S53>/Wait for Buffer to clear7'
   */
  uart_xy_wiggler_B.DataTypeConversion6_i =
    uart_xy_wiggler_DWork.WaitforBuffertoclear7_DSTATE_f[0];

  /* Outputs for Enabled SubSystem: '<S53>/Set UART vc Flag=7' incorporates:
   *  EnablePort: '<S74>/Enable'
   */
  /* Delay: '<S53>/Wait for Buffer to clear 6' */
  if (uart_xy_wiggler_DWork.WaitforBuffertoclear6_DSTATE_j[0U] > 0) {
    if (!uart_xy_wiggler_DWork.SetUARTvcFlag7_MODE) {
      uart_xy_wiggler_DWork.SetUARTvcFlag7_MODE = true;
    }

    if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
      /* S-Function (waijung_vdata_write): '<S74>/Volatile Data Storage Write' */

      /* set_UART_VCflagLissajousDataUartSetUARTvcFlag7VolatileDataStorageWrite */
      LissajousDataVolatileDataStorage8_LissaFreq = (double)
        uart_xy_wiggler_B.DataTypeConversion6_i;
    }
  } else {
    if (uart_xy_wiggler_DWork.SetUARTvcFlag7_MODE) {
      uart_xy_wiggler_DWork.SetUARTvcFlag7_MODE = false;
    }
  }

  /* End of Delay: '<S53>/Wait for Buffer to clear 6' */
  /* End of Outputs for SubSystem: '<S53>/Set UART vc Flag=7' */

  /* RateTransition: '<S53>/Rate Transition13' */
  if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
    uart_xy_wiggler_B.RateTransition13_f =
      uart_xy_wiggler_DWork.RateTransition13_Buffer0_e;

    /* RateTransition: '<S53>/Rate Transition14' */
    uart_xy_wiggler_B.RateTransition14_h =
      uart_xy_wiggler_DWork.RateTransition14_Buffer0_a;

    /* S-Function (stm32f4_usart): '<S53>/UART Rx7' */

    /* set_UART_VCflagLissajousDataUartUARTRx7: '<S53>/UART Rx7' */
    if (set_UART_VCflagLissajousDataUartUARTRx7_Receive(&UART3_Temp_Buffer[0],
         URX3_BUFFER_SIZE)) {          /* Non-Blocking */
      uart_xy_wiggler_B.UARTRx7_o2_k =
        set_UART_VCflagLissajousDataUartUARTRx7_data0;/* D0 */
      uart_xy_wiggler_B.UARTRx7_o1_e = 1;/* READY */
    } else {
      uart_xy_wiggler_B.UARTRx7_o1_e = 0;/* Not READY */
    }
  }

  /* End of RateTransition: '<S53>/Rate Transition13' */

  /* DataTypeConversion: '<S53>/Data Type Conversion7' incorporates:
   *  Delay: '<S53>/Wait for Buffer to clear8'
   */
  uart_xy_wiggler_B.DataTypeConversion7_d =
    uart_xy_wiggler_DWork.WaitforBuffertoclear8_DSTATE_e[0];

  /* Outputs for Enabled SubSystem: '<S53>/Set UART vc Flag=8' incorporates:
   *  EnablePort: '<S75>/Enable'
   */
  /* Delay: '<S53>/Wait for Buffer to clear 7' */
  if (uart_xy_wiggler_DWork.WaitforBuffertoclear7_DSTATE_d[0U] > 0) {
    if (!uart_xy_wiggler_DWork.SetUARTvcFlag8_MODE) {
      uart_xy_wiggler_DWork.SetUARTvcFlag8_MODE = true;
    }

    if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
      /* S-Function (waijung_vdata_write): '<S75>/Volatile Data Storage Write' */

      /* set_UART_VCflagLissajousDataUartSetUARTvcFlag8VolatileDataStorageWrite */
      LissajousDataVolatileDataStorage9_Axc = (double)
        uart_xy_wiggler_B.DataTypeConversion7_d;
    }
  } else {
    if (uart_xy_wiggler_DWork.SetUARTvcFlag8_MODE) {
      uart_xy_wiggler_DWork.SetUARTvcFlag8_MODE = false;
    }
  }

  /* End of Delay: '<S53>/Wait for Buffer to clear 7' */
  /* End of Outputs for SubSystem: '<S53>/Set UART vc Flag=8' */

  /* RateTransition: '<S53>/Rate Transition15' */
  if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
    uart_xy_wiggler_B.RateTransition15_e =
      uart_xy_wiggler_DWork.RateTransition15_Buffer0_l;

    /* RateTransition: '<S53>/Rate Transition16' */
    uart_xy_wiggler_B.RateTransition16_o =
      uart_xy_wiggler_DWork.RateTransition16_Buffer0_p;

    /* S-Function (stm32f4_usart): '<S53>/UART Rx8' */

    /* set_UART_VCflagLissajousDataUartUARTRx8: '<S53>/UART Rx8' */
    if (set_UART_VCflagLissajousDataUartUARTRx8_Receive(&UART3_Temp_Buffer[0],
         URX3_BUFFER_SIZE)) {          /* Non-Blocking */
      uart_xy_wiggler_B.UARTRx8_o2_g =
        set_UART_VCflagLissajousDataUartUARTRx8_data0;/* D0 */
      uart_xy_wiggler_B.UARTRx8_o1_c = 1;/* READY */
    } else {
      uart_xy_wiggler_B.UARTRx8_o1_c = 0;/* Not READY */
    }
  }

  /* End of RateTransition: '<S53>/Rate Transition15' */

  /* DataTypeConversion: '<S53>/Data Type Conversion8' incorporates:
   *  Delay: '<S53>/Wait for Buffer to clear9'
   */
  uart_xy_wiggler_B.DataTypeConversion8_m =
    uart_xy_wiggler_DWork.WaitforBuffertoclear9_DSTATE[0];

  /* Outputs for Enabled SubSystem: '<S53>/Set UART vc Flag=9' incorporates:
   *  EnablePort: '<S76>/Enable'
   */
  /* Delay: '<S53>/Wait for Buffer to clear 8' */
  if (uart_xy_wiggler_DWork.WaitforBuffertoclear8_DSTATE_j[0U] > 0) {
    if (!uart_xy_wiggler_DWork.SetUARTvcFlag9_MODE) {
      uart_xy_wiggler_DWork.SetUARTvcFlag9_MODE = true;
    }

    if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
      /* S-Function (waijung_vdata_write): '<S76>/Volatile Data Storage Write' */

      /* set_UART_VCflagLissajousDataUartSetUARTvcFlag9VolatileDataStorageWrite */
      LissajousDataVolatileDataStorage10_Ays = (double)
        uart_xy_wiggler_B.DataTypeConversion8_m;
    }
  } else {
    if (uart_xy_wiggler_DWork.SetUARTvcFlag9_MODE) {
      uart_xy_wiggler_DWork.SetUARTvcFlag9_MODE = false;
    }
  }

  /* End of Delay: '<S53>/Wait for Buffer to clear 8' */
  /* End of Outputs for SubSystem: '<S53>/Set UART vc Flag=9' */

  /* RateTransition: '<S53>/Rate Transition17' */
  if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
    uart_xy_wiggler_B.RateTransition17 =
      uart_xy_wiggler_DWork.RateTransition17_Buffer0;

    /* RateTransition: '<S53>/Rate Transition18' */
    uart_xy_wiggler_B.RateTransition18 =
      uart_xy_wiggler_DWork.RateTransition18_Buffer0;

    /* S-Function (stm32f4_usart): '<S53>/UART Rx9' */

    /* set_UART_VCflagLissajousDataUartUARTRx9: '<S53>/UART Rx9' */
    if (set_UART_VCflagLissajousDataUartUARTRx9_Receive(&UART3_Temp_Buffer[0],
         URX3_BUFFER_SIZE)) {          /* Non-Blocking */
      uart_xy_wiggler_B.UARTRx9_o2 =
        set_UART_VCflagLissajousDataUartUARTRx9_data0;/* D0 */
      uart_xy_wiggler_B.UARTRx9_o1 = 1;/* READY */
    } else {
      uart_xy_wiggler_B.UARTRx9_o1 = 0;/* Not READY */
    }
  }

  /* End of RateTransition: '<S53>/Rate Transition17' */

  /* DataTypeConversion: '<S53>/Data Type Conversion9' incorporates:
   *  Delay: '<S53>/Wait for Buffer to clear10'
   */
  uart_xy_wiggler_B.DataTypeConversion9_n =
    uart_xy_wiggler_DWork.WaitforBuffertoclear10_DSTATE_p[0];

  /* Outputs for Enabled SubSystem: '<S53>/Set UART vc Flag=10' incorporates:
   *  EnablePort: '<S72>/Enable'
   */
  /* Delay: '<S53>/Wait for Buffer to clear 9' */
  if (uart_xy_wiggler_DWork.WaitforBuffertoclear9_DSTATE_a[0U] > 0) {
    if (!uart_xy_wiggler_DWork.SetUARTvcFlag10_MODE) {
      uart_xy_wiggler_DWork.SetUARTvcFlag10_MODE = true;
    }

    if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
      /* S-Function (waijung_vdata_write): '<S72>/Volatile Data Storage Write' */

      /* set_UART_VCflagLissajousDataUartSetUARTvcFlag10VolatileDataStorageWrite */
      LissajousDataVolatileDataStorage11_Ayc = (double)
        uart_xy_wiggler_B.DataTypeConversion9_n;
    }
  } else {
    if (uart_xy_wiggler_DWork.SetUARTvcFlag10_MODE) {
      uart_xy_wiggler_DWork.SetUARTvcFlag10_MODE = false;
    }
  }

  /* End of Delay: '<S53>/Wait for Buffer to clear 9' */
  /* End of Outputs for SubSystem: '<S53>/Set UART vc Flag=10' */

  /* RateTransition: '<S53>/Rate Transition19' */
  if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
    uart_xy_wiggler_B.RateTransition19_g =
      uart_xy_wiggler_DWork.RateTransition19_Buffer0_o;

    /* RateTransition: '<S53>/Rate Transition20' */
    uart_xy_wiggler_B.RateTransition20_o =
      uart_xy_wiggler_DWork.RateTransition20_Buffer0_e;

    /* S-Function (stm32f4_usart): '<S53>/UART Rx10' */

    /* set_UART_VCflagLissajousDataUartUARTRx10: '<S53>/UART Rx10' */
    if (set_UART_VCflagLissajousDataUartUARTRx10_Receive(&UART3_Temp_Buffer[0],
         URX3_BUFFER_SIZE)) {          /* Non-Blocking */
      uart_xy_wiggler_B.UARTRx10_o2_h =
        set_UART_VCflagLissajousDataUartUARTRx10_data0;/* D0 */
      uart_xy_wiggler_B.UARTRx10_o1_m = 1;/* READY */
    } else {
      uart_xy_wiggler_B.UARTRx10_o1_m = 0;/* Not READY */
    }
  }

  /* End of RateTransition: '<S53>/Rate Transition19' */
  /* Update for RateTransition: '<S8>/Rate Transition2' */
  if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
    /* Update for Delay: '<S5>/Delay2' */
    uart_xy_wiggler_DWork.Delay2_DSTATE = rtb_Switch2;

    /* Update for Delay: '<S6>/Delay2' */
    uart_xy_wiggler_DWork.Delay2_DSTATE_c = rtb_Switch2_p;

    /* Update for UnitDelay: '<S13>/Unit Delay' */
    uart_xy_wiggler_DWork.UnitDelay_DSTATE = rtb_MathFunction_i;

    /* Update for UnitDelay: '<S12>/Unit Delay' */
    uart_xy_wiggler_DWork.UnitDelay_DSTATE_d = rtb_MathFunction_d;

    /* Update for UnitDelay: '<S25>/Unit Delay' */
    uart_xy_wiggler_DWork.UnitDelay_DSTATE_j = rtb_MathFunction_gp;

    /* Update for UnitDelay: '<S27>/Unit Delay' */
    uart_xy_wiggler_DWork.UnitDelay_DSTATE_g = rtb_MathFunction_gm;

    /* Update for UnitDelay: '<S24>/Unit Delay' */
    uart_xy_wiggler_DWork.UnitDelay_DSTATE_i = rtb_MathFunction_g;

    /* Update for UnitDelay: '<S26>/Unit Delay' */
    uart_xy_wiggler_DWork.UnitDelay_DSTATE_jm = rtb_MathFunction_a;

    /* Update for UnitDelay: '<S79>/Unit Delay' */
    uart_xy_wiggler_DWork.UnitDelay_DSTATE_do = rtb_MathFunction;
    uart_xy_wiggler_DWork.RateTransition2_Buffer0 = uart_xy_wiggler_B.UARTRx_o1;

    /* Update for RateTransition: '<S8>/Rate Transition4' */
    uart_xy_wiggler_DWork.RateTransition4_Buffer0 = uart_xy_wiggler_B.UARTRx_o2;
  }

  /* End of Update for RateTransition: '<S8>/Rate Transition2' */

  /* Update for Delay: '<S8>/Wait for Buffer to clear1' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear1_DSTATE[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear1_DSTATE[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear1_DSTATE[1] =
    uart_xy_wiggler_B.RateTransition4;

  /* Update for Delay: '<S8>/Wait for Buffer to clear ' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear_DSTATE[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear_DSTATE[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear_DSTATE[1] =
    uart_xy_wiggler_B.RateTransition2;

  /* Update for Delay: '<S8>/Wait for Buffer to clear3' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear3_DSTATE[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear3_DSTATE[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear3_DSTATE[1] =
    uart_xy_wiggler_B.RateTransition3;

  /* Update for Delay: '<S8>/Wait for Buffer to clear 1' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear1_DSTATE_l[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear1_DSTATE_l[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear1_DSTATE_l[1] =
    uart_xy_wiggler_B.RateTransition1_b;

  /* Update for RateTransition: '<S8>/Rate Transition1' incorporates:
   *  RateTransition: '<S8>/Rate Transition7'
   */
  if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
    uart_xy_wiggler_DWork.RateTransition1_Buffer0_o =
      uart_xy_wiggler_B.UARTRx1_o1;

    /* Update for RateTransition: '<S8>/Rate Transition3' */
    uart_xy_wiggler_DWork.RateTransition3_Buffer0 = uart_xy_wiggler_B.UARTRx1_o2;
    uart_xy_wiggler_DWork.RateTransition7_Buffer0_l =
      uart_xy_wiggler_B.UARTRx4_o1;

    /* Update for RateTransition: '<S8>/Rate Transition8' */
    uart_xy_wiggler_DWork.RateTransition8_Buffer0 = uart_xy_wiggler_B.UARTRx4_o2;
  }

  /* End of Update for RateTransition: '<S8>/Rate Transition1' */

  /* Update for Delay: '<S8>/Wait for Buffer to clear4' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear4_DSTATE[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear4_DSTATE[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear4_DSTATE[1] =
    uart_xy_wiggler_B.RateTransition8;

  /* Update for Delay: '<S8>/Wait for Buffer to clear 3' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear3_DSTATE_j[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear3_DSTATE_j[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear3_DSTATE_j[1] =
    uart_xy_wiggler_B.RateTransition7_f;

  /* Update for Delay: '<S8>/Wait for Buffer to clear5' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear5_DSTATE[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear5_DSTATE[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear5_DSTATE[1] =
    uart_xy_wiggler_B.RateTransition10;

  /* Update for Delay: '<S8>/Wait for Buffer to clear 4' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear4_DSTATE_b[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear4_DSTATE_b[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear4_DSTATE_b[1] =
    uart_xy_wiggler_B.RateTransition9;

  /* Update for RateTransition: '<S8>/Rate Transition10' incorporates:
   *  RateTransition: '<S8>/Rate Transition11'
   */
  if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
    uart_xy_wiggler_DWork.RateTransition10_Buffer0 =
      uart_xy_wiggler_B.UARTRx5_o2;

    /* Update for RateTransition: '<S8>/Rate Transition9' */
    uart_xy_wiggler_DWork.RateTransition9_Buffer0 = uart_xy_wiggler_B.UARTRx5_o1;
    uart_xy_wiggler_DWork.RateTransition11_Buffer0 =
      uart_xy_wiggler_B.UARTRx6_o2;

    /* Update for RateTransition: '<S8>/Rate Transition12' */
    uart_xy_wiggler_DWork.RateTransition12_Buffer0 =
      uart_xy_wiggler_B.UARTRx6_o1;
  }

  /* End of Update for RateTransition: '<S8>/Rate Transition10' */

  /* Update for Delay: '<S8>/Wait for Buffer to clear6' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear6_DSTATE[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear6_DSTATE[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear6_DSTATE[1] =
    uart_xy_wiggler_B.RateTransition11;

  /* Update for Delay: '<S8>/Wait for Buffer to clear 5' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear5_DSTATE_p[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear5_DSTATE_p[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear5_DSTATE_p[1] =
    uart_xy_wiggler_B.RateTransition12;

  /* Update for Delay: '<S8>/Wait for Buffer to clear2' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear2_DSTATE[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear2_DSTATE[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear2_DSTATE[1] =
    uart_xy_wiggler_B.RateTransition6;

  /* Update for Delay: '<S8>/Wait for Buffer to clear 2' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear2_DSTATE_l[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear2_DSTATE_l[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear2_DSTATE_l[1] =
    uart_xy_wiggler_B.RateTransition5_n;

  /* Update for RateTransition: '<S8>/Rate Transition5' incorporates:
   *  RateTransition: '<S52>/Rate Transition1'
   */
  if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
    uart_xy_wiggler_DWork.RateTransition5_Buffer0_m =
      uart_xy_wiggler_B.UARTRx2_o1;

    /* Update for RateTransition: '<S8>/Rate Transition6' */
    uart_xy_wiggler_DWork.RateTransition6_Buffer0 = uart_xy_wiggler_B.UARTRx2_o2;
    uart_xy_wiggler_DWork.RateTransition1_Buffer0 =
      uart_xy_wiggler_B.UARTRx1_o2_p;

    /* Update for RateTransition: '<S52>/Rate Transition2' */
    uart_xy_wiggler_DWork.RateTransition2_Buffer0_h =
      uart_xy_wiggler_B.UARTRx1_o1_p;
  }

  /* End of Update for RateTransition: '<S8>/Rate Transition5' */

  /* Update for Delay: '<S52>/Wait for Buffer to clear1' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear1_DSTATE_p[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear1_DSTATE_p[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear1_DSTATE_p[1] =
    uart_xy_wiggler_B.RateTransition1;

  /* Update for Delay: '<S52>/Wait for Buffer to clear 1' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear1_DSTATE_d[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear1_DSTATE_d[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear1_DSTATE_d[1] =
    uart_xy_wiggler_B.RateTransition2_g;

  /* Update for Delay: '<S52>/Wait for Buffer to clear11' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear11_DSTATE[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear11_DSTATE[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear11_DSTATE[1] =
    uart_xy_wiggler_B.RateTransition21;

  /* Update for Delay: '<S52>/Wait for Buffer to clear 10' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear10_DSTATE_n[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear10_DSTATE_n[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear10_DSTATE_n[1] =
    uart_xy_wiggler_B.RateTransition22;

  /* Update for RateTransition: '<S52>/Rate Transition21' incorporates:
   *  RateTransition: '<S52>/Rate Transition3'
   */
  if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
    uart_xy_wiggler_DWork.RateTransition21_Buffer0 =
      uart_xy_wiggler_B.UARTRx11_o2;

    /* Update for RateTransition: '<S52>/Rate Transition22' */
    uart_xy_wiggler_DWork.RateTransition22_Buffer0 =
      uart_xy_wiggler_B.UARTRx11_o1;
    uart_xy_wiggler_DWork.RateTransition3_Buffer0_o =
      uart_xy_wiggler_B.UARTRx2_o2_i;

    /* Update for RateTransition: '<S52>/Rate Transition4' */
    uart_xy_wiggler_DWork.RateTransition4_Buffer0_k =
      uart_xy_wiggler_B.UARTRx2_o1_p;
  }

  /* End of Update for RateTransition: '<S52>/Rate Transition21' */

  /* Update for Delay: '<S52>/Wait for Buffer to clear2' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear2_DSTATE_b[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear2_DSTATE_b[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear2_DSTATE_b[1] =
    uart_xy_wiggler_B.RateTransition3_p;

  /* Update for Delay: '<S52>/Wait for Buffer to clear 2' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear2_DSTATE_d[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear2_DSTATE_d[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear2_DSTATE_d[1] =
    uart_xy_wiggler_B.RateTransition4_e;

  /* Update for Delay: '<S52>/Wait for Buffer to clear3' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear3_DSTATE_n[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear3_DSTATE_n[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear3_DSTATE_n[1] =
    uart_xy_wiggler_B.RateTransition5;

  /* Update for Delay: '<S52>/Wait for Buffer to clear 3' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear3_DSTATE_c[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear3_DSTATE_c[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear3_DSTATE_c[1] =
    uart_xy_wiggler_B.RateTransition6_d;

  /* Update for RateTransition: '<S52>/Rate Transition5' incorporates:
   *  RateTransition: '<S52>/Rate Transition7'
   */
  if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
    uart_xy_wiggler_DWork.RateTransition5_Buffer0 =
      uart_xy_wiggler_B.UARTRx3_o2_g;

    /* Update for RateTransition: '<S52>/Rate Transition6' */
    uart_xy_wiggler_DWork.RateTransition6_Buffer0_c =
      uart_xy_wiggler_B.UARTRx3_o1_d;
    uart_xy_wiggler_DWork.RateTransition7_Buffer0 =
      uart_xy_wiggler_B.UARTRx4_o2_o;

    /* Update for RateTransition: '<S52>/Rate Transition9' */
    uart_xy_wiggler_DWork.RateTransition9_Buffer0_c =
      uart_xy_wiggler_B.UARTRx4_o1_f;
  }

  /* End of Update for RateTransition: '<S52>/Rate Transition5' */

  /* Update for Delay: '<S52>/Wait for Buffer to clear4' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear4_DSTATE_p[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear4_DSTATE_p[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear4_DSTATE_p[1] =
    uart_xy_wiggler_B.RateTransition7;

  /* Update for Delay: '<S52>/Wait for Buffer to clear 4' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear4_DSTATE_c[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear4_DSTATE_c[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear4_DSTATE_c[1] =
    uart_xy_wiggler_B.RateTransition9_c;

  /* Update for Delay: '<S52>/Wait for Buffer to clear6' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear6_DSTATE_b[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear6_DSTATE_b[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear6_DSTATE_b[1] =
    uart_xy_wiggler_B.RateTransition11_n;

  /* Update for Delay: '<S52>/Wait for Buffer to clear 5' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear5_DSTATE_c[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear5_DSTATE_c[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear5_DSTATE_c[1] =
    uart_xy_wiggler_B.RateTransition12_h;

  /* Update for RateTransition: '<S52>/Rate Transition11' incorporates:
   *  RateTransition: '<S52>/Rate Transition13'
   */
  if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
    uart_xy_wiggler_DWork.RateTransition11_Buffer0_d =
      uart_xy_wiggler_B.UARTRx6_o2_h;

    /* Update for RateTransition: '<S52>/Rate Transition12' */
    uart_xy_wiggler_DWork.RateTransition12_Buffer0_i =
      uart_xy_wiggler_B.UARTRx6_o1_i;
    uart_xy_wiggler_DWork.RateTransition13_Buffer0 =
      uart_xy_wiggler_B.UARTRx7_o2;

    /* Update for RateTransition: '<S52>/Rate Transition14' */
    uart_xy_wiggler_DWork.RateTransition14_Buffer0 =
      uart_xy_wiggler_B.UARTRx7_o1;
  }

  /* End of Update for RateTransition: '<S52>/Rate Transition11' */

  /* Update for Delay: '<S52>/Wait for Buffer to clear7' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear7_DSTATE[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear7_DSTATE[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear7_DSTATE[1] =
    uart_xy_wiggler_B.RateTransition13;

  /* Update for Delay: '<S52>/Wait for Buffer to clear 6' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear6_DSTATE_br[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear6_DSTATE_br[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear6_DSTATE_br[1] =
    uart_xy_wiggler_B.RateTransition14;

  /* Update for Delay: '<S52>/Wait for Buffer to clear8' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear8_DSTATE[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear8_DSTATE[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear8_DSTATE[1] =
    uart_xy_wiggler_B.RateTransition15;

  /* Update for Delay: '<S52>/Wait for Buffer to clear 7' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear7_DSTATE_a[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear7_DSTATE_a[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear7_DSTATE_a[1] =
    uart_xy_wiggler_B.RateTransition16;

  /* Update for RateTransition: '<S52>/Rate Transition15' incorporates:
   *  RateTransition: '<S52>/Rate Transition10'
   */
  if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
    uart_xy_wiggler_DWork.RateTransition15_Buffer0 =
      uart_xy_wiggler_B.UARTRx8_o2;

    /* Update for RateTransition: '<S52>/Rate Transition16' */
    uart_xy_wiggler_DWork.RateTransition16_Buffer0 =
      uart_xy_wiggler_B.UARTRx8_o1;
    uart_xy_wiggler_DWork.RateTransition10_Buffer0_g =
      uart_xy_wiggler_B.UARTRx5_o1_p;

    /* Update for RateTransition: '<S52>/Rate Transition8' */
    uart_xy_wiggler_DWork.RateTransition8_Buffer0_o =
      uart_xy_wiggler_B.UARTRx5_o2_h;
  }

  /* End of Update for RateTransition: '<S52>/Rate Transition15' */

  /* Update for Delay: '<S52>/Wait for Buffer to clear5' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear5_DSTATE_l[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear5_DSTATE_l[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear5_DSTATE_l[1] =
    uart_xy_wiggler_B.RateTransition8_c;

  /* Update for Delay: '<S52>/Wait for Buffer to clear 8' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear8_DSTATE_d[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear8_DSTATE_d[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear8_DSTATE_d[1] =
    uart_xy_wiggler_B.RateTransition10_e;

  /* Update for Delay: '<S52>/Wait for Buffer to clear10' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear10_DSTATE[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear10_DSTATE[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear10_DSTATE[1] =
    uart_xy_wiggler_B.RateTransition19;

  /* Update for Delay: '<S52>/Wait for Buffer to clear 9' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear9_DSTATE_i[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear9_DSTATE_i[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear9_DSTATE_i[1] =
    uart_xy_wiggler_B.RateTransition20;

  /* Update for RateTransition: '<S52>/Rate Transition19' incorporates:
   *  RateTransition: '<S53>/Rate Transition1'
   */
  if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
    uart_xy_wiggler_DWork.RateTransition19_Buffer0 =
      uart_xy_wiggler_B.UARTRx10_o2;

    /* Update for RateTransition: '<S52>/Rate Transition20' */
    uart_xy_wiggler_DWork.RateTransition20_Buffer0 =
      uart_xy_wiggler_B.UARTRx10_o1;
    uart_xy_wiggler_DWork.RateTransition1_Buffer0_i =
      uart_xy_wiggler_B.UARTRx1_o2_i;

    /* Update for RateTransition: '<S53>/Rate Transition2' */
    uart_xy_wiggler_DWork.RateTransition2_Buffer0_g =
      uart_xy_wiggler_B.UARTRx1_o1_f;
  }

  /* End of Update for RateTransition: '<S52>/Rate Transition19' */

  /* Update for Delay: '<S53>/Wait for Buffer to clear1' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear1_DSTATE_c[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear1_DSTATE_c[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear1_DSTATE_c[1] =
    uart_xy_wiggler_B.RateTransition1_l;

  /* Update for Delay: '<S53>/Wait for Buffer to clear 1' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear1_DSTATE_n[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear1_DSTATE_n[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear1_DSTATE_n[1] =
    uart_xy_wiggler_B.RateTransition2_o;

  /* Update for Delay: '<S53>/Wait for Buffer to clear11' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear11_DSTATE_g[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear11_DSTATE_g[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear11_DSTATE_g[1] =
    uart_xy_wiggler_B.RateTransition21_c;

  /* Update for Delay: '<S53>/Wait for Buffer to clear 10' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear10_DSTAT_nb[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear10_DSTAT_nb[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear10_DSTAT_nb[1] =
    uart_xy_wiggler_B.RateTransition22_n;

  /* Update for RateTransition: '<S53>/Rate Transition21' incorporates:
   *  RateTransition: '<S53>/Rate Transition13'
   */
  if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
    uart_xy_wiggler_DWork.RateTransition21_Buffer0_p =
      uart_xy_wiggler_B.UARTRx11_o2_a;

    /* Update for RateTransition: '<S53>/Rate Transition22' */
    uart_xy_wiggler_DWork.RateTransition22_Buffer0_j =
      uart_xy_wiggler_B.UARTRx11_o1_c;
    uart_xy_wiggler_DWork.RateTransition13_Buffer0_e =
      uart_xy_wiggler_B.UARTRx7_o2_k;

    /* Update for RateTransition: '<S53>/Rate Transition14' */
    uart_xy_wiggler_DWork.RateTransition14_Buffer0_a =
      uart_xy_wiggler_B.UARTRx7_o1_e;
  }

  /* End of Update for RateTransition: '<S53>/Rate Transition21' */

  /* Update for Delay: '<S53>/Wait for Buffer to clear7' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear7_DSTATE_f[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear7_DSTATE_f[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear7_DSTATE_f[1] =
    uart_xy_wiggler_B.RateTransition13_f;

  /* Update for Delay: '<S53>/Wait for Buffer to clear 6' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear6_DSTATE_j[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear6_DSTATE_j[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear6_DSTATE_j[1] =
    uart_xy_wiggler_B.RateTransition14_h;

  /* Update for Delay: '<S53>/Wait for Buffer to clear8' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear8_DSTATE_e[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear8_DSTATE_e[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear8_DSTATE_e[1] =
    uart_xy_wiggler_B.RateTransition15_e;

  /* Update for Delay: '<S53>/Wait for Buffer to clear 7' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear7_DSTATE_d[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear7_DSTATE_d[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear7_DSTATE_d[1] =
    uart_xy_wiggler_B.RateTransition16_o;

  /* Update for RateTransition: '<S53>/Rate Transition15' incorporates:
   *  RateTransition: '<S53>/Rate Transition17'
   */
  if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
    uart_xy_wiggler_DWork.RateTransition15_Buffer0_l =
      uart_xy_wiggler_B.UARTRx8_o2_g;

    /* Update for RateTransition: '<S53>/Rate Transition16' */
    uart_xy_wiggler_DWork.RateTransition16_Buffer0_p =
      uart_xy_wiggler_B.UARTRx8_o1_c;
    uart_xy_wiggler_DWork.RateTransition17_Buffer0 =
      uart_xy_wiggler_B.UARTRx9_o2;

    /* Update for RateTransition: '<S53>/Rate Transition18' */
    uart_xy_wiggler_DWork.RateTransition18_Buffer0 =
      uart_xy_wiggler_B.UARTRx9_o1;
  }

  /* End of Update for RateTransition: '<S53>/Rate Transition15' */

  /* Update for Delay: '<S53>/Wait for Buffer to clear9' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear9_DSTATE[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear9_DSTATE[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear9_DSTATE[1] =
    uart_xy_wiggler_B.RateTransition17;

  /* Update for Delay: '<S53>/Wait for Buffer to clear 8' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear8_DSTATE_j[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear8_DSTATE_j[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear8_DSTATE_j[1] =
    uart_xy_wiggler_B.RateTransition18;

  /* Update for Delay: '<S53>/Wait for Buffer to clear10' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear10_DSTATE_p[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear10_DSTATE_p[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear10_DSTATE_p[1] =
    uart_xy_wiggler_B.RateTransition19_g;

  /* Update for Delay: '<S53>/Wait for Buffer to clear 9' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear9_DSTATE_a[0] =
    uart_xy_wiggler_DWork.WaitforBuffertoclear9_DSTATE_a[1];
  uart_xy_wiggler_DWork.WaitforBuffertoclear9_DSTATE_a[1] =
    uart_xy_wiggler_B.RateTransition20_o;

  /* Update for RateTransition: '<S53>/Rate Transition19' */
  if (uart_xy_wiggler_M->Timing.TaskCounters.TID[1] == 0) {
    uart_xy_wiggler_DWork.RateTransition19_Buffer0_o =
      uart_xy_wiggler_B.UARTRx10_o2_h;

    /* Update for RateTransition: '<S53>/Rate Transition20' */
    uart_xy_wiggler_DWork.RateTransition20_Buffer0_e =
      uart_xy_wiggler_B.UARTRx10_o1_m;
  }

  /* End of Update for RateTransition: '<S53>/Rate Transition19' */
  rate_scheduler();
}

/* Model initialize function */
void uart_xy_wiggler_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)uart_xy_wiggler_M, 0,
                sizeof(RT_MODEL_uart_xy_wiggler));

  /* block I/O */
  (void) memset(((void *) &uart_xy_wiggler_B), 0,
                sizeof(BlockIO_uart_xy_wiggler));

  /* states (dwork) */
  (void) memset((void *)&uart_xy_wiggler_DWork, 0,
                sizeof(D_Work_uart_xy_wiggler));
  uart_xy_wig_MedianFilter1_Start(&uart_xy_wiggler_DWork.MedianFilter);

  /* Start for MATLABSystem: '<Root>/Median Filter1' */
  uart_xy_wig_MedianFilter1_Start(&uart_xy_wiggler_DWork.MedianFilter1);

  /* Start for S-Function (waijung_vdata_storage): '<S1>/Volatile Data Storage1' */

  /* S-Function Block: <S1>/Volatile Data Storage1 */
  CalibrationDataVolatileDataStorage1_ab3 = -4.75;

  /* Start for S-Function (waijung_vdata_storage): '<S1>/Volatile Data Storage11' */

  /* S-Function Block: <S1>/Volatile Data Storage11 */
  CalibrationDataVolatileDataStorage11_ab1 = 0.75;

  /* Start for S-Function (waijung_vdata_storage): '<S1>/Volatile Data Storage12' */

  /* S-Function Block: <S1>/Volatile Data Storage12 */
  CalibrationDataVolatileDataStorage12_ab2 = 36.75;

  /* Start for S-Function (waijung_vdata_storage): '<S1>/Volatile Data Storage2' */

  /* S-Function Block: <S1>/Volatile Data Storage2 */
  CalibrationDataVolatileDataStorage2_ab4 = 5.0;

  /* Start for S-Function (waijung_vdata_storage): '<S1>/Volatile Data Storage3' */

  /* S-Function Block: <S1>/Volatile Data Storage3 */
  CalibrationDataVolatileDataStorage3_ab5 = 0.25;

  /* Start for S-Function (waijung_vdata_storage): '<S1>/Volatile Data Storage4' */

  /* S-Function Block: <S1>/Volatile Data Storage4 */
  CalibrationDataVolatileDataStorage4_ab6 = 43.75;

  /* Start for S-Function (waijung_vdata_storage): '<S1>/Volatile Data Storage5' */

  /* S-Function Block: <S1>/Volatile Data Storage5 */
  CalibrationDataVolatileDataStorage5_ab7 = 7.75;

  /* Start for S-Function (waijung_vdata_storage): '<S1>/Volatile Data Storage6' */

  /* S-Function Block: <S1>/Volatile Data Storage6 */
  CalibrationDataVolatileDataStorage6_ab8 = -1.75;

  /* Start for S-Function (waijung_vdata_storage): '<S1>/Volatile Data Storage7' */

  /* S-Function Block: <S1>/Volatile Data Storage7 */
  CalibrationDataVolatileDataStorage7_ab9 = 1.5;

  /* Start for S-Function (waijung_vdata_storage): '<S1>/Volatile Data Storage8' */

  /* S-Function Block: <S1>/Volatile Data Storage8 */
  CalibrationDataVolatileDataStorage8_ab10 = 2.75;

  /* Start for S-Function (waijung_vdata_storage): '<S4>/Volatile Data Storage10' */

  /* S-Function Block: <S4>/Volatile Data Storage10 */
  LissajousDataVolatileDataStorage10_Ays = 1.0;

  /* Start for S-Function (waijung_vdata_storage): '<S4>/Volatile Data Storage11' */

  /* S-Function Block: <S4>/Volatile Data Storage11 */
  LissajousDataVolatileDataStorage11_Ayc = 1.0;

  /* Start for S-Function (waijung_vdata_storage): '<S4>/Volatile Data Storage12' */

  /* S-Function Block: <S4>/Volatile Data Storage12 */
  LissajousDataVolatileDataStorage12_Axs = 1.0;

  /* Start for S-Function (waijung_vdata_storage): '<S4>/Volatile Data Storage7' */

  /* S-Function Block: <S4>/Volatile Data Storage7 */
  LissajousDataVolatileDataStorage7_A_Laser = 0.1;

  /* Start for S-Function (waijung_vdata_storage): '<S4>/Volatile Data Storage8' */

  /* S-Function Block: <S4>/Volatile Data Storage8 */
  LissajousDataVolatileDataStorage8_LissaFreq = 0.1;

  /* Start for S-Function (waijung_vdata_storage): '<S4>/Volatile Data Storage9' */

  /* S-Function Block: <S4>/Volatile Data Storage9 */
  LissajousDataVolatileDataStorage9_Axc = 1.0;

  /* Start for RateTransition: '<S8>/Rate Transition2' */
  uart_xy_wiggler_B.RateTransition2 =
    uart_xy_wiggler_P.RateTransition2_InitialConditio;

  /* Start for RateTransition: '<S8>/Rate Transition4' */
  uart_xy_wiggler_B.RateTransition4 =
    uart_xy_wiggler_P.RateTransition4_InitialConditio;

  /* Start for RateTransition: '<S8>/Rate Transition1' */
  uart_xy_wiggler_B.RateTransition1_b =
    uart_xy_wiggler_P.RateTransition1_InitialCondit_g;

  /* Start for RateTransition: '<S8>/Rate Transition3' */
  uart_xy_wiggler_B.RateTransition3 =
    uart_xy_wiggler_P.RateTransition3_InitialConditio;

  /* Start for RateTransition: '<S8>/Rate Transition7' */
  uart_xy_wiggler_B.RateTransition7_f =
    uart_xy_wiggler_P.RateTransition7_InitialCondit_j;

  /* Start for RateTransition: '<S8>/Rate Transition8' */
  uart_xy_wiggler_B.RateTransition8 =
    uart_xy_wiggler_P.RateTransition8_InitialConditio;

  /* Start for RateTransition: '<S8>/Rate Transition10' */
  uart_xy_wiggler_B.RateTransition10 =
    uart_xy_wiggler_P.RateTransition10_InitialConditi;

  /* Start for RateTransition: '<S8>/Rate Transition9' */
  uart_xy_wiggler_B.RateTransition9 =
    uart_xy_wiggler_P.RateTransition9_InitialConditio;

  /* Start for RateTransition: '<S8>/Rate Transition11' */
  uart_xy_wiggler_B.RateTransition11 =
    uart_xy_wiggler_P.RateTransition11_InitialConditi;

  /* Start for RateTransition: '<S8>/Rate Transition12' */
  uart_xy_wiggler_B.RateTransition12 =
    uart_xy_wiggler_P.RateTransition12_InitialConditi;

  /* Start for RateTransition: '<S8>/Rate Transition5' */
  uart_xy_wiggler_B.RateTransition5_n =
    uart_xy_wiggler_P.RateTransition5_InitialCondit_e;

  /* Start for RateTransition: '<S8>/Rate Transition6' */
  uart_xy_wiggler_B.RateTransition6 =
    uart_xy_wiggler_P.RateTransition6_InitialConditio;

  /* Start for RateTransition: '<S52>/Rate Transition1' */
  uart_xy_wiggler_B.RateTransition1 =
    uart_xy_wiggler_P.RateTransition1_InitialConditio;

  /* Start for RateTransition: '<S52>/Rate Transition2' */
  uart_xy_wiggler_B.RateTransition2_g =
    uart_xy_wiggler_P.RateTransition2_InitialCondit_i;

  /* Start for RateTransition: '<S52>/Rate Transition21' */
  uart_xy_wiggler_B.RateTransition21 =
    uart_xy_wiggler_P.RateTransition21_InitialConditi;

  /* Start for RateTransition: '<S52>/Rate Transition22' */
  uart_xy_wiggler_B.RateTransition22 =
    uart_xy_wiggler_P.RateTransition22_InitialConditi;

  /* Start for RateTransition: '<S52>/Rate Transition3' */
  uart_xy_wiggler_B.RateTransition3_p =
    uart_xy_wiggler_P.RateTransition3_InitialCondit_a;

  /* Start for RateTransition: '<S52>/Rate Transition4' */
  uart_xy_wiggler_B.RateTransition4_e =
    uart_xy_wiggler_P.RateTransition4_InitialCondit_e;

  /* Start for RateTransition: '<S52>/Rate Transition5' */
  uart_xy_wiggler_B.RateTransition5 =
    uart_xy_wiggler_P.RateTransition5_InitialConditio;

  /* Start for RateTransition: '<S52>/Rate Transition6' */
  uart_xy_wiggler_B.RateTransition6_d =
    uart_xy_wiggler_P.RateTransition6_InitialCondit_b;

  /* Start for RateTransition: '<S52>/Rate Transition7' */
  uart_xy_wiggler_B.RateTransition7 =
    uart_xy_wiggler_P.RateTransition7_InitialConditio;

  /* Start for RateTransition: '<S52>/Rate Transition9' */
  uart_xy_wiggler_B.RateTransition9_c =
    uart_xy_wiggler_P.RateTransition9_InitialCondit_c;

  /* Start for RateTransition: '<S52>/Rate Transition11' */
  uart_xy_wiggler_B.RateTransition11_n =
    uart_xy_wiggler_P.RateTransition11_InitialCondi_l;

  /* Start for RateTransition: '<S52>/Rate Transition12' */
  uart_xy_wiggler_B.RateTransition12_h =
    uart_xy_wiggler_P.RateTransition12_InitialCondi_e;

  /* Start for RateTransition: '<S52>/Rate Transition13' */
  uart_xy_wiggler_B.RateTransition13 =
    uart_xy_wiggler_P.RateTransition13_InitialConditi;

  /* Start for RateTransition: '<S52>/Rate Transition14' */
  uart_xy_wiggler_B.RateTransition14 =
    uart_xy_wiggler_P.RateTransition14_InitialConditi;

  /* Start for RateTransition: '<S52>/Rate Transition15' */
  uart_xy_wiggler_B.RateTransition15 =
    uart_xy_wiggler_P.RateTransition15_InitialConditi;

  /* Start for RateTransition: '<S52>/Rate Transition16' */
  uart_xy_wiggler_B.RateTransition16 =
    uart_xy_wiggler_P.RateTransition16_InitialConditi;

  /* Start for RateTransition: '<S52>/Rate Transition10' */
  uart_xy_wiggler_B.RateTransition10_e =
    uart_xy_wiggler_P.RateTransition10_InitialCondi_d;

  /* Start for RateTransition: '<S52>/Rate Transition8' */
  uart_xy_wiggler_B.RateTransition8_c =
    uart_xy_wiggler_P.RateTransition8_InitialCondit_i;

  /* Start for RateTransition: '<S52>/Rate Transition19' */
  uart_xy_wiggler_B.RateTransition19 =
    uart_xy_wiggler_P.RateTransition19_InitialConditi;

  /* Start for RateTransition: '<S52>/Rate Transition20' */
  uart_xy_wiggler_B.RateTransition20 =
    uart_xy_wiggler_P.RateTransition20_InitialConditi;

  /* Start for RateTransition: '<S53>/Rate Transition1' */
  uart_xy_wiggler_B.RateTransition1_l =
    uart_xy_wiggler_P.RateTransition1_InitialCondit_n;

  /* Start for RateTransition: '<S53>/Rate Transition2' */
  uart_xy_wiggler_B.RateTransition2_o =
    uart_xy_wiggler_P.RateTransition2_InitialCondit_e;

  /* Start for RateTransition: '<S53>/Rate Transition21' */
  uart_xy_wiggler_B.RateTransition21_c =
    uart_xy_wiggler_P.RateTransition21_InitialCondi_e;

  /* Start for RateTransition: '<S53>/Rate Transition22' */
  uart_xy_wiggler_B.RateTransition22_n =
    uart_xy_wiggler_P.RateTransition22_InitialCondi_h;

  /* Start for RateTransition: '<S53>/Rate Transition13' */
  uart_xy_wiggler_B.RateTransition13_f =
    uart_xy_wiggler_P.RateTransition13_InitialCondi_a;

  /* Start for RateTransition: '<S53>/Rate Transition14' */
  uart_xy_wiggler_B.RateTransition14_h =
    uart_xy_wiggler_P.RateTransition14_InitialCondi_e;

  /* Start for RateTransition: '<S53>/Rate Transition15' */
  uart_xy_wiggler_B.RateTransition15_e =
    uart_xy_wiggler_P.RateTransition15_InitialCondi_n;

  /* Start for RateTransition: '<S53>/Rate Transition16' */
  uart_xy_wiggler_B.RateTransition16_o =
    uart_xy_wiggler_P.RateTransition16_InitialCondi_b;

  /* Start for RateTransition: '<S53>/Rate Transition17' */
  uart_xy_wiggler_B.RateTransition17 =
    uart_xy_wiggler_P.RateTransition17_InitialConditi;

  /* Start for RateTransition: '<S53>/Rate Transition18' */
  uart_xy_wiggler_B.RateTransition18 =
    uart_xy_wiggler_P.RateTransition18_InitialConditi;

  /* Start for RateTransition: '<S53>/Rate Transition19' */
  uart_xy_wiggler_B.RateTransition19_g =
    uart_xy_wiggler_P.RateTransition19_InitialCondi_j;

  /* Start for RateTransition: '<S53>/Rate Transition20' */
  uart_xy_wiggler_B.RateTransition20_o =
    uart_xy_wiggler_P.RateTransition20_InitialCondi_j;

  /* Start for S-Function (waijung_vdata_storage): '<Root>/Volatile Data Storage1' */

  /* S-Function Block: <Root>/Volatile Data Storage1 */
  VolatileDataStorage1_Laser = 90.0;

  /* Start for S-Function (waijung_vdata_storage): '<Root>/Volatile Data Storage2' */

  /* S-Function Block: <Root>/Volatile Data Storage2 */
  VolatileDataStorage2_vcx = 0.0;

  /* Start for S-Function (waijung_vdata_storage): '<Root>/Volatile Data Storage3' */

  /* S-Function Block: <Root>/Volatile Data Storage3 */
  VolatileDataStorage3_flag = 0.0;

  /* Start for S-Function (waijung_vdata_storage): '<Root>/Volatile Data Storage4' */

  /* S-Function Block: <Root>/Volatile Data Storage4 */
  VolatileDataStorage4_CircleFlag = 0.0;

  /* Start for S-Function (waijung_vdata_storage): '<Root>/Volatile Data Storage5' */

  /* S-Function Block: <Root>/Volatile Data Storage5 */
  VolatileDataStorage5_CircleFrequency = 0.1;

  /* Start for S-Function (waijung_vdata_storage): '<Root>/Volatile Data Storage6' */

  /* S-Function Block: <Root>/Volatile Data Storage6 */
  VolatileDataStorage6_vcy = 0.0;

  /* Start for S-Function (waijung_vdata_storage): '<Root>/Volatile Data Storage7' */

  /* S-Function Block: <Root>/Volatile Data Storage7 */
  VolatileDataStorage7_CircleR = 0.1;

  /* InitializeConditions for Delay: '<S5>/Delay2' */
  uart_xy_wiggler_DWork.Delay2_DSTATE =
    uart_xy_wiggler_P.Delay2_InitialCondition;

  /* InitializeConditions for Delay: '<S6>/Delay2' */
  uart_xy_wiggler_DWork.Delay2_DSTATE_c =
    uart_xy_wiggler_P.Delay2_InitialCondition_h;

  /* InitializeConditions for UnitDelay: '<S13>/Unit Delay' */
  uart_xy_wiggler_DWork.UnitDelay_DSTATE = uart_xy_wiggler_P.DiscreteTimeVCO1_Ph;

  /* InitializeConditions for UnitDelay: '<S12>/Unit Delay' */
  uart_xy_wiggler_DWork.UnitDelay_DSTATE_d =
    uart_xy_wiggler_P.DiscreteTimeVCO_Ph;

  /* InitializeConditions for UnitDelay: '<S25>/Unit Delay' */
  uart_xy_wiggler_DWork.UnitDelay_DSTATE_j = uart_xy_wiggler_P.Coswt_Ph;

  /* InitializeConditions for UnitDelay: '<S27>/Unit Delay' */
  uart_xy_wiggler_DWork.UnitDelay_DSTATE_g = uart_xy_wiggler_P.Sinwt_Ph;

  /* InitializeConditions for UnitDelay: '<S24>/Unit Delay' */
  uart_xy_wiggler_DWork.UnitDelay_DSTATE_i = uart_xy_wiggler_P.Cos5wt_Ph;

  /* InitializeConditions for UnitDelay: '<S26>/Unit Delay' */
  uart_xy_wiggler_DWork.UnitDelay_DSTATE_jm = uart_xy_wiggler_P.Sin5wt_Ph;

  /* InitializeConditions for DiscretePulseGenerator: '<Root>/recording_clock' */
  uart_xy_wiggler_DWork.clockTickCounter = 0;

  /* InitializeConditions for DiscretePulseGenerator: '<Root>/send_2_uart_clock' */
  uart_xy_wiggler_DWork.clockTickCounter_b = 0;

  /* InitializeConditions for S-Function (sdspstacknqueue): '<S7>/Queue' */

  /* DSP System Toolbox Queue (sdspstacknqueue) - '<S7>/Queue' */
  /* Initialize event port handler previous signal state: */
  uart_xy_wiggler_DWork.Queue_EPH0PrevState = EVENT_PORT_STATE_UNINIT;

  /* Initialize event port handler previous signal state: */
  uart_xy_wiggler_DWork.Queue_EPH1PrevState = EVENT_PORT_STATE_UNINIT;

  /* Initialize event port handler previous signal state: */
  uart_xy_wiggler_DWork.Queue_EPH2PrevState = EVENT_PORT_STATE_UNINIT;

  {
    uart_xy_wiggler_DWork.Queue_QueueFrontIdx =
      uart_xy_wiggler_DWork.Queue_QueueBackIdx =
      uart_xy_wiggler_DWork.Queue_NumElements = 0;
    memset(&uart_xy_wiggler_B.Queue_o1[0], 0, sizeof(real32_T)*4);/* Set output values to zero */
  }

  /* InitializeConditions for UnitDelay: '<S79>/Unit Delay' */
  uart_xy_wiggler_DWork.UnitDelay_DSTATE_do =
    uart_xy_wiggler_P.DiscreteTimeVCO_Ph_k;

  /* InitializeConditions for RateTransition: '<S8>/Rate Transition2' */
  uart_xy_wiggler_DWork.RateTransition2_Buffer0 =
    uart_xy_wiggler_P.RateTransition2_InitialConditio;

  /* InitializeConditions for RateTransition: '<S8>/Rate Transition4' */
  uart_xy_wiggler_DWork.RateTransition4_Buffer0 =
    uart_xy_wiggler_P.RateTransition4_InitialConditio;

  /* InitializeConditions for RateTransition: '<S8>/Rate Transition1' */
  uart_xy_wiggler_DWork.RateTransition1_Buffer0_o =
    uart_xy_wiggler_P.RateTransition1_InitialCondit_g;

  /* InitializeConditions for RateTransition: '<S8>/Rate Transition3' */
  uart_xy_wiggler_DWork.RateTransition3_Buffer0 =
    uart_xy_wiggler_P.RateTransition3_InitialConditio;

  /* InitializeConditions for RateTransition: '<S8>/Rate Transition7' */
  uart_xy_wiggler_DWork.RateTransition7_Buffer0_l =
    uart_xy_wiggler_P.RateTransition7_InitialCondit_j;

  /* InitializeConditions for RateTransition: '<S8>/Rate Transition8' */
  uart_xy_wiggler_DWork.RateTransition8_Buffer0 =
    uart_xy_wiggler_P.RateTransition8_InitialConditio;

  /* InitializeConditions for RateTransition: '<S8>/Rate Transition10' */
  uart_xy_wiggler_DWork.RateTransition10_Buffer0 =
    uart_xy_wiggler_P.RateTransition10_InitialConditi;

  /* InitializeConditions for RateTransition: '<S8>/Rate Transition9' */
  uart_xy_wiggler_DWork.RateTransition9_Buffer0 =
    uart_xy_wiggler_P.RateTransition9_InitialConditio;

  /* InitializeConditions for RateTransition: '<S8>/Rate Transition11' */
  uart_xy_wiggler_DWork.RateTransition11_Buffer0 =
    uart_xy_wiggler_P.RateTransition11_InitialConditi;

  /* InitializeConditions for RateTransition: '<S8>/Rate Transition12' */
  uart_xy_wiggler_DWork.RateTransition12_Buffer0 =
    uart_xy_wiggler_P.RateTransition12_InitialConditi;

  /* InitializeConditions for RateTransition: '<S8>/Rate Transition5' */
  uart_xy_wiggler_DWork.RateTransition5_Buffer0_m =
    uart_xy_wiggler_P.RateTransition5_InitialCondit_e;

  /* InitializeConditions for RateTransition: '<S8>/Rate Transition6' */
  uart_xy_wiggler_DWork.RateTransition6_Buffer0 =
    uart_xy_wiggler_P.RateTransition6_InitialConditio;

  /* InitializeConditions for RateTransition: '<S52>/Rate Transition1' */
  uart_xy_wiggler_DWork.RateTransition1_Buffer0 =
    uart_xy_wiggler_P.RateTransition1_InitialConditio;

  /* InitializeConditions for RateTransition: '<S52>/Rate Transition2' */
  uart_xy_wiggler_DWork.RateTransition2_Buffer0_h =
    uart_xy_wiggler_P.RateTransition2_InitialCondit_i;

  /* InitializeConditions for RateTransition: '<S52>/Rate Transition21' */
  uart_xy_wiggler_DWork.RateTransition21_Buffer0 =
    uart_xy_wiggler_P.RateTransition21_InitialConditi;

  /* InitializeConditions for RateTransition: '<S52>/Rate Transition22' */
  uart_xy_wiggler_DWork.RateTransition22_Buffer0 =
    uart_xy_wiggler_P.RateTransition22_InitialConditi;

  /* InitializeConditions for RateTransition: '<S52>/Rate Transition3' */
  uart_xy_wiggler_DWork.RateTransition3_Buffer0_o =
    uart_xy_wiggler_P.RateTransition3_InitialCondit_a;

  /* InitializeConditions for RateTransition: '<S52>/Rate Transition4' */
  uart_xy_wiggler_DWork.RateTransition4_Buffer0_k =
    uart_xy_wiggler_P.RateTransition4_InitialCondit_e;

  /* InitializeConditions for RateTransition: '<S52>/Rate Transition5' */
  uart_xy_wiggler_DWork.RateTransition5_Buffer0 =
    uart_xy_wiggler_P.RateTransition5_InitialConditio;

  /* InitializeConditions for RateTransition: '<S52>/Rate Transition6' */
  uart_xy_wiggler_DWork.RateTransition6_Buffer0_c =
    uart_xy_wiggler_P.RateTransition6_InitialCondit_b;

  /* InitializeConditions for RateTransition: '<S52>/Rate Transition7' */
  uart_xy_wiggler_DWork.RateTransition7_Buffer0 =
    uart_xy_wiggler_P.RateTransition7_InitialConditio;

  /* InitializeConditions for RateTransition: '<S52>/Rate Transition9' */
  uart_xy_wiggler_DWork.RateTransition9_Buffer0_c =
    uart_xy_wiggler_P.RateTransition9_InitialCondit_c;

  /* InitializeConditions for RateTransition: '<S52>/Rate Transition11' */
  uart_xy_wiggler_DWork.RateTransition11_Buffer0_d =
    uart_xy_wiggler_P.RateTransition11_InitialCondi_l;

  /* InitializeConditions for RateTransition: '<S52>/Rate Transition12' */
  uart_xy_wiggler_DWork.RateTransition12_Buffer0_i =
    uart_xy_wiggler_P.RateTransition12_InitialCondi_e;

  /* InitializeConditions for RateTransition: '<S52>/Rate Transition13' */
  uart_xy_wiggler_DWork.RateTransition13_Buffer0 =
    uart_xy_wiggler_P.RateTransition13_InitialConditi;

  /* InitializeConditions for RateTransition: '<S52>/Rate Transition14' */
  uart_xy_wiggler_DWork.RateTransition14_Buffer0 =
    uart_xy_wiggler_P.RateTransition14_InitialConditi;

  /* InitializeConditions for RateTransition: '<S52>/Rate Transition15' */
  uart_xy_wiggler_DWork.RateTransition15_Buffer0 =
    uart_xy_wiggler_P.RateTransition15_InitialConditi;

  /* InitializeConditions for RateTransition: '<S52>/Rate Transition16' */
  uart_xy_wiggler_DWork.RateTransition16_Buffer0 =
    uart_xy_wiggler_P.RateTransition16_InitialConditi;

  /* InitializeConditions for RateTransition: '<S52>/Rate Transition10' */
  uart_xy_wiggler_DWork.RateTransition10_Buffer0_g =
    uart_xy_wiggler_P.RateTransition10_InitialCondi_d;

  /* InitializeConditions for RateTransition: '<S52>/Rate Transition8' */
  uart_xy_wiggler_DWork.RateTransition8_Buffer0_o =
    uart_xy_wiggler_P.RateTransition8_InitialCondit_i;

  /* InitializeConditions for RateTransition: '<S52>/Rate Transition19' */
  uart_xy_wiggler_DWork.RateTransition19_Buffer0 =
    uart_xy_wiggler_P.RateTransition19_InitialConditi;

  /* InitializeConditions for RateTransition: '<S52>/Rate Transition20' */
  uart_xy_wiggler_DWork.RateTransition20_Buffer0 =
    uart_xy_wiggler_P.RateTransition20_InitialConditi;

  /* InitializeConditions for RateTransition: '<S53>/Rate Transition1' */
  uart_xy_wiggler_DWork.RateTransition1_Buffer0_i =
    uart_xy_wiggler_P.RateTransition1_InitialCondit_n;

  /* InitializeConditions for RateTransition: '<S53>/Rate Transition2' */
  uart_xy_wiggler_DWork.RateTransition2_Buffer0_g =
    uart_xy_wiggler_P.RateTransition2_InitialCondit_e;

  /* InitializeConditions for RateTransition: '<S53>/Rate Transition21' */
  uart_xy_wiggler_DWork.RateTransition21_Buffer0_p =
    uart_xy_wiggler_P.RateTransition21_InitialCondi_e;

  /* InitializeConditions for RateTransition: '<S53>/Rate Transition22' */
  uart_xy_wiggler_DWork.RateTransition22_Buffer0_j =
    uart_xy_wiggler_P.RateTransition22_InitialCondi_h;

  /* InitializeConditions for RateTransition: '<S53>/Rate Transition13' */
  uart_xy_wiggler_DWork.RateTransition13_Buffer0_e =
    uart_xy_wiggler_P.RateTransition13_InitialCondi_a;

  /* InitializeConditions for RateTransition: '<S53>/Rate Transition14' */
  uart_xy_wiggler_DWork.RateTransition14_Buffer0_a =
    uart_xy_wiggler_P.RateTransition14_InitialCondi_e;

  /* InitializeConditions for RateTransition: '<S53>/Rate Transition15' */
  uart_xy_wiggler_DWork.RateTransition15_Buffer0_l =
    uart_xy_wiggler_P.RateTransition15_InitialCondi_n;

  /* InitializeConditions for RateTransition: '<S53>/Rate Transition16' */
  uart_xy_wiggler_DWork.RateTransition16_Buffer0_p =
    uart_xy_wiggler_P.RateTransition16_InitialCondi_b;

  /* InitializeConditions for RateTransition: '<S53>/Rate Transition17' */
  uart_xy_wiggler_DWork.RateTransition17_Buffer0 =
    uart_xy_wiggler_P.RateTransition17_InitialConditi;

  /* InitializeConditions for RateTransition: '<S53>/Rate Transition18' */
  uart_xy_wiggler_DWork.RateTransition18_Buffer0 =
    uart_xy_wiggler_P.RateTransition18_InitialConditi;

  /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear1' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear1_DSTATE[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear1_InitialCo;

  /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear ' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear_DSTATE[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear_InitialCon;

  /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear3' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear3_DSTATE[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear3_InitialCo;

  /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear 1' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear1_DSTATE_l[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear1_Initial_n;

  /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear4' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear4_DSTATE[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear4_InitialCo;

  /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear 3' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear3_DSTATE_j[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear3_Initia_mg;

  /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear5' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear5_DSTATE[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear5_InitialCo;

  /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear 4' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear4_DSTATE_b[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear4_Initial_k;

  /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear6' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear6_DSTATE[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear6_InitialCo;

  /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear 5' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear5_DSTATE_p[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear5_Initia_lu;

  /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear2' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear2_DSTATE[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear2_InitialCo;

  /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear 2' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear2_DSTATE_l[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear2_Initial_l;

  /* InitializeConditions for Delay: '<S52>/Wait for Buffer to clear1' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear1_DSTATE_p[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear1_Initial_h;

  /* InitializeConditions for Delay: '<S52>/Wait for Buffer to clear 1' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear1_DSTATE_d[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear1_Initial_c;

  /* InitializeConditions for Delay: '<S52>/Wait for Buffer to clear11' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear11_DSTATE[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear11_InitialC;

  /* InitializeConditions for Delay: '<S52>/Wait for Buffer to clear 10' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear10_DSTATE_n[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear10_Initia_l;

  /* InitializeConditions for Delay: '<S52>/Wait for Buffer to clear2' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear2_DSTATE_b[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear2_Initial_g;

  /* InitializeConditions for Delay: '<S52>/Wait for Buffer to clear 2' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear2_DSTATE_d[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear2_Initial_k;

  /* InitializeConditions for Delay: '<S52>/Wait for Buffer to clear3' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear3_DSTATE_n[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear3_Initial_m;

  /* InitializeConditions for Delay: '<S52>/Wait for Buffer to clear 3' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear3_DSTATE_c[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear3_Initial_j;

  /* InitializeConditions for Delay: '<S52>/Wait for Buffer to clear4' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear4_DSTATE_p[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear4_Initial_d;

  /* InitializeConditions for Delay: '<S52>/Wait for Buffer to clear 4' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear4_DSTATE_c[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear4_Initial_h;

  /* InitializeConditions for Delay: '<S52>/Wait for Buffer to clear6' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear6_DSTATE_b[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear6_Initial_c;

  /* InitializeConditions for Delay: '<S52>/Wait for Buffer to clear 5' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear5_DSTATE_c[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear5_Initial_n;

  /* InitializeConditions for Delay: '<S52>/Wait for Buffer to clear7' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear7_DSTATE[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear7_InitialCo;

  /* InitializeConditions for Delay: '<S52>/Wait for Buffer to clear 6' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear6_DSTATE_br[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear6_Initial_m;

  /* InitializeConditions for Delay: '<S52>/Wait for Buffer to clear8' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear8_DSTATE[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear8_InitialCo;

  /* InitializeConditions for Delay: '<S52>/Wait for Buffer to clear 7' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear7_DSTATE_a[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear7_Initial_j;

  /* InitializeConditions for Delay: '<S52>/Wait for Buffer to clear5' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear5_DSTATE_l[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear5_Initial_l;

  /* InitializeConditions for Delay: '<S52>/Wait for Buffer to clear 8' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear8_DSTATE_d[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear8_Initial_i;

  /* InitializeConditions for Delay: '<S52>/Wait for Buffer to clear10' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear10_DSTATE[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear10_InitialC;

  /* InitializeConditions for Delay: '<S52>/Wait for Buffer to clear 9' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear9_DSTATE_i[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear9_Initial_n;

  /* InitializeConditions for Delay: '<S53>/Wait for Buffer to clear1' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear1_DSTATE_c[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear1_Initial_a;

  /* InitializeConditions for Delay: '<S53>/Wait for Buffer to clear 1' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear1_DSTATE_n[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear1_Initial_b;

  /* InitializeConditions for Delay: '<S53>/Wait for Buffer to clear11' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear11_DSTATE_g[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear11_Initia_f;

  /* InitializeConditions for Delay: '<S53>/Wait for Buffer to clear 10' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear10_DSTAT_nb[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear10_Initi_ow;

  /* InitializeConditions for Delay: '<S53>/Wait for Buffer to clear7' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear7_DSTATE_f[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear7_Initial_b;

  /* InitializeConditions for Delay: '<S53>/Wait for Buffer to clear 6' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear6_DSTATE_j[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear6_Initial_b;

  /* InitializeConditions for Delay: '<S53>/Wait for Buffer to clear8' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear8_DSTATE_e[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear8_Initial_m;

  /* InitializeConditions for Delay: '<S53>/Wait for Buffer to clear 7' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear7_DSTATE_d[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear7_Initial_l;

  /* InitializeConditions for Delay: '<S53>/Wait for Buffer to clear9' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear9_DSTATE[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear9_InitialCo;

  /* InitializeConditions for Delay: '<S53>/Wait for Buffer to clear 8' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear8_DSTATE_j[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear8_Initial_c;

  /* InitializeConditions for Delay: '<S53>/Wait for Buffer to clear10' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear10_DSTATE_p[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear10_Initia_o;

  /* InitializeConditions for Delay: '<S53>/Wait for Buffer to clear 9' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear9_DSTATE_a[0] =
    uart_xy_wiggler_P.WaitforBuffertoclear9_Initial_h;

  /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear1' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear1_DSTATE[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear1_InitialCo;

  /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear ' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear_DSTATE[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear_InitialCon;

  /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear3' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear3_DSTATE[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear3_InitialCo;

  /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear 1' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear1_DSTATE_l[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear1_Initial_n;

  /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear4' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear4_DSTATE[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear4_InitialCo;

  /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear 3' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear3_DSTATE_j[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear3_Initia_mg;

  /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear5' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear5_DSTATE[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear5_InitialCo;

  /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear 4' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear4_DSTATE_b[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear4_Initial_k;

  /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear6' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear6_DSTATE[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear6_InitialCo;

  /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear 5' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear5_DSTATE_p[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear5_Initia_lu;

  /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear2' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear2_DSTATE[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear2_InitialCo;

  /* InitializeConditions for Delay: '<S8>/Wait for Buffer to clear 2' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear2_DSTATE_l[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear2_Initial_l;

  /* InitializeConditions for Delay: '<S52>/Wait for Buffer to clear1' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear1_DSTATE_p[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear1_Initial_h;

  /* InitializeConditions for Delay: '<S52>/Wait for Buffer to clear 1' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear1_DSTATE_d[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear1_Initial_c;

  /* InitializeConditions for Delay: '<S52>/Wait for Buffer to clear11' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear11_DSTATE[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear11_InitialC;

  /* InitializeConditions for Delay: '<S52>/Wait for Buffer to clear 10' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear10_DSTATE_n[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear10_Initia_l;

  /* InitializeConditions for Delay: '<S52>/Wait for Buffer to clear2' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear2_DSTATE_b[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear2_Initial_g;

  /* InitializeConditions for Delay: '<S52>/Wait for Buffer to clear 2' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear2_DSTATE_d[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear2_Initial_k;

  /* InitializeConditions for Delay: '<S52>/Wait for Buffer to clear3' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear3_DSTATE_n[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear3_Initial_m;

  /* InitializeConditions for Delay: '<S52>/Wait for Buffer to clear 3' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear3_DSTATE_c[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear3_Initial_j;

  /* InitializeConditions for Delay: '<S52>/Wait for Buffer to clear4' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear4_DSTATE_p[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear4_Initial_d;

  /* InitializeConditions for Delay: '<S52>/Wait for Buffer to clear 4' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear4_DSTATE_c[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear4_Initial_h;

  /* InitializeConditions for Delay: '<S52>/Wait for Buffer to clear6' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear6_DSTATE_b[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear6_Initial_c;

  /* InitializeConditions for Delay: '<S52>/Wait for Buffer to clear 5' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear5_DSTATE_c[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear5_Initial_n;

  /* InitializeConditions for Delay: '<S52>/Wait for Buffer to clear7' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear7_DSTATE[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear7_InitialCo;

  /* InitializeConditions for Delay: '<S52>/Wait for Buffer to clear 6' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear6_DSTATE_br[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear6_Initial_m;

  /* InitializeConditions for Delay: '<S52>/Wait for Buffer to clear8' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear8_DSTATE[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear8_InitialCo;

  /* InitializeConditions for Delay: '<S52>/Wait for Buffer to clear 7' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear7_DSTATE_a[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear7_Initial_j;

  /* InitializeConditions for Delay: '<S52>/Wait for Buffer to clear5' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear5_DSTATE_l[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear5_Initial_l;

  /* InitializeConditions for Delay: '<S52>/Wait for Buffer to clear 8' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear8_DSTATE_d[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear8_Initial_i;

  /* InitializeConditions for Delay: '<S52>/Wait for Buffer to clear10' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear10_DSTATE[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear10_InitialC;

  /* InitializeConditions for Delay: '<S52>/Wait for Buffer to clear 9' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear9_DSTATE_i[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear9_Initial_n;

  /* InitializeConditions for Delay: '<S53>/Wait for Buffer to clear1' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear1_DSTATE_c[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear1_Initial_a;

  /* InitializeConditions for Delay: '<S53>/Wait for Buffer to clear 1' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear1_DSTATE_n[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear1_Initial_b;

  /* InitializeConditions for Delay: '<S53>/Wait for Buffer to clear11' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear11_DSTATE_g[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear11_Initia_f;

  /* InitializeConditions for Delay: '<S53>/Wait for Buffer to clear 10' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear10_DSTAT_nb[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear10_Initi_ow;

  /* InitializeConditions for Delay: '<S53>/Wait for Buffer to clear7' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear7_DSTATE_f[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear7_Initial_b;

  /* InitializeConditions for Delay: '<S53>/Wait for Buffer to clear 6' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear6_DSTATE_j[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear6_Initial_b;

  /* InitializeConditions for Delay: '<S53>/Wait for Buffer to clear8' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear8_DSTATE_e[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear8_Initial_m;

  /* InitializeConditions for Delay: '<S53>/Wait for Buffer to clear 7' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear7_DSTATE_d[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear7_Initial_l;

  /* InitializeConditions for Delay: '<S53>/Wait for Buffer to clear9' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear9_DSTATE[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear9_InitialCo;

  /* InitializeConditions for Delay: '<S53>/Wait for Buffer to clear 8' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear8_DSTATE_j[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear8_Initial_c;

  /* InitializeConditions for Delay: '<S53>/Wait for Buffer to clear10' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear10_DSTATE_p[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear10_Initia_o;

  /* InitializeConditions for Delay: '<S53>/Wait for Buffer to clear 9' */
  uart_xy_wiggler_DWork.WaitforBuffertoclear9_DSTATE_a[1] =
    uart_xy_wiggler_P.WaitforBuffertoclear9_Initial_h;

  /* InitializeConditions for RateTransition: '<S53>/Rate Transition19' */
  uart_xy_wiggler_DWork.RateTransition19_Buffer0_o =
    uart_xy_wiggler_P.RateTransition19_InitialCondi_j;

  /* InitializeConditions for RateTransition: '<S53>/Rate Transition20' */
  uart_xy_wiggler_DWork.RateTransition20_Buffer0_e =
    uart_xy_wiggler_P.RateTransition20_InitialCondi_j;
  uart_xy_wigg_MedianFilter1_Init(&uart_xy_wiggler_DWork.MedianFilter);
  uart_xy_wigg_MedianFilter1_Init(&uart_xy_wiggler_DWork.MedianFilter1);

  /* Enable for S-Function (stm32f4_usart): '<Root>/UART Setup' */
  /* Level2 S-Function Block: '<Root>/UART Setup' (stm32f4_usart) */
  enable_UARTSetup();

  /* Enable for S-Function (stm32f4_digital_output): '<S7>/DC_enable' */
  /* Level2 S-Function Block: '<S7>/DC_enable' (stm32f4_digital_output) */
  enable_record_and_send_via_UARTDC_enable();

  /* Enable for S-Function (stm32f4_pwm_capture): '<Root>/PWM chX' */
  /* Level2 S-Function Block: '<Root>/PWM chX' (stm32f4_pwm_capture) */
  enable_PWMchX();

  /* Enable for S-Function (stm32f4_pwm_capture): '<Root>/PWM chY' */
  /* Level2 S-Function Block: '<Root>/PWM chY' (stm32f4_pwm_capture) */
  enable_PWMchY();

  /* Enable for S-Function (stm32f4_basicpwm): '<S9>/Basic PWM' */
  /* Level2 S-Function Block: '<S9>/Basic PWM' (stm32f4_basicpwm) */
  enable_wigglerBasicPWM();

  /* Enable for S-Function (stm32f4_digital_output): '<S9>/Digital Output1' */
  /* Level2 S-Function Block: '<S9>/Digital Output1' (stm32f4_digital_output) */
  enable_wigglerDigitalOutput1();

  /* Enable for S-Function (stm32f4_digital_output): '<S9>/Digital Output2' */
  /* Level2 S-Function Block: '<S9>/Digital Output2' (stm32f4_digital_output) */
  enable_wigglerDigitalOutput2();

  /* Enable for S-Function (stm32f4_usart): '<S8>/UART Rx' */
  /* Level2 S-Function Block: '<S8>/UART Rx' (stm32f4_usart) */
  enable_set_UART_VCflagUARTRx();

  /* Enable for S-Function (stm32f4_usart): '<S8>/UART Rx1' */
  /* Level2 S-Function Block: '<S8>/UART Rx1' (stm32f4_usart) */
  enable_set_UART_VCflagUARTRx1();

  /* Enable for S-Function (stm32f4_usart): '<S8>/UART Rx4' */
  /* Level2 S-Function Block: '<S8>/UART Rx4' (stm32f4_usart) */
  enable_set_UART_VCflagUARTRx4();

  /* Enable for S-Function (stm32f4_usart): '<S8>/UART Rx5' */
  /* Level2 S-Function Block: '<S8>/UART Rx5' (stm32f4_usart) */
  enable_set_UART_VCflagUARTRx5();

  /* Enable for S-Function (stm32f4_usart): '<S8>/UART Rx6' */
  /* Level2 S-Function Block: '<S8>/UART Rx6' (stm32f4_usart) */
  enable_set_UART_VCflagUARTRx6();

  /* Enable for S-Function (stm32f4_usart): '<S8>/UART Rx2' */
  /* Level2 S-Function Block: '<S8>/UART Rx2' (stm32f4_usart) */
  enable_set_UART_VCflagUARTRx2();

  /* Enable for S-Function (stm32f4_usart): '<S8>/UART Rx3' */
  /* Level2 S-Function Block: '<S8>/UART Rx3' (stm32f4_usart) */
  enable_set_UART_VCflagUARTRx3();

  /* Enable for S-Function (stm32f4_usart): '<S52>/UART Rx1' */
  /* Level2 S-Function Block: '<S52>/UART Rx1' (stm32f4_usart) */
  enable_set_UART_VCflagCalibrationDataUartUARTRx1();

  /* Enable for S-Function (stm32f4_usart): '<S52>/UART Rx11' */
  /* Level2 S-Function Block: '<S52>/UART Rx11' (stm32f4_usart) */
  enable_set_UART_VCflagCalibrationDataUartUARTRx11();

  /* Enable for S-Function (stm32f4_usart): '<S52>/UART Rx2' */
  /* Level2 S-Function Block: '<S52>/UART Rx2' (stm32f4_usart) */
  enable_set_UART_VCflagCalibrationDataUartUARTRx2();

  /* Enable for S-Function (stm32f4_usart): '<S52>/UART Rx3' */
  /* Level2 S-Function Block: '<S52>/UART Rx3' (stm32f4_usart) */
  enable_set_UART_VCflagCalibrationDataUartUARTRx3();

  /* Enable for S-Function (stm32f4_usart): '<S52>/UART Rx4' */
  /* Level2 S-Function Block: '<S52>/UART Rx4' (stm32f4_usart) */
  enable_set_UART_VCflagCalibrationDataUartUARTRx4();

  /* Enable for S-Function (stm32f4_usart): '<S52>/UART Rx6' */
  /* Level2 S-Function Block: '<S52>/UART Rx6' (stm32f4_usart) */
  enable_set_UART_VCflagCalibrationDataUartUARTRx6();

  /* Enable for S-Function (stm32f4_usart): '<S52>/UART Rx7' */
  /* Level2 S-Function Block: '<S52>/UART Rx7' (stm32f4_usart) */
  enable_set_UART_VCflagCalibrationDataUartUARTRx7();

  /* Enable for S-Function (stm32f4_usart): '<S52>/UART Rx8' */
  /* Level2 S-Function Block: '<S52>/UART Rx8' (stm32f4_usart) */
  enable_set_UART_VCflagCalibrationDataUartUARTRx8();

  /* Enable for S-Function (stm32f4_usart): '<S52>/UART Rx5' */
  /* Level2 S-Function Block: '<S52>/UART Rx5' (stm32f4_usart) */
  enable_set_UART_VCflagCalibrationDataUartUARTRx5();

  /* Enable for S-Function (stm32f4_usart): '<S52>/UART Rx10' */
  /* Level2 S-Function Block: '<S52>/UART Rx10' (stm32f4_usart) */
  enable_set_UART_VCflagCalibrationDataUartUARTRx10();

  /* Enable for S-Function (stm32f4_usart): '<S53>/UART Rx1' */
  /* Level2 S-Function Block: '<S53>/UART Rx1' (stm32f4_usart) */
  enable_set_UART_VCflagLissajousDataUartUARTRx1();

  /* Enable for S-Function (stm32f4_usart): '<S53>/UART Rx11' */
  /* Level2 S-Function Block: '<S53>/UART Rx11' (stm32f4_usart) */
  enable_set_UART_VCflagLissajousDataUartUARTRx11();

  /* Enable for S-Function (stm32f4_usart): '<S53>/UART Rx7' */
  /* Level2 S-Function Block: '<S53>/UART Rx7' (stm32f4_usart) */
  enable_set_UART_VCflagLissajousDataUartUARTRx7();

  /* Enable for S-Function (stm32f4_usart): '<S53>/UART Rx8' */
  /* Level2 S-Function Block: '<S53>/UART Rx8' (stm32f4_usart) */
  enable_set_UART_VCflagLissajousDataUartUARTRx8();

  /* Enable for S-Function (stm32f4_usart): '<S53>/UART Rx9' */
  /* Level2 S-Function Block: '<S53>/UART Rx9' (stm32f4_usart) */
  enable_set_UART_VCflagLissajousDataUartUARTRx9();

  /* Enable for S-Function (stm32f4_usart): '<S53>/UART Rx10' */
  /* Level2 S-Function Block: '<S53>/UART Rx10' (stm32f4_usart) */
  enable_set_UART_VCflagLissajousDataUartUARTRx10();
}

/* Model terminate function */
void uart_xy_wiggler_terminate(void)
{
  /* Terminate for S-Function (stm32f4_digital_output): '<S7>/DC_enable' */

  /* terminate_record_and_send_via_UARTDC_enable(); */
  uart_xy_wigg_MedianFilter1_Term(&uart_xy_wiggler_DWork.MedianFilter);

  /* Terminate for MATLABSystem: '<Root>/Median Filter1' */
  uart_xy_wigg_MedianFilter1_Term(&uart_xy_wiggler_DWork.MedianFilter1);

  /* Terminate for S-Function (stm32f4_basicpwm): '<S9>/Basic PWM' */

  /* terminate_wigglerBasicPWM(); */

  /* Terminate for S-Function (stm32f4_digital_output): '<S9>/Digital Output1' */

  /* terminate_wigglerDigitalOutput1(); */

  /* Terminate for S-Function (stm32f4_digital_output): '<S9>/Digital Output2' */

  /* terminate_wigglerDigitalOutput2(); */
}

/* [EOF] */
