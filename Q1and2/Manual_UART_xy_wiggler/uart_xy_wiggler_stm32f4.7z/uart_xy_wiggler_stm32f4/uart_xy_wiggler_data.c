/*
 * File: uart_xy_wiggler_data.c
 *
 * Created with Waijung Blockset
 *
 * Real-Time Workshop code generated for Simulink model uart_xy_wiggler.
 *
 * Model version                        : 1.148
 * Real-Time Workshop file version      : 8.14 (R2018a) 06-Feb-2018
 * Real-Time Workshop file generated on : Sun Jul 21 14:00:36 2019
 * TLC version                          : 8.14 (Feb 22 2018)
 * C/C++ source code generated on       : Sun Jul 21 14:00:44 2019
 *
 * Target selection: stm32f4.tlc
 * Embedded hardware selection: ARM Compatible->Cortex - M4
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "uart_xy_wiggler.h"
#include "uart_xy_wiggler_private.h"

/* Block parameters (default storage) */
Parameters_uart_xy_wiggler uart_xy_wiggler_P = {
  /* Mask Parameter: DiscreteTimeVCO1_Ac
   * Referenced by: '<S13>/Sensitivity3'
   */
  1.0,

  /* Mask Parameter: DiscreteTimeVCO_Ac
   * Referenced by: '<S12>/Sensitivity3'
   */
  1.0,

  /* Mask Parameter: Coswt_Ac
   * Referenced by: '<S25>/Sensitivity3'
   */
  1.0,

  /* Mask Parameter: Sinwt_Ac
   * Referenced by: '<S27>/Sensitivity3'
   */
  1.0,

  /* Mask Parameter: Cos5wt_Ac
   * Referenced by: '<S24>/Sensitivity3'
   */
  1.0,

  /* Mask Parameter: Sin5wt_Ac
   * Referenced by: '<S26>/Sensitivity3'
   */
  1.0,

  /* Mask Parameter: DiscreteTimeVCO_Ac_m
   * Referenced by: '<S79>/Sensitivity3'
   */
  1.0,

  /* Mask Parameter: DiscreteTimeVCO1_Ph
   * Referenced by: '<S13>/Unit Delay'
   */
  0.0,

  /* Mask Parameter: DiscreteTimeVCO_Ph
   * Referenced by: '<S12>/Unit Delay'
   */
  1.5707963267948966,

  /* Mask Parameter: Coswt_Ph
   * Referenced by: '<S25>/Unit Delay'
   */
  0.0,

  /* Mask Parameter: Sinwt_Ph
   * Referenced by: '<S27>/Unit Delay'
   */
  4.71238898038469,

  /* Mask Parameter: Cos5wt_Ph
   * Referenced by: '<S24>/Unit Delay'
   */
  0.0,

  /* Mask Parameter: Sin5wt_Ph
   * Referenced by: '<S26>/Unit Delay'
   */
  4.71238898038469,

  /* Mask Parameter: DiscreteTimeVCO_Ph_k
   * Referenced by: '<S79>/Unit Delay'
   */
  0.0,

  /* Mask Parameter: CompareToConstant2_const
   * Referenced by: '<S78>/Constant'
   */
  0.0,

  /* Mask Parameter: CompareToConstant1_const
   * Referenced by: '<S77>/Constant'
   */
  0.0,

  /* Mask Parameter: CompareToConstant8_const
   * Referenced by: '<S43>/Constant'
   */
  50.0F,

  /* Mask Parameter: CompareToConstant10_const
   * Referenced by: '<S42>/Constant'
   */
  -50.0F,

  /* Mask Parameter: CompareToConstant8_const_l
   * Referenced by: '<S45>/Constant'
   */
  50.0F,

  /* Mask Parameter: CompareToConstant10_const_o
   * Referenced by: '<S44>/Constant'
   */
  -50.0F,

  /* Mask Parameter: CompareToConstant1_const_c
   * Referenced by: '<S46>/Constant'
   */
  1U,

  /* Mask Parameter: CompareToConstant5_const
   * Referenced by: '<S47>/Constant'
   */
  2U,

  /* Mask Parameter: CompareToConstant6_const
   * Referenced by: '<S48>/Constant'
   */
  3U,

  /* Mask Parameter: CompareToConstant7_const
   * Referenced by: '<S49>/Constant'
   */
  2U,

  /* Expression: 90
   * Referenced by: '<S9>/Constant'
   */
  90.0,

  /* Expression: 1
   * Referenced by: '<Root>/recording_clock'
   */
  1.0,

  /* Expression: 2
   * Referenced by: '<Root>/recording_clock'
   */
  2.0,

  /* Expression: 1
   * Referenced by: '<Root>/recording_clock'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<Root>/recording_clock'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<Root>/send_2_uart_clock'
   */
  1.0,

  /* Expression: 2
   * Referenced by: '<Root>/send_2_uart_clock'
   */
  2.0,

  /* Expression: 1
   * Referenced by: '<Root>/send_2_uart_clock'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<Root>/send_2_uart_clock'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S9>/Gain'
   */
  1.0,

  /* Expression: 1
   * Referenced by: '<S9>/Gain1'
   */
  1.0,

  /* Expression: 90
   * Referenced by: '<S9>/Constant1'
   */
  90.0,

  /* Computed Parameter: WeightedSampleTime_WtEt
   * Referenced by: '<S79>/Weighted Sample Time'
   */
  0.01,

  /* Expression: FcRadians
   * Referenced by: '<S79>/Center Frequency'
   */
  0.0,

  /* Expression: KcRadPerV
   * Referenced by: '<S82>/Gain'
   */
  6.2831853071795862,

  /* Expression: 2*pi
   * Referenced by: '<S79>/Modulo 2*pi'
   */
  6.2831853071795862,

  /* Computed Parameter: WeightedSampleTime_WtEt_a
   * Referenced by: '<S12>/Weighted Sample Time'
   */
  0.01,

  /* Expression: FcRadians
   * Referenced by: '<S12>/Center Frequency'
   */
  0.0,

  /* Expression: KcRadPerV
   * Referenced by: '<S18>/Gain'
   */
  6.2831853071795862,

  /* Expression: 2*pi
   * Referenced by: '<S12>/Modulo 2*pi'
   */
  6.2831853071795862,

  /* Computed Parameter: WeightedSampleTime_WtEt_o
   * Referenced by: '<S13>/Weighted Sample Time'
   */
  0.01,

  /* Expression: FcRadians
   * Referenced by: '<S13>/Center Frequency'
   */
  0.0,

  /* Expression: KcRadPerV
   * Referenced by: '<S21>/Gain'
   */
  6.2831853071795862,

  /* Expression: 2*pi
   * Referenced by: '<S13>/Modulo 2*pi'
   */
  6.2831853071795862,

  /* Computed Parameter: WeightedSampleTime_WtEt_os
   * Referenced by: '<S24>/Weighted Sample Time'
   */
  0.01,

  /* Expression: FcRadians
   * Referenced by: '<S24>/Center Frequency'
   */
  0.0,

  /* Expression: 5
   * Referenced by: '<S3>/Gain1'
   */
  5.0,

  /* Expression: KcRadPerV
   * Referenced by: '<S32>/Gain'
   */
  6.2831853071795862,

  /* Expression: 2*pi
   * Referenced by: '<S24>/Modulo 2*pi'
   */
  6.2831853071795862,

  /* Computed Parameter: WeightedSampleTime_WtEt_i
   * Referenced by: '<S25>/Weighted Sample Time'
   */
  0.01,

  /* Expression: FcRadians
   * Referenced by: '<S25>/Center Frequency'
   */
  0.0,

  /* Expression: KcRadPerV
   * Referenced by: '<S35>/Gain'
   */
  6.2831853071795862,

  /* Expression: 2*pi
   * Referenced by: '<S25>/Modulo 2*pi'
   */
  6.2831853071795862,

  /* Expression: 5
   * Referenced by: '<S3>/Gain'
   */
  5.0,

  /* Computed Parameter: WeightedSampleTime_WtEt_h
   * Referenced by: '<S26>/Weighted Sample Time'
   */
  0.01,

  /* Expression: FcRadians
   * Referenced by: '<S26>/Center Frequency'
   */
  0.0,

  /* Expression: KcRadPerV
   * Referenced by: '<S38>/Gain'
   */
  6.2831853071795862,

  /* Expression: 2*pi
   * Referenced by: '<S26>/Modulo 2*pi'
   */
  6.2831853071795862,

  /* Computed Parameter: WeightedSampleTime_WtEt_a3
   * Referenced by: '<S27>/Weighted Sample Time'
   */
  0.01,

  /* Expression: FcRadians
   * Referenced by: '<S27>/Center Frequency'
   */
  0.0,

  /* Expression: KcRadPerV
   * Referenced by: '<S41>/Gain'
   */
  6.2831853071795862,

  /* Expression: 2*pi
   * Referenced by: '<S27>/Modulo 2*pi'
   */
  6.2831853071795862,

  /* Computed Parameter: Constant_Value_m
   * Referenced by: '<Root>/Constant'
   */
  50.0F,

  /* Computed Parameter: Delay2_InitialCondition
   * Referenced by: '<S5>/Delay2'
   */
  0.0F,

  /* Computed Parameter: Constant1_Value_e
   * Referenced by: '<Root>/Constant1'
   */
  50.0F,

  /* Computed Parameter: Delay2_InitialCondition_h
   * Referenced by: '<S6>/Delay2'
   */
  0.0F,

  /* Computed Parameter: WaitforBuffertoclear1_InitialCo
   * Referenced by: '<S8>/Wait for Buffer to clear1'
   */
  0.0F,

  /* Computed Parameter: RateTransition4_InitialConditio
   * Referenced by: '<S8>/Rate Transition4'
   */
  0.0F,

  /* Computed Parameter: WaitforBuffertoclear3_InitialCo
   * Referenced by: '<S8>/Wait for Buffer to clear3'
   */
  0.0F,

  /* Computed Parameter: RateTransition3_InitialConditio
   * Referenced by: '<S8>/Rate Transition3'
   */
  0.0F,

  /* Computed Parameter: WaitforBuffertoclear4_InitialCo
   * Referenced by: '<S8>/Wait for Buffer to clear4'
   */
  0.0F,

  /* Computed Parameter: RateTransition8_InitialConditio
   * Referenced by: '<S8>/Rate Transition8'
   */
  0.0F,

  /* Computed Parameter: WaitforBuffertoclear5_InitialCo
   * Referenced by: '<S8>/Wait for Buffer to clear5'
   */
  0.0F,

  /* Computed Parameter: RateTransition10_InitialConditi
   * Referenced by: '<S8>/Rate Transition10'
   */
  0.0F,

  /* Computed Parameter: WaitforBuffertoclear6_InitialCo
   * Referenced by: '<S8>/Wait for Buffer to clear6'
   */
  0.0F,

  /* Computed Parameter: RateTransition11_InitialConditi
   * Referenced by: '<S8>/Rate Transition11'
   */
  0.0F,

  /* Computed Parameter: WaitforBuffertoclear2_InitialCo
   * Referenced by: '<S8>/Wait for Buffer to clear2'
   */
  0.0F,

  /* Computed Parameter: RateTransition6_InitialConditio
   * Referenced by: '<S8>/Rate Transition6'
   */
  0.0F,

  /* Computed Parameter: WaitforBuffertoclear1_Initial_h
   * Referenced by: '<S52>/Wait for Buffer to clear1'
   */
  0.0F,

  /* Computed Parameter: RateTransition1_InitialConditio
   * Referenced by: '<S52>/Rate Transition1'
   */
  0.0F,

  /* Computed Parameter: WaitforBuffertoclear11_InitialC
   * Referenced by: '<S52>/Wait for Buffer to clear11'
   */
  0.0F,

  /* Computed Parameter: RateTransition21_InitialConditi
   * Referenced by: '<S52>/Rate Transition21'
   */
  0.0F,

  /* Computed Parameter: WaitforBuffertoclear2_Initial_g
   * Referenced by: '<S52>/Wait for Buffer to clear2'
   */
  0.0F,

  /* Computed Parameter: RateTransition3_InitialCondit_a
   * Referenced by: '<S52>/Rate Transition3'
   */
  0.0F,

  /* Computed Parameter: WaitforBuffertoclear3_Initial_m
   * Referenced by: '<S52>/Wait for Buffer to clear3'
   */
  0.0F,

  /* Computed Parameter: RateTransition5_InitialConditio
   * Referenced by: '<S52>/Rate Transition5'
   */
  0.0F,

  /* Computed Parameter: WaitforBuffertoclear4_Initial_d
   * Referenced by: '<S52>/Wait for Buffer to clear4'
   */
  0.0F,

  /* Computed Parameter: RateTransition7_InitialConditio
   * Referenced by: '<S52>/Rate Transition7'
   */
  0.0F,

  /* Computed Parameter: WaitforBuffertoclear6_Initial_c
   * Referenced by: '<S52>/Wait for Buffer to clear6'
   */
  0.0F,

  /* Computed Parameter: RateTransition11_InitialCondi_l
   * Referenced by: '<S52>/Rate Transition11'
   */
  0.0F,

  /* Computed Parameter: WaitforBuffertoclear7_InitialCo
   * Referenced by: '<S52>/Wait for Buffer to clear7'
   */
  0.0F,

  /* Computed Parameter: RateTransition13_InitialConditi
   * Referenced by: '<S52>/Rate Transition13'
   */
  0.0F,

  /* Computed Parameter: WaitforBuffertoclear8_InitialCo
   * Referenced by: '<S52>/Wait for Buffer to clear8'
   */
  0.0F,

  /* Computed Parameter: RateTransition15_InitialConditi
   * Referenced by: '<S52>/Rate Transition15'
   */
  0.0F,

  /* Computed Parameter: WaitforBuffertoclear5_Initial_l
   * Referenced by: '<S52>/Wait for Buffer to clear5'
   */
  0.0F,

  /* Computed Parameter: RateTransition8_InitialCondit_i
   * Referenced by: '<S52>/Rate Transition8'
   */
  0.0F,

  /* Computed Parameter: WaitforBuffertoclear10_InitialC
   * Referenced by: '<S52>/Wait for Buffer to clear10'
   */
  0.0F,

  /* Computed Parameter: RateTransition19_InitialConditi
   * Referenced by: '<S52>/Rate Transition19'
   */
  0.0F,

  /* Computed Parameter: WaitforBuffertoclear1_Initial_a
   * Referenced by: '<S53>/Wait for Buffer to clear1'
   */
  0.0F,

  /* Computed Parameter: RateTransition1_InitialCondit_n
   * Referenced by: '<S53>/Rate Transition1'
   */
  0.0F,

  /* Computed Parameter: WaitforBuffertoclear11_Initia_f
   * Referenced by: '<S53>/Wait for Buffer to clear11'
   */
  0.0F,

  /* Computed Parameter: RateTransition21_InitialCondi_e
   * Referenced by: '<S53>/Rate Transition21'
   */
  0.0F,

  /* Computed Parameter: WaitforBuffertoclear7_Initial_b
   * Referenced by: '<S53>/Wait for Buffer to clear7'
   */
  0.0F,

  /* Computed Parameter: RateTransition13_InitialCondi_a
   * Referenced by: '<S53>/Rate Transition13'
   */
  0.0F,

  /* Computed Parameter: WaitforBuffertoclear8_Initial_m
   * Referenced by: '<S53>/Wait for Buffer to clear8'
   */
  0.0F,

  /* Computed Parameter: RateTransition15_InitialCondi_n
   * Referenced by: '<S53>/Rate Transition15'
   */
  0.0F,

  /* Computed Parameter: WaitforBuffertoclear9_InitialCo
   * Referenced by: '<S53>/Wait for Buffer to clear9'
   */
  0.0F,

  /* Computed Parameter: RateTransition17_InitialConditi
   * Referenced by: '<S53>/Rate Transition17'
   */
  0.0F,

  /* Computed Parameter: WaitforBuffertoclear10_Initia_o
   * Referenced by: '<S53>/Wait for Buffer to clear10'
   */
  0.0F,

  /* Computed Parameter: RateTransition19_InitialCondi_j
   * Referenced by: '<S53>/Rate Transition19'
   */
  0.0F,

  /* Computed Parameter: Delay2_DelayLength
   * Referenced by: '<S5>/Delay2'
   */
  1U,

  /* Computed Parameter: Delay2_DelayLength_f
   * Referenced by: '<S6>/Delay2'
   */
  1U,

  /* Computed Parameter: WaitforBuffertoclear1_DelayLeng
   * Referenced by: '<S8>/Wait for Buffer to clear1'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear_DelayLengt
   * Referenced by: '<S8>/Wait for Buffer to clear '
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear3_DelayLeng
   * Referenced by: '<S8>/Wait for Buffer to clear3'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear1_DelayLe_f
   * Referenced by: '<S8>/Wait for Buffer to clear 1'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear4_DelayLeng
   * Referenced by: '<S8>/Wait for Buffer to clear4'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear3_DelayLe_k
   * Referenced by: '<S8>/Wait for Buffer to clear 3'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear5_DelayLeng
   * Referenced by: '<S8>/Wait for Buffer to clear5'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear4_DelayLe_n
   * Referenced by: '<S8>/Wait for Buffer to clear 4'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear6_DelayLeng
   * Referenced by: '<S8>/Wait for Buffer to clear6'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear5_DelayLe_d
   * Referenced by: '<S8>/Wait for Buffer to clear 5'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear2_DelayLeng
   * Referenced by: '<S8>/Wait for Buffer to clear2'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear2_DelayLe_k
   * Referenced by: '<S8>/Wait for Buffer to clear 2'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear1_DelayLe_o
   * Referenced by: '<S52>/Wait for Buffer to clear1'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear1_DelayLe_n
   * Referenced by: '<S52>/Wait for Buffer to clear 1'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear11_DelayLen
   * Referenced by: '<S52>/Wait for Buffer to clear11'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear10_DelayLen
   * Referenced by: '<S52>/Wait for Buffer to clear 10'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear2_DelayLe_e
   * Referenced by: '<S52>/Wait for Buffer to clear2'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear2_DelayLe_c
   * Referenced by: '<S52>/Wait for Buffer to clear 2'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear3_DelayLe_c
   * Referenced by: '<S52>/Wait for Buffer to clear3'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear3_DelayLe_h
   * Referenced by: '<S52>/Wait for Buffer to clear 3'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear4_DelayLe_g
   * Referenced by: '<S52>/Wait for Buffer to clear4'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear4_DelayLe_c
   * Referenced by: '<S52>/Wait for Buffer to clear 4'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear6_DelayLe_a
   * Referenced by: '<S52>/Wait for Buffer to clear6'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear5_DelayLe_k
   * Referenced by: '<S52>/Wait for Buffer to clear 5'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear7_DelayLeng
   * Referenced by: '<S52>/Wait for Buffer to clear7'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear6_DelayLe_m
   * Referenced by: '<S52>/Wait for Buffer to clear 6'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear8_DelayLeng
   * Referenced by: '<S52>/Wait for Buffer to clear8'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear7_DelayLe_c
   * Referenced by: '<S52>/Wait for Buffer to clear 7'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear5_DelayLe_a
   * Referenced by: '<S52>/Wait for Buffer to clear5'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear8_DelayLe_c
   * Referenced by: '<S52>/Wait for Buffer to clear 8'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear10_DelayL_f
   * Referenced by: '<S52>/Wait for Buffer to clear10'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear9_DelayLeng
   * Referenced by: '<S52>/Wait for Buffer to clear 9'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear1_DelayL_f0
   * Referenced by: '<S53>/Wait for Buffer to clear1'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear1_DelayLe_j
   * Referenced by: '<S53>/Wait for Buffer to clear 1'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear11_DelayL_m
   * Referenced by: '<S53>/Wait for Buffer to clear11'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear10_DelayL_n
   * Referenced by: '<S53>/Wait for Buffer to clear 10'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear7_DelayLe_j
   * Referenced by: '<S53>/Wait for Buffer to clear7'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear6_DelayLe_e
   * Referenced by: '<S53>/Wait for Buffer to clear 6'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear8_DelayLe_n
   * Referenced by: '<S53>/Wait for Buffer to clear8'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear7_DelayLe_o
   * Referenced by: '<S53>/Wait for Buffer to clear 7'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear9_DelayLe_o
   * Referenced by: '<S53>/Wait for Buffer to clear9'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear8_DelayLe_b
   * Referenced by: '<S53>/Wait for Buffer to clear 8'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear10_Delay_nh
   * Referenced by: '<S53>/Wait for Buffer to clear10'
   */
  2U,

  /* Computed Parameter: WaitforBuffertoclear9_DelayLe_h
   * Referenced by: '<S53>/Wait for Buffer to clear 9'
   */
  2U,

  /* Computed Parameter: Constant_Value_e
   * Referenced by: '<S51>/Constant'
   */
  0U,

  /* Computed Parameter: WaitforBuffertoclear_InitialCon
   * Referenced by: '<S8>/Wait for Buffer to clear '
   */
  0U,

  /* Computed Parameter: RateTransition2_InitialConditio
   * Referenced by: '<S8>/Rate Transition2'
   */
  0U,

  /* Computed Parameter: WaitforBuffertoclear1_Initial_n
   * Referenced by: '<S8>/Wait for Buffer to clear 1'
   */
  0U,

  /* Computed Parameter: RateTransition1_InitialCondit_g
   * Referenced by: '<S8>/Rate Transition1'
   */
  0U,

  /* Computed Parameter: WaitforBuffertoclear3_Initia_mg
   * Referenced by: '<S8>/Wait for Buffer to clear 3'
   */
  0U,

  /* Computed Parameter: RateTransition7_InitialCondit_j
   * Referenced by: '<S8>/Rate Transition7'
   */
  0U,

  /* Computed Parameter: WaitforBuffertoclear4_Initial_k
   * Referenced by: '<S8>/Wait for Buffer to clear 4'
   */
  0U,

  /* Computed Parameter: RateTransition9_InitialConditio
   * Referenced by: '<S8>/Rate Transition9'
   */
  0U,

  /* Computed Parameter: WaitforBuffertoclear5_Initia_lu
   * Referenced by: '<S8>/Wait for Buffer to clear 5'
   */
  0U,

  /* Computed Parameter: RateTransition12_InitialConditi
   * Referenced by: '<S8>/Rate Transition12'
   */
  0U,

  /* Computed Parameter: WaitforBuffertoclear2_Initial_l
   * Referenced by: '<S8>/Wait for Buffer to clear 2'
   */
  0U,

  /* Computed Parameter: RateTransition5_InitialCondit_e
   * Referenced by: '<S8>/Rate Transition5'
   */
  0U,

  /* Computed Parameter: WaitforBuffertoclear1_Initial_c
   * Referenced by: '<S52>/Wait for Buffer to clear 1'
   */
  0U,

  /* Computed Parameter: RateTransition2_InitialCondit_i
   * Referenced by: '<S52>/Rate Transition2'
   */
  0U,

  /* Computed Parameter: WaitforBuffertoclear10_Initia_l
   * Referenced by: '<S52>/Wait for Buffer to clear 10'
   */
  0U,

  /* Computed Parameter: RateTransition22_InitialConditi
   * Referenced by: '<S52>/Rate Transition22'
   */
  0U,

  /* Computed Parameter: WaitforBuffertoclear2_Initial_k
   * Referenced by: '<S52>/Wait for Buffer to clear 2'
   */
  0U,

  /* Computed Parameter: RateTransition4_InitialCondit_e
   * Referenced by: '<S52>/Rate Transition4'
   */
  0U,

  /* Computed Parameter: WaitforBuffertoclear3_Initial_j
   * Referenced by: '<S52>/Wait for Buffer to clear 3'
   */
  0U,

  /* Computed Parameter: RateTransition6_InitialCondit_b
   * Referenced by: '<S52>/Rate Transition6'
   */
  0U,

  /* Computed Parameter: WaitforBuffertoclear4_Initial_h
   * Referenced by: '<S52>/Wait for Buffer to clear 4'
   */
  0U,

  /* Computed Parameter: RateTransition9_InitialCondit_c
   * Referenced by: '<S52>/Rate Transition9'
   */
  0U,

  /* Computed Parameter: WaitforBuffertoclear5_Initial_n
   * Referenced by: '<S52>/Wait for Buffer to clear 5'
   */
  0U,

  /* Computed Parameter: RateTransition12_InitialCondi_e
   * Referenced by: '<S52>/Rate Transition12'
   */
  0U,

  /* Computed Parameter: WaitforBuffertoclear6_Initial_m
   * Referenced by: '<S52>/Wait for Buffer to clear 6'
   */
  0U,

  /* Computed Parameter: RateTransition14_InitialConditi
   * Referenced by: '<S52>/Rate Transition14'
   */
  0U,

  /* Computed Parameter: WaitforBuffertoclear7_Initial_j
   * Referenced by: '<S52>/Wait for Buffer to clear 7'
   */
  0U,

  /* Computed Parameter: RateTransition16_InitialConditi
   * Referenced by: '<S52>/Rate Transition16'
   */
  0U,

  /* Computed Parameter: WaitforBuffertoclear8_Initial_i
   * Referenced by: '<S52>/Wait for Buffer to clear 8'
   */
  0U,

  /* Computed Parameter: RateTransition10_InitialCondi_d
   * Referenced by: '<S52>/Rate Transition10'
   */
  0U,

  /* Computed Parameter: WaitforBuffertoclear9_Initial_n
   * Referenced by: '<S52>/Wait for Buffer to clear 9'
   */
  0U,

  /* Computed Parameter: RateTransition20_InitialConditi
   * Referenced by: '<S52>/Rate Transition20'
   */
  0U,

  /* Computed Parameter: WaitforBuffertoclear1_Initial_b
   * Referenced by: '<S53>/Wait for Buffer to clear 1'
   */
  0U,

  /* Computed Parameter: RateTransition2_InitialCondit_e
   * Referenced by: '<S53>/Rate Transition2'
   */
  0U,

  /* Computed Parameter: WaitforBuffertoclear10_Initi_ow
   * Referenced by: '<S53>/Wait for Buffer to clear 10'
   */
  0U,

  /* Computed Parameter: RateTransition22_InitialCondi_h
   * Referenced by: '<S53>/Rate Transition22'
   */
  0U,

  /* Computed Parameter: WaitforBuffertoclear6_Initial_b
   * Referenced by: '<S53>/Wait for Buffer to clear 6'
   */
  0U,

  /* Computed Parameter: RateTransition14_InitialCondi_e
   * Referenced by: '<S53>/Rate Transition14'
   */
  0U,

  /* Computed Parameter: WaitforBuffertoclear7_Initial_l
   * Referenced by: '<S53>/Wait for Buffer to clear 7'
   */
  0U,

  /* Computed Parameter: RateTransition16_InitialCondi_b
   * Referenced by: '<S53>/Rate Transition16'
   */
  0U,

  /* Computed Parameter: WaitforBuffertoclear8_Initial_c
   * Referenced by: '<S53>/Wait for Buffer to clear 8'
   */
  0U,

  /* Computed Parameter: RateTransition18_InitialConditi
   * Referenced by: '<S53>/Rate Transition18'
   */
  0U,

  /* Computed Parameter: WaitforBuffertoclear9_Initial_h
   * Referenced by: '<S53>/Wait for Buffer to clear 9'
   */
  0U,

  /* Computed Parameter: RateTransition20_InitialCondi_j
   * Referenced by: '<S53>/Rate Transition20'
   */
  0U
};

/* [EOF] */
