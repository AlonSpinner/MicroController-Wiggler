/*
 * File: uart_xy_wiggler_types.h
 *
 * Created with Waijung Blockset
 *
 * Real-Time Workshop code generated for Simulink model uart_xy_wiggler.
 *
 * Model version                        : 1.148
 * Real-Time Workshop file version      : 8.14 (R2018a) 06-Feb-2018
 * Real-Time Workshop file generated on : Sun Jul 21 14:00:36 2019
 * TLC version                          : 8.14 (Feb 22 2018)
 * C/C++ source code generated on       : Sun Jul 21 14:00:44 2019
 *
 * Target selection: stm32f4.tlc
 * Embedded hardware selection: ARM Compatible->Cortex - M4
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_uart_xy_wiggler_types_h_
#define RTW_HEADER_uart_xy_wiggler_types_h_
#include "rtwtypes.h"
#ifndef typedef_dsp_private_MedianFilterCG_uart
#define typedef_dsp_private_MedianFilterCG_uart

typedef struct {
  int32_T isInitialized;
  boolean_T isSetupComplete;
  real32_T pWinLen;
  real32_T pBuf[5];
  real32_T pHeap[5];
  real32_T pMidHeap;
  real32_T pIdx;
  real32_T pPos[5];
  real32_T pMinHeapLength;
  real32_T pMaxHeapLength;
} dsp_private_MedianFilterCG_uart;

#endif                                 /*typedef_dsp_private_MedianFilterCG_uart*/

#ifndef typedef_cell_wrap_uart_xy_wiggler
#define typedef_cell_wrap_uart_xy_wiggler

typedef struct {
  uint32_T f1[8];
} cell_wrap_uart_xy_wiggler;

#endif                                 /*typedef_cell_wrap_uart_xy_wiggler*/

#ifndef typedef_dsp_MedianFilter_uart_xy_wiggle
#define typedef_dsp_MedianFilter_uart_xy_wiggle

typedef struct {
  boolean_T matlabCodegenIsDeleted;
  int32_T isInitialized;
  boolean_T isSetupComplete;
  cell_wrap_uart_xy_wiggler inputVarSize;
  int32_T NumChannels;
  dsp_private_MedianFilterCG_uart pMID;
} dsp_MedianFilter_uart_xy_wiggle;

#endif                                 /*typedef_dsp_MedianFilter_uart_xy_wiggle*/

/* Parameters (default storage) */
typedef struct Parameters_uart_xy_wiggler_ Parameters_uart_xy_wiggler;

/* Forward declaration for rtModel */
typedef struct tag_RTM_uart_xy_wiggler RT_MODEL_uart_xy_wiggler;

#endif                                 /* RTW_HEADER_uart_xy_wiggler_types_h_ */

/* [EOF] */
